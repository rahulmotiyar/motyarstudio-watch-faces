import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const out=path.basename(here)==='source'?path.resolve(here,'..'):path.resolve(here,'../outputs/braun-round');
const engine=path.join(out,'engine/editor/core');
const {encodePixels,decodePixels}=await import(path.join(engine,'format/pixels-codec.js'));
const {parseBin,buildBin,assertFlashable,rawCRC32}=await import(path.join(engine,'format/bin.js'));
const {TAG,u32}=await import(path.join(engine,'format/raw.js'));
const {fromLegacy,toLegacy}=await import(path.join(engine,'document/doc.js'));
const {buildBind}=await import(path.join(engine,'document/sources.js'));
const {dialId}=await import(path.join(out,'engine/device/lib/ble-protocol.js'));
const OPS={eq:1,ne:2,noData:3,lt:4,gte:5,lte:6};
const meta=(w,h,source,max,sub=0)=>{
  const b=new Uint8Array(14),v=new DataView(b.buffer);
  v.setUint16(0,w,true);v.setUint16(2,h,true);b[9]=source;b[10]=sub;b[11]=max;b[12]=max>>8;b[13]=max>>16;
  return Buffer.from(b).toString('hex');
};
let variants=JSON.parse(fs.readFileSync(path.join(out,'variants.json')));
const original=new Map(variants.map(v=>[v.theme,v.sha256])),results=[];
const selectedTheme=process.argv[2];
const allowedThemes=new Set(variants.map(v=>v.theme));
const selectedFamily=process.argv[3];
const root=path.join(out,'expanded-assets');
for(const family of fs.readdirSync(root).sort()){
  if(selectedFamily&&family!==selectedFamily)continue;
  const dir=path.join(root,family);if(!fs.existsSync(path.join(dir,'scenes.json')))continue;
  const manifest=JSON.parse(fs.readFileSync(path.join(dir,'manifest.json'))),scenes=JSON.parse(fs.readFileSync(path.join(dir,'scenes.json'))).filter(s=>allowedThemes.has(s.theme)&&(!selectedTheme||s.theme===selectedTheme));
  if(!scenes.length)continue;
  const resources=[],ids={};
  for(const [key,{w,h,cf}] of Object.entries(manifest)){
    assert(w<=466&&h<=466,`${key} exceeds the native image limit`);ids[key]=resources.length;
    const pixels=new Uint8ClampedArray(fs.readFileSync(path.join(dir,key+'.rgba')));assert.equal(pixels.length,w*h*4);
    resources.push(encodePixels(pixels,w,h,cf));
  }
  const thumbnail=key=>({tag:TAG.preview,subs:[{tag:TAG.pvStruct,prefix:'0000000000',refType:0x61,images:[ids[key]]}]});
  function node(layer){
    const isHand=layer.type==='hand',isNumber=layer.type==='number',key=layer.key??layer.keys?.[0],asset=manifest[key];
    assert(!isHand||layer.source!==0x0f,`${key}: source 0x0f failed as a rotating hand on the watch; use stock smooth-hand 0x12 or ticking-hand 0x72`);
    assert(asset,`Missing asset ${key}`);const frames=isNumber?layer.keys:layer.frames??[key];
    const x=isHand?layer.cx-asset.pivotX+(asset.offsetX??0):layer.x,y=isHand?layer.cy-asset.pivotY+(asset.offsetY??0):layer.y;
    assert(Number.isInteger(x)&&Number.isInteger(y),`Fractional placement ${key}`);
    const bg=!isHand&&asset.w===466&&asset.h===466,max=layer.max??({1:24,4:24,10:60,11:60,14:60,15:60,18:60,21:12,23:31,24:7,25:99999,26:240,36:100,48:100,54:99,114:60}[layer.source]??0);
    const subs=[{tag:TAG.struct,x,y,meta:meta(bg?466:0,bg?466:0,layer.source??0,max,layer.sub??0),refType:0x61,images:frames.map(k=>{assert(k in ids,`Missing frame ${k}`);return ids[k];})}];
    if(layer.conditions?.length)subs.push({tag:TAG.bind,hex:buildBind(layer.conditions.map(c=>({id:c.source,op:OPS[c.op??'eq'],val:c.value})))});
    if(isNumber)subs.push({tag:TAG.fmt,hex:((layer.padZero===false?0:0x80)|layer.digits).toString(16).padStart(2,'0')});
    if(isHand)subs.push({tag:TAG.pivot,flag:1,pivotX:asset.pivotX,pivotY:asset.pivotY});
    return {tag:isHand?TAG.hand:isNumber?TAG.number:TAG.image,subs};
  }
  for(const scene of scenes){
    const raw={name:scene.name,resources,screens:[{tag:TAG.main,subs:[{tag:TAG.name,text:scene.name},thumbnail(scene.mainThumb),...scene.main.map(node)]},
      {tag:TAG.aod,subs:[thumbnail(scene.aodThumb),...scene.aod.map(node)]}]};
    const bin=buildBin(toLegacy(fromLegacy(raw).doc)),parsed=parseBin(bin);assertFlashable(bin);assert.deepEqual(buildBin(parsed),bin);
    let decodedBytes=0;
    for(const asset of parsed.resources){const p=decodePixels(asset);assert(p);decodedBytes+=p.length;}
    const treeEnd=39+(bin[37]|bin[38]<<8),resourcesEnd=bin.length-36;
    assert.equal(rawCRC32(bin.subarray(treeEnd,resourcesEnd)),u32(bin,32));
    const head=new Uint8Array(32+treeEnd-36);head.set(bin.subarray(4,36));head.set(bin.subarray(36,treeEnd),32);assert.equal(rawCRC32(head),u32(bin,0));
    assert.equal(u32(bin,24),bin.length-36);assert.equal(u32(bin,28),resourcesEnd-treeEnd);
    const {doc}=fromLegacy(parsed);assert.deepEqual(doc.screens.map(s=>s.kind),['main','aod']);
    const main=doc.screens[0].layers,sources=[...new Set(main.map(l=>l.meta?.source).filter(Boolean))].sort((a,b)=>a-b);
    assert.deepEqual(sources,[...scene.expectedSources].sort((a,b)=>a-b),scene.theme+' live sources');
    assert(main.some(l=>[1,4,10,11,14].includes(l.meta?.source)),scene.theme+' has no live clock');
    for(const layer of scene.main.filter(l=>l.type==='hand'))assert(Number.isInteger(layer.cx)&&Number.isInteger(layer.cy));
    if(scene.hasDate)assert(main.some(l=>[23,24].includes(l.meta?.source)));
    fs.writeFileSync(path.join(out,scene.filename),bin);
    const sha256=crypto.createHash('sha256').update(bin).digest('hex');
    const variant=Object.fromEntries(Object.entries(scene).filter(([k])=>!['main','aod','mainThumb','aodThumb'].includes(k)));
    variant.sha256=sha256;variant.shadowCount=scene.main.filter(l=>l.type==='hand'&&l.key.endsWith('-shadow')).length;variant.group='expanded';
    const existing=variants.findIndex(v=>v.theme===scene.theme);
    const previousVariant=existing<0?null:variants[existing];
    if(existing<0)variants.push(variant);else variants[existing]=variant;
    let old=null;const reportPath=path.join(out,scene.validationFile);try{old=JSON.parse(fs.readFileSync(reportPath));}catch{}
    if(!old&&previousVariant?.validationFile){try{old=JSON.parse(fs.readFileSync(path.join(out,previousVariant.validationFile)));}catch{}}
    const report={...variant,target:'CMF Watch Pro 2',resolution:[466,466],bytes:bin.length,decodedRgbaBytes:decodedBytes,
      checks:{byteExactRoundTrip:true,headerAndResourceCrc:true,allAssetsDecoded:true,maxImageSide:466,previewsOnBothScreens:true,nativeSources:sources,artworkSupersampling:4},
      hardware:old?.sha256===sha256?old.hardware:{connected:false,uploaded:false,verifiedOnWatch:false},
      ...(old?.sha256===sha256&&old?.browserRendering?{browserRendering:old.browserRendering}:{}),
      ...(old?.previousRevisionHardware?{previousRevisionHardware:old.previousRevisionHardware}:{}),
      ...(old?.sha256!==sha256&&old?.hardware?.uploaded?{previousRevisionHardware:{revision:old.revision,sha256:old.sha256,...old.hardware}}:{})};
    fs.writeFileSync(reportPath,JSON.stringify(report,null,2)+'\n');results.push({theme:scene.theme,bytes:bin.length,resources:parsed.resources.length,sources});
  }
}
assert.equal(new Set(variants.map(v=>v.theme)).size,variants.length);assert.equal(new Set(variants.map(v=>dialId(v.seed))).size,variants.length);
if(selectedTheme){
  assert.equal(results.length,1,'The requested face was not found');
  for(const [theme,sha] of original)if(theme!==selectedTheme)assert.equal(variants.find(v=>v.theme===theme).sha256,sha,'Unselected face changed');
}
for(const theme of ['white','black','casio','braun-subdials','skagen'])assert.equal(variants.find(v=>v.theme===theme).sha256,original.get(theme),'Existing face changed');
fs.writeFileSync(path.join(out,'variants.json'),JSON.stringify(variants,null,2)+'\n');
if(path.basename(here)!=='source'){
  for(const name of ['build-expanded.mjs','native_face_art.py','generate-classics.py','generate-digitals.py','generate-radial-native.py','generate-radial-lite.py','generate-weather-zenith.py','zenith_photo.py','generate-photo-dials.py','photo_hands.py','photo_calendar.py']){
    if(fs.existsSync(path.join(here,name)))fs.copyFileSync(path.join(here,name),path.join(out,'source',name));
  }
}
console.log(JSON.stringify(results,null,2));
