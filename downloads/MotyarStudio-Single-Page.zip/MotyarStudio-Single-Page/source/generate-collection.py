"""Three code-drawn CMF faces. All live elements are exported as native widgets."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageFilter,ImageChops,ImageColor
import math,json,re,xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parent
OUT=HERE.parent if HERE.name=='source' else HERE.parent/'outputs/braun-round'
ASSETS=OUT/'collection-assets';ASSETS.mkdir(exist_ok=True)
S=4;FONT='/System/Library/Fonts/HelveticaNeue.ttc'
BOLD='/System/Library/Fonts/Supplemental/Arial Bold.ttf'
NARROW='/System/Library/Fonts/Supplemental/Arial Narrow.ttf'
manifest={};scenes=[]
# One layout drives the recessed circles, tick marks, native pivots and checks.
SUBDIALS={'minute':[154,183],'hour24':[312,183],'second':[233,336],'radius':60,'arrangement':'triangle'}
SKAGEN_SUBDIALS={'minute':[137,233],'hour24':[233,137],'second':[233,329],'radius':59,'arrangement':'cardinal'}
def canvas(w,h,c=(0,0,0,0)):
    im=Image.new('RGBA',(w*S,h*S),c);return im,ImageDraw.Draw(im)
def line(d,pts,c,w=1):d.line([(round(x*S),round(y*S)) for x,y in pts],fill=c,width=max(1,round(w*S)))
def ellipse(d,box,c=None,outline=None,w=1):d.ellipse(tuple(round(v*S) for v in box),fill=c,outline=outline,width=max(1,round(w*S)))
def rect(d,box,c,outline=None,w=1,r=0):
    box=tuple(round(v*S) for v in box)
    if r:d.rounded_rectangle(box,radius=round(r*S),fill=c,outline=outline,width=max(1,round(w*S)))
    else:d.rectangle(box,fill=c,outline=outline,width=max(1,round(w*S)))
def poly(d,pts,c):d.polygon([(round(x*S),round(y*S)) for x,y in pts],fill=c)
def text(d,xy,t,size,c='#252722',font=FONT):
    d.text(tuple(round(v*S) for v in xy),str(t),font=ImageFont.truetype(font,round(size*S)),fill=c,anchor='mm')
def tracked(d,xy,t,size,c,spacing=1.5,font=FONT):
    f=ImageFont.truetype(font,round(size*S));width=sum(d.textlength(ch,font=f) for ch in t)+spacing*S*(len(t)-1)
    x=xy[0]*S-width/2
    for ch in t:
        d.text((round(x),round(xy[1]*S)),ch,font=f,fill=c,anchor='lm');x+=d.textlength(ch,font=f)+spacing*S
def save(key,im,cf=5,**geometry):
    im=im.resize((im.width//S,im.height//S),Image.Resampling.LANCZOS)
    if cf==4:
        px=im.load();bayer=((0,8,2,10),(12,4,14,6),(3,11,1,9),(15,7,13,5))
        for y in range(im.height):
            for x in range(im.width):
                r,g,b,a=px[x,y];n=(bayer[y%4][x%4]-7.5)/16
                px[x,y]=tuple(max(0,min(255,round(v+n*step))) for v,step in [(r,7.8),(g,3.8),(b,7.8)])+(a,)
    im.save(ASSETS/f'{key}.png');(ASSETS/f'{key}.rgba').write_bytes(im.tobytes())
    manifest[key]={'w':im.width,'h':im.height,'cf':cf,**geometry};return im
def surface(dark=False):
    small=Image.new('RGBA',(466,466));px=[]
    for y in range(466):
        for x in range(466):
            dx=(x-233)/233;dy=(y-233)/233;r=math.hypot(dx,dy);light=(-dx-dy)*.5
            v=31+light*10-r*r*2 if dark else 245+light*5-r*r*4
            px.append(tuple(max(0,min(255,round(v+a))) for a in (0,.4,-1))+(255,))
    small.putdata(px);return small.resize((466*S,466*S),Image.Resampling.BICUBIC)
def roundface(key,im):
    mask=Image.new('L',im.size);ImageDraw.Draw(mask).ellipse((0,0,466*S-1,466*S-1),fill=255)
    bg=Image.new('RGBA',im.size,'black');bg.paste(im,(0,0),mask);return save(key,bg,4)
def braun_logo(im,xy=(233,97),w=80):
    src=Image.open(OUT/'source/braun-logo-official.png').convert('RGBA').getchannel('A');src=src.crop(src.getbbox())
    h=round(w*S*src.height/src.width);alpha=src.resize((round(w*S),h),Image.Resampling.LANCZOS)
    logo=Image.new('RGBA',alpha.size,'#20221d');logo.putalpha(alpha)
    im.alpha_composite(logo,(round(xy[0]*S-w*S/2),round(xy[1]*S-h/2)))
def skagen_logo(im,xy=(338,237),w=96):
    # Original wordmark outlines, including DENMARK, from the brand's warranty cover.
    alpha=Image.open(OUT/'source/skagen-logo-original.png').convert('RGBA').getchannel('A')
    alpha=alpha.crop(alpha.getbbox());h=round(w*S*alpha.height/alpha.width)
    alpha=alpha.resize((round(w*S),h),Image.Resampling.LANCZOS)
    mark=Image.new('RGBA',alpha.size,'#e1e5dd');mark.putalpha(alpha)
    im.alpha_composite(mark,(round(xy[0]*S-w*S/2),round(xy[1]*S-h/2)))
def tick(d,t,cx,cy,r0,r1,c,w=1,den=60):
    a=t*math.tau/den;line(d,[(cx+math.sin(a)*r0,cy-math.cos(a)*r0),(cx+math.sin(a)*r1,cy-math.cos(a)*r1)],c,w)
def well(im,cx,cy,r,dark=False):
    # Broad, directional occlusion on the inside wall, with a soft lower lip.
    # This shades a recess rather than outlining it with two hard semicircles.
    patch,_=canvas(r*2+4,r*2+4);pixels=[]
    global_light=(-(cx-233)-(cy-233))/466
    for yy in range(patch.height):
        for xx in range(patch.width):
            dx=(xx+.5)/S-r-2;dy=(yy+.5)/S-r-2;rr=math.hypot(dx,dy);depth=r-rr
            if depth<0:pixels.append((0,0,0,0));continue
            light=-(dx+dy)/max(rr,1)/math.sqrt(2)
            base=(29+global_light*8) if dark else (242+global_light*4)
            shade=(15 if dark else 35)*math.exp(-depth/5.7)*(.63+.37*light)
            lip=(8 if dark else 12)*math.exp(-((depth-.7)/.65)**2)*max(0,-light)
            v=base-shade+lip+(-dx-dy)/r*(.7 if dark else 1)
            pixels.append(tuple(max(0,min(255,round(v+c))) for c in (0,.5,-.7))+(255,))
    patch.putdata(pixels);im.alpha_composite(patch,(round((cx-r-2)*S),round((cy-r-2)*S)))
def subdial(im,cx,cy,r,label,den=60,dark=False):
    well(im,cx,cy,r,dark);d=ImageDraw.Draw(im);ink='#d9dfd1' if dark else '#252923'
    for n in range(0,den,5 if den==60 else 2):tick(d,n,cx,cy,r-9,r-5,ink,1.1,den)
    marks=[(0,'60'),(20,'20'),(40,'40')] if den==60 else [(0,'24'),(8,'08'),(16,'16')]
    for n,s in marks:
        a=n*math.tau/den;text(d,(cx+math.sin(a)*(r-19),cy-math.cos(a)*(r-19)),s,10.5*r/48,ink)
    if den!=24:text(d,(cx,cy+18*r/48),label,10.5*r/48,ink)
def art(key,x,y,source=0,frames=None,conditions=None):
    return {'type':'image','key':key,'x':x,'y':y,'source':source,'frames':frames or [key],**({'conditions':conditions} if conditions else {})}
def pointer(key,cx,cy,source,maxval=60):return {'type':'hand','key':key,'cx':cx,'cy':cy,'source':source,'max':maxval}
def number(keys,x,y,source,digits=2):return {'type':'number','keys':keys,'x':x,'y':y,'source':source,'digits':digits}

def hand(key,tip,width,color,style='plain',shadow=True):
    w=80 if tip>70 else 40;h=round(tip+104);h+=h%2;piv=round(tip+38);x=w/2
    im,d=canvas(w,h);mask=Image.new('L',im.size);md=ImageDraw.Draw(mask)
    if style=='second':
        line(md,[(x,piv-tip),(x,piv+22)],255,width)
        md.rounded_rectangle(tuple(round(v*S) for v in (x-3,piv+4,x+3,piv+23)),radius=round(3*S),fill=255)
        ellipse(md,(x-8,piv-8,x+8,piv+8),255)
    elif style=='rounded':rect(md,(x-width/2,piv-tip,x+width/2,piv+8),255,r=width/2)
    else:rect(md,(x-width/2,piv-tip,x+width/2,piv+8),255)
    layer=Image.new('RGBA',im.size,color);layer.putalpha(mask);im.alpha_composite(layer);d=ImageDraw.Draw(im)
    if style=='hollow':
        rect(d,(x-width*.23,piv-tip+5,x+width*.23,piv-13),'#dedfd7',r=1)
        line(d,[(x-width/2+.25,piv-tip+.5),(x-width/2+.25,piv+7)],'#747a6f',.45)
    elif style=='rounded':
        rect(d,(x-width*.22,piv-tip+5,x+width*.22,piv-12),'#eef0e7',r=1.3)
        line(d,[(x-width/2+.4,piv-tip+5),(x-width/2+.4,piv+5)],'#f6f8ee',.55)
    elif style=='second':
        ellipse(d,(x-7.8,piv-7.8,x+7.8,piv+7.8),None,'#f8e398',.65)
        ellipse(d,(x-1.7,piv-1.7,x+1.7,piv+1.7),'#8c7334')
        ellipse(d,(x-.6,piv-.8,x+.7,piv+.4),'#fff2bd')
    if tip<=70 and key.startswith(('braun-sub-','skagen-')):
        # The spindle and both needles share this exact exported native pivot.
        ellipse(d,(x-3.1,piv-3.1,x+3.1,piv+3.1),color)
        ellipse(d,(x-1,piv-1,x+1,piv+1),'#aeb4a6')
    save(key,im,pivotX=w/2,pivotY=piv)
    if shadow:
        sh=Image.new('RGBA',im.size,(0,0,0,0));large=tip>70
        broad=mask.filter(ImageFilter.GaussianBlur((7.2 if large else 2.8)*S)).point(lambda a:round(a*(.60 if large else .35)))
        contact=mask.filter(ImageFilter.GaussianBlur((2.7 if large else 1)*S)).point(lambda a:round(a*.10))
        sh.putalpha(ImageChops.add(broad,contact));save(key+'-shadow',sh,pivotX=w/2,pivotY=piv,offsetX=3 if large else 1,offsetY=7 if large else 2)

def clock_layers(prefix,cx=233,cy=233):
    result=[]
    for key,src in [('hour',10),('minute',14),('second',114)]:
        result.extend([pointer(prefix+key+'-shadow',cx,cy,src),pointer(prefix+key,cx,cy,src)])
    return result
def hour24_frames(prefix,color):
    keys=[]
    for hour in range(24):
        im,d=canvas(80,80);a=hour*math.tau/24
        pts=[(40-math.sin(a)*4,40+math.cos(a)*4),(40+math.sin(a)*31,40-math.cos(a)*31)]
        shadow,_=canvas(80,80);sd=ImageDraw.Draw(shadow)
        line(sd,[(x+1,y+2) for x,y in pts],(0,0,0,95),2)
        ellipse(sd,(38,39,44,45),(0,0,0,95));im.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(2.3*S)))
        d=ImageDraw.Draw(im);line(d,pts,color,2)
        ellipse(d,(37,37,43,43),color);key=f'{prefix}-24h-{hour}';save(key,im);keys.append(key)
    return keys

def subdial_layers(prefix,frames,layout=SUBDIALS):
    mx,my=layout['minute'];hx,hy=layout['hour24'];sx,sy=layout['second']
    return [pointer(prefix+'small-min-shadow',mx,my,14),pointer(prefix+'small-min',mx,my,14),
        art(frames[0],hx-40,hy-40,4,frames),pointer(prefix+'small-sec-shadow',sx,sy,114),pointer(prefix+'small-sec',sx,sy,114)]

def hub_shadow(key):
    im,d=canvas(80,84);ellipse(d,(28,29,52,53),(0,0,0,100))
    save(key,im.filter(ImageFilter.GaussianBlur(8*S)))

# Braun subdials: current minute / 24h / seconds rather than a simulated stopwatch.
im=surface();d=ImageDraw.Draw(im)
for i in range(60):tick(d,i,233,233,205 if i%5==0 else 211,226,'#252722',2.8 if i%5==0 else 1)
for h in range(1,13):
    a=h*math.tau/12;text(d,(233+math.sin(a)*184,233-math.cos(a)*184),h,31,'#22251e')
braun_logo(im,(233,98),83)
for name,label,den in [('minute','min',60),('hour24','24h',24),('second','sec',60)]:subdial(im,*SUBDIALS[name],SUBDIALS['radius'],label,den)
# Rotated frame is static; the date text is a 32-frame native day picker.
date,d=canvas(56,56);rect(d,(10,11,44,51),'#c6c9bf')
for yy in range(13,50):
    for xx in range(12,43):
        v=248-30*math.exp(-(yy-13)/7)-15*math.exp(-(xx-12)/4)
        rect(d,(xx,yy,xx+1,yy+1),tuple([round(v)]*2+[round(v-5),255]))
line(d,[(11,50),(11,12),(43,12)],'#929b89',.8);line(d,[(12,50),(43,50),(43,13)],'#ffffff',1)
tab=[(8,7),(27,10),(46,7),(46,15),(27,18),(8,15)]
tabsh,td=canvas(56,56);poly(td,[(x+.8,y+2.4) for x,y in tab],(0,0,0,68))
date.alpha_composite(tabsh.filter(ImageFilter.GaussianBlur(1.7*S)));d=ImageDraw.Draw(date)
poly(d,tab,'#ce1622');line(d,[(8.4,7.5),(27,10.5),(45.6,7.5)],'#f15b53',.6);line(d,[(8,15),(27,18),(46,15)],'#a00814',.6)
# Center lies on the 4-o'clock ray and is equidistant from the 24h and seconds wells.
DATE_CENTER=(333,291);DATE_ORIGIN=(DATE_CENTER[0]-28,DATE_CENTER[1]-28)
date=date.rotate(-30,resample=Image.Resampling.BICUBIC,center=(28*S,28*S));im.alpha_composite(date,(DATE_ORIGIN[0]*S,DATE_ORIGIN[1]*S))
roundface('braun-sub-dial',im)
datekeys=[]
for day in range(32):
    frame,d=canvas(56,56)
    if day:text(d,(27,32),f'{day:02d}',22,'#252923')
    frame=frame.rotate(-30,resample=Image.Resampling.BICUBIC,center=(28*S,28*S))
    key=f'braun-sub-date-{day}';save(key,frame);datekeys.append(key)
for name,tip,width,color,style in [('hour',118,9,'#20241d','hollow'),('minute',173,7,'#161b15','hollow'),('second',190,1.6,'#e1ad1b','second')]:hand('braun-sub-'+name,tip,width,color,style)
hand('braun-sub-small-min',36,2.3,'#252b23');hand('braun-sub-small-sec',36,2.1,'#252b23')
h24=hour24_frames('braun-sub','#252b23')
hub_shadow('braun-sub-hub-shadow')
braun_layers=[art('braun-sub-dial',0,0),art(datekeys[0],*DATE_ORIGIN,23,datekeys),
    *subdial_layers('braun-sub-',h24),art('braun-sub-hub-shadow',196,197),*clock_layers('braun-sub-')]

# Skagen: aligned subdials, applied silver indices, gold seconds and tracked lettering.
im=surface(True);d=ImageDraw.Draw(im)
for i in range(60):
    major=i%5==0
    if i in (0,15,30,45):continue
    tick(d,i,233,233,204 if major else 220,225,'#10160f',5 if major else 2)
    tick(d,i,232.3,232.1,204 if major else 220,225,'#bfc8b8',3.5 if major else 1.7)
    if major:tick(d,i,232.0,231.8,205,224,'#f0f3e7',.8)
for hour in (3,6,9,12):
    angle=hour*math.tau/12;text(d,(233+math.sin(angle)*202,233-math.cos(angle)*202),str(hour),36,'#dce2d5')
for name,label,den in [('minute','min',60),('hour24','24h',24),('second','sec',60)]:subdial(im,*SKAGEN_SUBDIALS[name],SKAGEN_SUBDIALS['radius'],label,den,True)
skagen_logo(im)
roundface('skagen-dial',im)
for name,tip,width,color,style in [('hour',115,8,'#adb5a6','rounded'),('minute',173,7,'#adb5a6','rounded'),('second',193,1.3,'#d9c687','second')]:hand('skagen-'+name,tip,width,color,style)
hand('skagen-small-min',31,1.7,'#d5c18a');hand('skagen-small-sec',31,1.6,'#d5c18a')
sk24=hour24_frames('skagen','#d5c18a')
hub_shadow('skagen-hub-shadow')
skagen_layers=[art('skagen-dial',0,0),*subdial_layers('skagen-',sk24,SKAGEN_SUBDIALS),art('skagen-hub-shadow',196,197),*clock_layers('skagen-')]

# The supplied vector has M/L/H/V/C/Z paths. Rasterize its outlines at 4x,
# including holes, so the native logo never comes from an enlarged bitmap.
def casio_logo(im,cx,cy,w):
    root=ET.parse(OUT/'source/casio-logo.svg').getroot();tokens=re.findall(r'[A-Za-z]|[-+]?(?:\d*\.\d+|\d+)(?:[eE][-+]?\d+)?',root.find('.//{*}path').attrib['d'])
    mask=Image.new('1',(round(298*S),round(56.4*S)));contour=[];p=(0,0);start=p;i=0;cmd=None
    def finish():
        nonlocal mask,contour
        if contour:
            part=Image.new('1',mask.size);ImageDraw.Draw(part).polygon([((x+210)*S,(y-414.59367)*S) for x,y in contour],fill=1)
            mask=ImageChops.logical_xor(mask,part);contour=[]
    while i<len(tokens):
        if tokens[i].isalpha():cmd=tokens[i];i+=1
        upper=cmd.upper();relative=cmd.islower()
        if upper=='Z':finish();p=start;cmd=None;continue
        count={'M':2,'L':2,'H':1,'V':1,'C':6}[upper];vals=list(map(float,tokens[i:i+count]));i+=count
        if upper in ('M','L'):
            q=(vals[0]+(p[0] if relative else 0),vals[1]+(p[1] if relative else 0))
            if upper=='M':finish();start=q;cmd='l' if relative else 'L'
            contour.append(q);p=q
        elif upper in ('H','V'):
            p=(vals[0]+(p[0] if relative else 0),p[1]) if upper=='H' else (p[0],vals[0]+(p[1] if relative else 0));contour.append(p)
        else:
            a,b,q=[(vals[j]+(p[0] if relative else 0),vals[j+1]+(p[1] if relative else 0)) for j in (0,2,4)]
            for n in range(1,25):
                t=n/24;u=1-t;contour.append(tuple(u**3*p[k]+3*u*u*t*a[k]+3*u*t*t*b[k]+t**3*q[k] for k in (0,1)))
            p=q
    finish();mask=mask.convert('L');mask=mask.crop(mask.getbbox());h=round(w*S*mask.height/mask.width)
    mask=mask.resize((w*S,h),Image.Resampling.LANCZOS);logo=Image.new('RGBA',mask.size,'#e0e5d7');logo.putalpha(mask)
    im.alpha_composite(logo,(round(cx*S-w*S/2),round(cy*S-h/2)))

# Casio's LCD-like segment artwork: every digit is a native time/date binding.
LCD='#a7ad99';LCDINK='#161c15'
segments={0:'ab cdef'.replace(' ',''),1:'bc',2:'abged',3:'abgcd',4:'fgbc',5:'afgcd',6:'afgecd',7:'abc',8:'abcdefg',9:'abfgcd'}
def digitset(prefix,w,h):
    keys=[]
    for n in range(10):
        im,d=canvas(w,h);mx=3;my=3;t=max(2.5,w*.14);mid=h/2
        hs=lambda yy:[(mx+t*.6,yy-t/2),(w-mx-t*.6,yy-t/2),(w-mx,yy),(w-mx-t*.6,yy+t/2),(mx+t*.6,yy+t/2),(mx,yy)]
        vs=lambda xx,y0,y1:[(xx,y0),(xx+t/2,y0+t*.6),(xx+t/2,y1-t*.6),(xx,y1),(xx-t/2,y1-t*.6),(xx-t/2,y0+t*.6)]
        shapes={'a':hs(my+t/2),'g':hs(mid),'d':hs(h-my-t/2),'f':vs(mx+t/2,my+t,mid-t*.6),
            'b':vs(w-mx-t/2,my+t,mid-t*.6),'e':vs(mx+t/2,mid+t*.6,h-my-t),'c':vs(w-mx-t/2,mid+t*.6,h-my-t)}
        for name,shape in shapes.items():poly(d,shape,LCDINK if name in segments[n] else '#969f88')
        key=f'{prefix}-{n}';save(key,im);keys.append(key)
    return keys
big=digitset('casio-big',42,77);small=digitset('casio-seconds',27,54);calendar=[]
for n in range(10):
    im,d=canvas(13,22);text(d,(6.5,11),str(n),21,LCDINK,NARROW)
    key=f'casio-calendar-{n}';save(key,im);calendar.append(key)
im=surface(True);d=ImageDraw.Draw(im)
# A circular chassis with a full-width LCD band following the round chord.
ellipse(d,(9,9,457,457),'#464d43');ellipse(d,(12,12,454,454),'#2d342a')
casio_logo(im,233,56,122);d=ImageDraw.Draw(im)
tracked(d,(233,86),'WORLD TIME',11,'#afbba5',2,BOLD)
tracked(d,(141,109),'LOCAL',9,'#c5cfb7',1.6,BOLD)
d=ImageDraw.Draw(im)
ellipse(d,(70,122,212,264),'#151d13');ellipse(d,(72,124,210,262),'#697561');ellipse(d,(75,127,207,259),'#394331')
ellipse(d,(93,145,189,241),LCD);line(d,[(94,193),(188,193)],'#535f47',.6);line(d,[(141,146),(141,240)],'#535f47',.6)
ellipse(d,(107,159,175,227),None,'#535f47',.6)
for n in range(60):tick(d,n,141,193,61 if n%5==0 else 64,67,'#d5dbc9',1.7 if n%5==0 else .7)
for n in range(0,60,5):
    a=n*math.tau/60;text(d,(141+math.sin(a)*55,193-math.cos(a)*55),f'{n or 60:02d}',9,'#d7ddcc',NARROW)
rect(d,(232,118,400,146),'#141d12',r=6);rect(d,(235,121,397,143),LCD,r=4)
tracked(d,(316,132),'AMS',17,LCDINK,3,BOLD)
rect(d,(232,154,400,264),'#141d12',r=7);rect(d,(235,157,397,261),LCD,r=5)
# Natural Earth coastlines and the Amsterdam reticle use the same projection.
world,wd=canvas(160,100,LCD)
project=lambda lon,lat:(4+(lon+180)*152/360,4+(85-lat)*79/145)
for feature in json.loads((OUT/'source/ne_110m_land.geojson').read_text())['features']:
    geom=feature['geometry'];polygons=[geom['coordinates']] if geom['type']=='Polygon' else geom['coordinates']
    for rings in polygons:
        for index,ring in enumerate(rings):poly(wd,[project(lon,lat) for lon,lat in ring],'#4d5e42' if index==0 else LCD)
for lon in (-120,-60,0,60,120):
    xx,_=project(lon,0)
    for yy in range(3,84,3):rect(wd,(xx,yy,xx+.35,yy+.35),'#77876b')
for lat in (-30,0,30,60):
    _,yy=project(0,lat)
    for xx in range(4,157,3):rect(wd,(xx,yy,xx+.35,yy+.35),'#77876b')
rect(wd,(0,84,160,100),LCD)
target_lon,target_lat=4.9041,52.3676;tx,ty=project(target_lon,target_lat)
ellipse(wd,(tx-4.2,ty-4.2,tx+4.2,ty+4.2),LCD);ellipse(wd,(tx-3,ty-3,tx+3,ty+3),None,LCDINK,.9)
for pts in [[(tx-7,ty),(tx-3.5,ty)],[(tx+3.5,ty),(tx+7,ty)],[(tx,ty-7),(tx,ty-3.5)],[(tx,ty+3.5),(tx,ty+7)]]:line(wd,pts,LCDINK,.8)
ellipse(wd,(tx-1,ty-1,tx+1,ty+1),LCDINK)
tracked(wd,(80,94),'AMSTERDAM',7.5,LCDINK,1.2,BOLD)
im.alpha_composite(world,(236*S,158*S));d=ImageDraw.Draw(im)
rect(d,(66,276,400,310),'#141d12',r=6);rect(d,(69,279,397,307),LCD,r=4)
line(d,[(206,280),(206,306)],'#78866c',.7);text(d,(324,293),'-',18,LCDINK)
# Intersect the LCD with a circle, preserving a consistent margin at the bottom.
panel,_=canvas(466,466,LCD);mask=Image.new('L',panel.size);md=ImageDraw.Draw(mask)
ellipse(md,(15,15,451,451),255);band=Image.new('L',panel.size);bd=ImageDraw.Draw(band);rect(bd,(0,319,466,411),255)
mask=ImageChops.multiply(mask,band);panel.putalpha(mask);im.alpha_composite(panel);d=ImageDraw.Draw(im)
line(d,[(37,318),(429,318)],'#141d12',2)
tracked(d,(233,432),'ILLUMINATOR',10,'#c8d0bd',1.9,BOLD)
roundface('casio-dial',im)
weekday=[]
for wd,name in enumerate(['SUN','MON','TUE','WED','THU','FRI','SAT']):
    im,d=canvas(61,22);tracked(d,(30.5,11),name,17,LCDINK,.8,BOLD);key=f'casio-weekday-{wd}';save(key,im);weekday.append(key)
ampm=[]
for key,name in [('casio-am','AM'),('casio-pm','PM'),('casio-24','24H')]:
    im,d=canvas(27,14);text(d,(13.5,7),name,10,LCDINK,BOLD);save(key,im);ampm.append(key)
im,d=canvas(10,77)
for y in (25,54):rect(d,(2,y-3,8,y+3),LCDINK,r=1)
save('casio-colon',im)
for name,tip,width in [('hour',29,3),('minute',44,2),('second',48,1)]:hand('casio-'+name,tip,width,'#232b1e',shadow=False)
casio_layers=[art('casio-dial',0,0),pointer('casio-hour',141,193,10),pointer('casio-minute',141,193,14),pointer('casio-second',141,193,114),
    art(weekday[0],101,282,24,weekday),number(calendar,278,282,21),number(calendar,344,282,23),
    number(big,92,326,1),art('casio-colon',184,326),number(big,202,326,11),number(small,300,349,15),
    art(ampm[0],357,333,19,ampm[:2],conditions=[{'source':20,'value':0}]),art('casio-24',357,333,conditions=[{'source':20,'value':1}])]

# Compact always-on screens with previews, matching the native stock-face structure.
def aod(prefix,digital=False):
    im,d=canvas(466,466,'black')
    if digital:
        text(d,(233,165),'CASIO',20,'#969f8b',BOLD);keys=[]
        for n in range(10):
            glyph=Image.open(ASSETS/f'{big[n]}.png').convert('RGBA')
            alpha=glyph.getchannel('A');rgb=Image.new('RGBA',glyph.size,'#a2ab96')
            # Retain only active dark segments so AOD has no LCD ghost array.
            gp=glyph.load();mask=Image.new('L',glyph.size);mask.putdata([255 if gp[x,y][0]<70 and gp[x,y][3]>120 else 0 for y in range(glyph.height) for x in range(glyph.width)])
            rgb.putalpha(mask);key=f'casio-aod-{n}';save(key,rgb.resize((42*S,77*S),Image.Resampling.LANCZOS));keys.append(key)
        im2,dd=canvas(10,77)
        for yy in (25,54):rect(dd,(2,yy-3,8,yy+3),'#a2ab96',r=1)
        save('casio-aod-colon',im2);roundface(prefix+'-aod-dial',im)
        return [art(prefix+'-aod-dial',0,0),number(keys,144,205,1),art('casio-aod-colon',228,205),number(keys,246,205,11)]
    for n in range(0,60,5):tick(d,n,233,233,214,224,'#68715e',1.2)
    for h in (12,3,6,9):
        aa=h*math.tau/12;text(d,(233+math.sin(aa)*181,233-math.cos(aa)*181),h,25,'#8a957e')
    roundface(prefix+'-aod-dial',im)
    hand(prefix+'-aod-hour',115,3.3,'#a7b09b',shadow=False);hand(prefix+'-aod-minute',169,2.3,'#a7b09b',shadow=False)
    return [art(prefix+'-aod-dial',0,0),pointer(prefix+'-aod-hour',233,233,10),pointer(prefix+'-aod-minute',233,233,14)]

scenes=[
 {'theme':'casio','name':'Casio World','filename':'casio-world.bin','seed':'cmf-casio-world-v1','kind':'digital','description':'Circular LCD time and calendar, a live analogue clock and AMS map target for Amsterdam.','main':casio_layers,'aod':aod('casio',True),'dateBox':{'x':100,'y':281,'w':271,'h':24},'digitalLayout':{'ampm':[357,333,27,14],'hours':[92,326,84,77],'lcdCircle':[233,233,218],'lcdBand':[319,411]},'mapTarget':{'label':'AMS','name':'Amsterdam','longitude':target_lon,'latitude':target_lat,'pixel':[236+tx,158+ty],'fixed':True},'hasDate':True,'preview':'casio-preview.png','validationFile':'casio-validation.json'},
 {'theme':'braun-subdials','name':'Braun Subdials','filename':'braun-subdials.bin','seed':'cmf-braun-subdials-v1','kind':'subdials','revision':4,'description':'Ivory dial, aligned subdial spindles, a lower seconds well and a centered four-o’clock date.','main':braun_layers,'aod':aod('braun-sub'),'dateBox':{'x':304,'y':262,'w':58,'h':58},'subdialLayout':SUBDIALS,'hasDate':True,'preview':'braun-subdials-preview.png','validationFile':'braun-subdials-validation.json'},
 {'theme':'skagen','name':'Skagen Dark','filename':'skagen-dark.bin','seed':'cmf-skagen-dark-v1','kind':'subdials','revision':4,'description':'Larger subdials at 12, 9 and 6, original Skagen wordmark, four outer hour numerals and gold seconds.','main':skagen_layers,'aod':aod('skagen'),'subdialLayout':SKAGEN_SUBDIALS,'hasDate':False,'preview':'skagen-preview.png','validationFile':'skagen-validation.json'}]

def value(source,h,m,s,day,wd=4):return {0:0,1:h,4:h,10:(h%12)*5+m/12,11:m,14:m+s/60,15:s,19:int(h>=12),20:1,21:1,23:day,24:wd,114:s}.get(source,0)
def compose(scene,screen='main',h=10,m=8,s=35,day=29):
    result=Image.new('RGBA',(466,466),'black')
    for layer in scene[screen]:
        if any(value(c['source'],h,m,s,day)!=c['value'] for c in layer.get('conditions',[])):continue
        v=value(layer.get('source',0),h,m,s,day)
        if layer['type']=='hand':
            a=manifest[layer['key']];sprite=Image.open(ASSETS/(layer['key']+'.png'));full=Image.new('RGBA',(466,466))
            full.alpha_composite(sprite,(233-round(a['pivotX']),233-a['pivotY']))
            full=full.rotate(-v/layer.get('max',60)*360,resample=Image.Resampling.BICUBIC,center=(233,233))
            shifted=Image.new('RGBA',(466,466));shifted.alpha_composite(full,(layer['cx']-233+a.get('offsetX',0),layer['cy']-233+a.get('offsetY',0)));result.alpha_composite(shifted)
        elif layer['type']=='number':
            x=layer['x']
            for ch in f'{round(v):0{layer["digits"]}d}':
                sprite=Image.open(ASSETS/(layer['keys'][int(ch)]+'.png'));result.alpha_composite(sprite,(x,layer['y']));x+=sprite.width
        else:
            frames=layer['frames'];key=frames[int(v)%len(frames)];result.alpha_composite(Image.open(ASSETS/(key+'.png')),(layer['x'],layer['y']))
    return result
for scene in scenes:
    for screen,file in [('main',scene['preview']),('aod',scene['theme']+'-aod-preview.png')]:
        im=compose(scene,screen);im.save(OUT/file);key=scene['theme']+'-'+screen+'-thumb'
        save(key,im.resize((270*S,270*S),Image.Resampling.LANCZOS),4);scene[screen+'Thumb']=key
(ASSETS/'manifest.json').write_text(json.dumps(manifest,indent=2))
(ASSETS/'scenes.json').write_text(json.dumps(scenes,indent=2))
print('Generated three native-face scenes and',len(manifest),'assets.')
