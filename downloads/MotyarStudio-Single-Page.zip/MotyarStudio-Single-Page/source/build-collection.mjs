import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const out=path.basename(here)==='source'?path.resolve(here,'..'):path.resolve(here,'../outputs/braun-round');
const engine=path.join(out,'engine/editor/core');
const {encodePixels,decodePixels}=await import(path.join(engine,'format/pixels-codec.js'));
const {parseBin,buildBin,assertFlashable,rawCRC32}=await import(path.join(engine,'format/bin.js'));
const {TAG,u32}=await import(path.join(engine,'format/raw.js'));
const {fromLegacy,toLegacy}=await import(path.join(engine,'document/doc.js'));
const {buildBind}=await import(path.join(engine,'document/sources.js'));
const manifest=JSON.parse(fs.readFileSync(path.join(out,'collection-assets/manifest.json')));
const scenes=JSON.parse(fs.readFileSync(path.join(out,'collection-assets/scenes.json')));
const resources=[],ids={};
for(const [key,{w,h,cf}] of Object.entries(manifest)){
  ids[key]=resources.length;
  const pixels=new Uint8ClampedArray(fs.readFileSync(path.join(out,'collection-assets',key+'.rgba')));
  resources.push(encodePixels(pixels,w,h,cf));
}
const meta=(w=0,h=0,source=0,max=0)=>{
  const b=new Uint8Array(14),v=new DataView(b.buffer);
  v.setUint16(0,w,true);v.setUint16(2,h,true);b[9]=source;b[11]=max;b[12]=max>>8;b[13]=max>>16;
  return Buffer.from(b).toString('hex');
};
const thumbnail=key=>({tag:TAG.preview,subs:[{tag:TAG.pvStruct,prefix:'0000000000',refType:0x61,images:[ids[key]]}]});
function node(layer){
  const isHand=layer.type==='hand',isNumber=layer.type==='number';
  const key=layer.key??layer.keys?.[0],asset=manifest[key];
  const frames=isNumber?layer.keys:layer.frames??[key];
  const x=isHand?layer.cx-asset.pivotX+(asset.offsetX??0):layer.x;
  const y=isHand?layer.cy-asset.pivotY+(asset.offsetY??0):layer.y;
  const isBackground=asset.w===466&&asset.h===466;
  const max=isHand?layer.max??60:({1:24,11:60,15:60,21:12,23:31}[layer.source]??0);
  const subs=[{tag:TAG.struct,x,y,meta:meta(isBackground?466:0,isBackground?466:0,layer.source??0,max),refType:0x61,images:frames.map(k=>ids[k])}];
  if(layer.conditions?.length)subs.push({tag:TAG.bind,hex:buildBind(layer.conditions.map(c=>({id:c.source,op:1,val:c.value})))});
  if(isNumber)subs.push({tag:TAG.fmt,hex:(0x80|layer.digits).toString(16)});
  if(isHand)subs.push({tag:TAG.pivot,flag:1,pivotX:asset.pivotX,pivotY:asset.pivotY});
  return {tag:isHand?TAG.hand:isNumber?TAG.number:TAG.image,subs};
}
let variants=JSON.parse(fs.readFileSync(path.join(out,'variants.json'))).map(v=>{
  if(!['white','black'].includes(v.theme))return v;
  return {seed:v.theme==='black'?'braun-black-pro2-v2':'braun-round-pro2-v1',kind:'classic',
    description:v.theme==='black'?'A charcoal dial with silver-white hands, yellow seconds and a larger recessed date window.':
      'A softly shaded white dial, floating black hands, yellow seconds and a larger recessed date window.',
    preview:v.theme==='black'?'black-preview.png':'preview.png',aodPreview:'aod-preview.png',
    validationFile:v.theme==='black'?'black-validation.json':'validation.json',hasDate:true,
    dateBox:{x:220,y:342,w:26,h:28},shadowCount:3,...v};
});
const results=[];
for(const scene of scenes){
  const raw={name:scene.name,resources,screens:[{tag:TAG.main,subs:[{tag:TAG.name,text:scene.name},thumbnail(scene.mainThumb),...scene.main.map(node)]},
    {tag:TAG.aod,subs:[thumbnail(scene.aodThumb),...scene.aod.map(node)]}]};
  const packed=toLegacy(fromLegacy(raw).doc),bin=buildBin(packed),parsed=parseBin(bin);
  assert.deepEqual(buildBin(parsed),bin);assertFlashable(bin);
  let decodedBytes=0;
  for(const asset of parsed.resources){
    assert(asset.w<=466&&asset.h<=466);const pixels=decodePixels(asset);assert(pixels);decodedBytes+=pixels.length;
  }
  const treeEnd=39+(bin[37]|bin[38]<<8),resourcesEnd=bin.length-36;
  assert.equal(rawCRC32(bin.subarray(treeEnd,resourcesEnd)),u32(bin,32));
  const headerAndTree=new Uint8Array(32+treeEnd-36);headerAndTree.set(bin.subarray(4,36));headerAndTree.set(bin.subarray(36,treeEnd),32);
  assert.equal(rawCRC32(headerAndTree),u32(bin,0));assert.equal(u32(bin,24),bin.length-36);
  assert.equal(u32(bin,28),resourcesEnd-treeEnd);
  const {doc}=fromLegacy(parsed);
  assert.deepEqual(doc.screens.map(s=>s.kind),['main','aod']);
  const main=doc.screens[0].layers;
  const sources=[...new Set(main.filter(l=>l.meta?.source).map(l=>l.meta.source))].sort((a,b)=>a-b);
  const expected=scene.kind==='digital'?[1,10,11,14,15,19,21,23,24,114]:scene.hasDate?[4,10,14,23,114]:[4,10,14,114];
  assert.deepEqual(sources,expected);
  if(scene.kind==='subdials'){
    const hour24=main.find(l=>l.kind==='image'&&l.meta.source===4);assert.equal(hour24.frames.length,24);
    const layout=scene.subdialLayout;
    if(layout.arrangement==='cardinal'){
      assert.deepEqual(layout.hour24,[233,137]);assert.deepEqual(layout.minute,[137,233]);assert.deepEqual(layout.second,[233,329]);
    }else{
      assert.equal(layout.minute[1],layout.hour24[1]);
      assert.equal((layout.minute[0]+layout.hour24[0])/2,233);assert.equal(layout.second[0],233);
    }
    assert.equal(hour24.x+40,layout.hour24[0]);assert.equal(hour24.y+40,layout.hour24[1]);
    for(const [name,source] of [['minute',14],['second',114]]){
      const [x,y]=layout[name];assert(main.some(l=>l.kind==='hand'&&l.meta.source===source&&l.x+l.pivotX===x&&l.y+l.pivotY===y));
    }
    const distance=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
    if(scene.theme==='braun-subdials'){
      assert.deepEqual(layout.second,[233,336]);
      const center=[scene.dateBox.x+29,scene.dateBox.y+29];
      assert(Math.abs(distance(center,layout.hour24)-distance(center,layout.second))<1,'Date is not equidistant between chrono wells');
      assert(Math.abs((center[0]-233)/(center[1]-233)-Math.sqrt(3))<.04,'Date is not aligned with four o’clock');
    }
    const date=main.find(l=>l.kind==='image'&&l.meta.source===23);if(scene.hasDate)assert.equal(date.frames.length,32);
    for(const layer of main.filter(l=>l.kind==='hand'))assert(Number.isInteger(layer.x+layer.pivotX)&&Number.isInteger(layer.y+layer.pivotY));
  }else{
    assert.equal(main.find(l=>l.kind==='image'&&l.meta.source===24).frames.length,7);
    assert.equal(main.find(l=>l.kind==='image'&&l.meta.source===19).frames.length,2);
    assert(main.some(l=>l.conditions?.some(c=>c.source===20&&c.value===0)));
    const [cx,cy,radius]=scene.digitalLayout.lcdCircle;
    for(const layer of scene.main.filter(l=>l.y>=scene.digitalLayout.lcdBand[0])){
      for(const key of layer.keys??layer.frames??[]){
        const {w,h}=manifest[key],pixels=fs.readFileSync(path.join(out,'collection-assets',key+'.rgba'));
        for(let y=0;y<h;y++)for(let x=0;x<w;x++)if(pixels[(y*w+x)*4+3]>32){
          assert((layer.x+x-cx)**2+(layer.y+y-cy)**2<=radius**2,`Clipped LCD glyph: ${key}`);
        }
      }
    }
  }
  fs.writeFileSync(path.join(out,scene.filename),bin);
  const sha256=crypto.createHash('sha256').update(bin).digest('hex');
  const shadowCount=scene.main.filter(l=>l.type==='hand'&&l.key.endsWith('-shadow')).length;
  const variant={theme:scene.theme,name:scene.name,filename:scene.filename,seed:scene.seed,kind:scene.kind,description:scene.description,
    preview:scene.preview,aodPreview:scene.theme+'-aod-preview.png',validationFile:scene.validationFile,hasDate:scene.hasDate,
    ...Object.fromEntries(['dateBox','subdialLayout','digitalLayout','mapTarget'].filter(k=>scene[k]).map(k=>[k,scene[k]])),shadowCount,sha256,revision:scene.revision??2};
  variants=variants.filter(v=>v.theme!==scene.theme);variants.push(variant);
  const oldPath=path.join(out,scene.validationFile);let old=null;try{old=JSON.parse(fs.readFileSync(oldPath));}catch{}
  const report={...variant,target:'CMF Watch Pro 2',resolution:[466,466],bytes:bin.length,decodedRgbaBytes:decodedBytes,
    checks:{byteExactRoundTrip:true,headerAndResourceCrc:true,allAssetsDecoded:true,maxImageSide:466,previewsOnBothScreens:true,nativeSources:sources,
      live24hImageFrames:scene.kind==='subdials'?24:0,nativeClockSubdials:scene.kind==='subdials',
      ...(scene.kind==='subdials'?{alignedSubdialGeometry:true}:{}),artworkSupersampling:4,
      ...(scene.kind==='digital'?{allDigitalGlyphsInsideCircularLcd:true}:{}),
      mainHandWidgets:main.filter(l=>l.kind==='hand').length},
    knownDevice:{firmware:'1.0.0.73'},hardware:old?.sha256===sha256?old.hardware:{connected:false,uploaded:false,verifiedOnWatch:false},
    ...(old?.previousRevisionHardware?{previousRevisionHardware:old.previousRevisionHardware}:{}),
    ...(old?.sha256===sha256&&old?.browserRendering?{browserRendering:old.browserRendering}:{}),
    ...(old?.sha256!==sha256&&old?.hardware?.uploaded?{previousRevisionHardware:{revision:old.revision,sha256:old.sha256,...old.hardware}}:{})};
  fs.writeFileSync(oldPath,JSON.stringify(report,null,2)+'\n');results.push({theme:scene.theme,bytes:bin.length,resources:parsed.resources.length,sources});
}
fs.writeFileSync(path.join(out,'variants.json'),JSON.stringify(variants,null,2)+'\n');
if(path.basename(here)!=='source'){
  fs.copyFileSync(fileURLToPath(import.meta.url),path.join(out,'source/build-collection.mjs'));
  fs.copyFileSync(path.join(here,'generate-collection.py'),path.join(out,'source/generate-collection.py'));
}
console.log(JSON.stringify(results,null,2));
