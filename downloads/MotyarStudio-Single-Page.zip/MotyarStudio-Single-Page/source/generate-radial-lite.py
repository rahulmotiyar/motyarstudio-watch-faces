"""Lighter radial experiment using one continuous seconds rotor.

Generated independently from the three-rotor trial; hour/minute images are
pre-rendered to avoid native affine rotation on those two large layers.
This reduces geometric rotation work, not a measured hardware frame rate.

Original architecture:

Clockwise rotation is intentional: no unverified reverse flag is sent to the
watch. Fixed native HH/MM/SS values remain legible above the rotating rings.
This is a separate face/seed; it does not replace the anticlockwise frame face.
"""
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import math
import native_face_art as A

A.configure('radial-lite')
S=A.S
theme='radial-lite'
center=233
ink='#adbece'

base=Image.new('RGBA',(466,466));pixels=[]
for y in range(466):
    for x in range(466):
        dx=x-center;dy=y-center;r=math.hypot(dx,dy);light=-(dx+dy)/330
        value=(24 if r>=181 else 20 if r>=113 else 17)+light*3.5
        for boundary in (113,181):
            if r<boundary:value-=8*math.exp(-(boundary-r)/5)*(.65+.35*max(0,light))
        if r>228:value-=7*(r-228)/5
        pixels.append(tuple(max(0,min(255,round(value+c))) for c in (-1,1,5))+(255,))
base.putdata(pixels);base=base.resize((466*S,466*S),Image.Resampling.BICUBIC)
d=ImageDraw.Draw(base)
for radius in (113,181):A.ellipse(d,(233-radius,233-radius,233+radius,233+radius),None,'#34424f',.55)
for label,size,index,cy in [('motyar',18,1,222),('studios',16,7,244)]:
    f=ImageFont.truetype(A.FONT,round(size*S),index=index)
    left,top,right,bottom=d.textbbox((0,0),label,font=f)
    d.text((233*S-(left+right)/2,cy*S-(top+bottom)/2),label,font=f,fill=ink)
A.roundface(theme+'-dial',base)

def ring(name,size,numeral_radius,tick0,tick1,count,step,color,font_size,stepped=False):
    sprite,draw=A.canvas(size,size);cx=cy=size/2
    for value in range(count):
        # Descending physical layout brings the current value to 3 o'clock
        # when the native hand rotates clockwise by its clock angle.
        angle=-value*math.tau/count;degrees=math.degrees(angle)
        major=value%step==0;inner=tick0 if major else tick0+3
        A.line(draw,[(cx+math.cos(angle)*inner,cy+math.sin(angle)*inner),
                     (cx+math.cos(angle)*tick1,cy+math.sin(angle)*tick1)],color,1.8 if major else .85)
        if major:
            label=12 if name=='hours' and value==0 else value
            glyph,gd=A.canvas(56,36);A.text(gd,(28,18),f'{label:02d}',font_size,color,index=10)
            # Printed text follows the physical ring and is upright as it
            # crosses the fixed reading index at 3 o'clock.
            glyph=glyph.rotate(-degrees,resample=Image.Resampling.BICUBIC,expand=True)
            gx=(cx+math.cos(angle)*numeral_radius)*S;gy=(cy+math.sin(angle)*numeral_radius)*S
            sprite.alpha_composite(glyph,(round(gx-glyph.width/2),round(gy-glyph.height/2)))
    radius=tick1-3
    A.ellipse(draw,(cx+radius-2,cy-2,cx+radius+2,cy+2),'#6ca9c8')
    key=theme+'-'+name+'-rotor'
    if stepped:
        keys=[]
        for state in range(count):
            frame=sprite.rotate(-state*360/count,resample=Image.Resampling.BICUBIC,center=(cx*S,cy*S))
            state_key=key+'-'+str(state);A.save(state_key,frame);keys.append(state_key)
        return keys
    # The outer markings fit within 456px; trim five blank pixels on each side.
    sprite=sprite.crop((5*S,5*S,(size-5)*S,(size-5)*S));cx-=5;cy-=5
    A.save(key,sprite,pivotX=round(cx),pivotY=round(cy))
    return key

hour=ring('hours',228,88,99,107,12,1,'#8fa4b7',14,stepped=True)
minute=ring('minutes',360,143,168,176,60,5,'#8fa4b7',15,stepped=True)
second=ring('seconds',466,199,216,225,60,5,'#96aabd',14)

# An opaque, stationary readout covers the passing markings. The glass-like
# highlights are decorative; this does not pretend to refract moving pixels.
window,wd=A.canvas(180,60)
shadow,sd=A.canvas(180,60);A.rect(sd,(6,11,178,59),(0,0,0,70),r=11)
window.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(2*S)))
for y in range(48*S):
    t=y/(48*S-1);v=32-10*t
    ImageDraw.Draw(window).line((4*S,8*S+y,176*S,8*S+y),fill=(round(v-4),round(v+3),round(v+9),255))
mask=Image.new('L',window.size);A.rect(ImageDraw.Draw(mask),(4,8,176,56),255,r=10)
window.putalpha(mask);wd=ImageDraw.Draw(window)
A.rect(wd,(4,8,176,56),None,(135,167,191,115),.65,r=10)
A.line(wd,[(16,9),(164,9)],(222,237,247,95),.7)
A.line(wd,[(15,54.5),(165,54.5)],(132,173,198,45),.6)
for x in (64,120):A.line(wd,[(x,17),(x,48)],(137,165,187,45),.6)
A.save(theme+'-fixed-readout',window)

hours=A.labels(theme+'-hour-readout',[f'{12 if h==0 else h:02d}' for h in range(12)],64,48,28,'#e5f1fa',index=10)
minutes=A.labels(theme+'-minute-readout',[f'{m:02d}' for m in range(60)],64,48,28,'#e5f1fa',index=10)
seconds=A.labels(theme+'-second-readout',[f'{s:02d}' for s in range(60)],64,48,28,'#e5f1fa',index=10)
aod=A.aod(theme,True)
aod_hours=A.labels(theme+'-aod-hours',[f'{12 if h==0 else h:02d}' for h in range(12)],58,60,52,'#a4aea0')
aod[1]=A.art(aod_hours[0],163,201,4,aod_hours)

scene={'theme':theme,'name':'MotyarStudio Radial Lite (Test)','kind':'digital','revision':1,
    'description':'Lighter experimental trial: only the seconds ring requests continuous native rotation; hour and minute rings step once per hour/minute. Rings turn clockwise, with a fixed upright time window. Intended to reduce the pauses reported with three rotating rings; smoothness still needs a watch test.',
    'main':[A.art(theme+'-dial',0,0),A.art(hour[0],119,119,4,hour),A.art(minute[0],53,53,11,minute),A.pointer(second,233,233,0x12),
            A.art(theme+'-fixed-readout',284,201),A.art(hours[0],289,209,4,hours),A.art(minutes[0],344,209,11,minutes),A.art(seconds[0],400,209,15,seconds)],
    'aod':aod,'hasDate':False,'supportsSeconds':True,'expectedSources':[4,11,15,18],
    'hourFormat':'12-hour disc','experimental':True,
    'clockRegions':{'hours':[301,217,40,34],'minutes':[356,217,40,34],'seconds':[412,217,40,34]},
    'nativeRotatingDiscs':{'direction':'clockwise','center':[233,233],
        'hours':{'source':4,'size':228,'zeroMarkerRadius':104,'periodHours':12,'widget':'picker','frames':12},
        'minutes':{'source':11,'size':360,'zeroMarkerRadius':173,'periodMinutes':60,'widget':'picker','frames':60},
        'seconds':{'source':18,'size':456,'zeroMarkerRadius':222,'periodSeconds':60},
        'readout':'fixed upright native values','reverseRotationVerified':False,'hardwareVerified':False,
        'cadence':'one native smooth seconds rotor; hour/minute image pickers step once per hour/minute',
        'continuousRotatingPixels':456*456,'previousContinuousRotatingPixels':228*228+360*360+466*466,'continuousRotatingAreaReduction':1-(456*456)/(228*228+360*360+466*466)},
    'readingLens':{'style':'fixed readout with decorative glass highlights','runtimeRefraction':False,'precomputedRefraction':False,'bounds':[288,209,172,48]}}
A.finish([scene])
