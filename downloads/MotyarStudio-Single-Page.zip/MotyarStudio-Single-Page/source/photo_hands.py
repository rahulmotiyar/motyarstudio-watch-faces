"""Polished native moving parts for photo dials; importing writes nothing.

All functions receive a configured native_face_art-compatible ``a`` object.
``make_hand`` and ``make_subhand`` register ``key`` and ``key + '-shadow'``
with integer native pivots. The shadow resource has fixed dial-space offsets.
They return a small geometry descriptor; the caller chooses clock sources and
positions with a.pointer(). ``make_cap`` registers one centered sprite and
returns ``(key, half_size)``; place it at ``(cx-half_size, cy-half_size)``.
No function modifies the supplied dial photograph.
"""

import math
from PIL import Image, ImageDraw, ImageFilter, ImageChops


PALETTES = {
    'silver': {
        'edge': (15, 25, 32), 'shade': (54, 74, 87),
        'mid': (135, 159, 173), 'bright': (247, 252, 255),
        'lume': (247, 245, 225),
    },
    'gold': {
        'edge': (47, 31, 13), 'shade': (104, 72, 29),
        'mid': (192, 153, 83), 'bright': (255, 239, 184),
        'lume': (255, 249, 220),
    },
    'rose': {
        'edge': (49, 29, 25), 'shade': (104, 66, 57),
        'mid': (194, 142, 121), 'bright': (255, 231, 215),
        'lume': (250, 244, 223),
    },
    'dark': {
        'edge': (3, 10, 16), 'shade': (9, 22, 31),
        'mid': (33, 53, 67), 'bright': (128, 155, 170),
        'lume': (238, 241, 222),
    },
}


def _lerp(first, second, amount):
    amount = min(1, max(0, amount))
    return tuple(round(x + (y-x)*amount) for x, y in zip(first, second))


def _palette(metal):
    if metal not in PALETTES:
        raise ValueError('Unknown hand metal: ' + str(metal))
    return PALETTES[metal]


def _metal_plane(a, size, center_x, width, palette):
    """Two lengthwise facets, with a sharp polished ridge to the left."""
    plane = Image.new('RGBA', size)
    draw = ImageDraw.Draw(plane)
    for xx in range(size[0]):
        u = max(-1, min(1, (xx/a.S-center_x)/max(.8, width*.56)))
        if u < -.12:
            color = _lerp(palette['shade'], palette['bright'], (u+1)/.88)
        else:
            color = _lerp(palette['mid'], palette['shade'], (u+.12)/1.12)
        draw.line((xx, 0, xx, size[1]), fill=color+(255,))
    return plane


def _fill_metal(a, mask, center_x, width, palette, edge=.52):
    out = Image.new('RGBA', mask.size, palette['edge']+(255,))
    out.putalpha(mask)
    erosion = 2*max(1, round(edge*a.S))+1
    inner = mask.filter(ImageFilter.MinFilter(erosion))
    metal = _metal_plane(a, mask.size, center_x, width, palette)
    metal.putalpha(inner)
    out.alpha_composite(metal)
    return out


def _bezier(first, c1, c2, last, steps=18):
    result = []
    for n in range(steps+1):
        t=n/steps;u=1-t
        result.append((u**3*first[0]+3*u*u*t*c1[0]+3*u*t*t*c2[0]+t**3*last[0],
                       u**3*first[1]+3*u*u*t*c1[1]+3*u*t*t*c2[1]+t**3*last[1]))
    return result


def make_hand(a, key, tip, width, metal='silver', style='chrono', second=False):
    """Create a faceted hand plus a separately registered fixed-offset shadow.

    ``tip`` is pivot-to-tip in native pixels. ``width`` is the nominal shaft
    width. Styles are chrono, sport, leaf or subdial. A sport resource ending
    in ``'-hour'`` receives a Mercedes disc; sport seconds receive a lollipop.
    The returned pivot is also stored in a.manifest by a.save().
    """
    palette = _palette(metal)
    tip = round(tip)
    if not 4 <= tip <= 330 or not .5 <= width <= 30:
        raise ValueError('Hand dimensions outside supported native geometry')
    if style not in ('chrono', 'sport', 'leaf', 'subdial'):
        raise ValueError('Unknown hand style: ' + str(style))
    w=max(48, 2*math.ceil(width*2.2+16))
    pivot_x=w//2;pivot_y=tip+24;top=24
    tail=22 if second else (4 if style=='subdial' else 10)
    h=pivot_y+tail+24
    if h%2:h+=1
    if max(w,h)>466:raise ValueError('Hand resource exceeds native image limit')
    mask=Image.new('L',(w*a.S,h*a.S));md=ImageDraw.Draw(mask)
    mercedes = style=='sport' and key.endswith('-hour') and not second
    circle_y=pivot_y-tip*.70
    circle_r=max(5.6,width*.93)

    if second:
        a.line(md,[(pivot_x,top),(pivot_x,pivot_y+tail)],255,width+.65)
        if style=='sport':
            y=pivot_y-tip*.80
            a.ellipse(md,(pivot_x-3.1,y-3.1,pivot_x+3.1,y+3.1),255)
        elif style!='leaf':
            a.rect(md,(pivot_x-1.7,pivot_y+7,pivot_x+1.7,pivot_y+tail),255,r=.7)
    elif style=='subdial':
        a.poly(md,[(pivot_x,top),(pivot_x+width*.55,top+5),
                   (pivot_x+width*.45,pivot_y+tail),(pivot_x-width*.45,pivot_y+tail),
                   (pivot_x-width*.55,top+5)],255)
    elif mercedes:
        a.poly(md,[(pivot_x,top),(pivot_x+width*.46,top+17),
                   (pivot_x+width*.32,pivot_y+tail),(pivot_x-width*.32,pivot_y+tail),
                   (pivot_x-width*.46,top+17)],255)
        a.ellipse(md,(pivot_x-circle_r,circle_y-circle_r,pivot_x+circle_r,circle_y+circle_r),255)
    elif style=='leaf':
        points=_bezier((pivot_x,top),(pivot_x+width*.78,top+tip*.30),
                       (pivot_x+width*.58,pivot_y-tip*.24),(pivot_x,pivot_y+tail))
        points+=_bezier((pivot_x,pivot_y+tail),(pivot_x-width*.58,pivot_y-tip*.24),
                        (pivot_x-width*.78,top+tip*.30),(pivot_x,top))
        a.poly(md,points,255)
    else:
        a.poly(md,[(pivot_x,top),(pivot_x+width*.48,top+10),
                   (pivot_x+width*.45,pivot_y-19),(pivot_x+width*.27,pivot_y+tail),
                   (pivot_x-width*.27,pivot_y+tail),(pivot_x-width*.45,pivot_y-19),
                   (pivot_x-width*.48,top+10)],255)

    out=_fill_metal(a,mask,pivot_x,width,palette,edge=.32 if second or style=='subdial' else .52)
    detail=Image.new('RGBA',mask.size);dd=ImageDraw.Draw(detail)
    if second:
        a.line(dd,[(pivot_x-.18,top+2),(pivot_x-.18,pivot_y-4)],palette['bright']+(235,),max(.4,width*.42))
        if style=='sport':
            y=pivot_y-tip*.80
            a.ellipse(dd,(pivot_x-2,y-2,pivot_x+2,y+2),palette['lume']+(255,))
    elif mercedes:
        inset_r=circle_r*.69
        a.ellipse(dd,(pivot_x-inset_r,circle_y-inset_r,pivot_x+inset_r,circle_y+inset_r),palette['lume']+(255,))
        for angle in (-90,30,150):
            radians=math.radians(angle)
            a.line(dd,[(pivot_x,circle_y),(pivot_x+math.cos(radians)*inset_r,circle_y+math.sin(radians)*inset_r)],palette['shade']+(255,),1.1)
        if circle_y-circle_r-4>top+13:
            a.line(dd,[(pivot_x,top+13),(pivot_x,circle_y-circle_r-4)],palette['lume']+(255,),max(1,width*.30))
        a.line(dd,[(pivot_x,circle_y+circle_r+4),(pivot_x,pivot_y-16)],palette['lume']+(255,),max(1,width*.30))
    elif style!='subdial' and tip>60:
        inset=max(1.1,width*(.23 if style=='leaf' else .35))
        a.rect(dd,(pivot_x-inset/2,top+16,pivot_x+inset/2,pivot_y-23),palette['lume']+(255,),r=.45)
        a.line(dd,[(pivot_x-width*.35,top+12),(pivot_x-width*.35,pivot_y-21)],palette['bright']+(170,),.32)
    elif style=='subdial':
        a.line(dd,[(pivot_x-.2,top+4),(pivot_x-.2,pivot_y-2)],palette['bright']+(200,),.35)
    detail.putalpha(ImageChops.multiply(detail.getchannel('A'),mask));out.alpha_composite(detail)
    a.save(key,out,pivotX=pivot_x,pivotY=pivot_y)

    shadow=Image.new('RGBA',mask.size)
    blur=1.2 if style=='subdial' else 3.5
    shadow.putalpha(mask.filter(ImageFilter.GaussianBlur(blur*a.S)).point(lambda value:round(value*.32)))
    offset_y=2 if style=='subdial' else 3
    a.save(key+'-shadow',shadow,pivotX=pivot_x,pivotY=pivot_y,offsetX=1,offsetY=offset_y)
    return {'key':key,'shadowKey':key+'-shadow','pivotX':pivot_x,'pivotY':pivot_y,'w':w,'h':h}


def make_subhand(a,key,tip,metal='silver'):
    """A fine pointed subdial hand; same registration/return contract as make_hand."""
    return make_hand(a,key,tip,1.7,metal,'subdial')


def make_cap(a,key,radius,metal='silver'):
    """Register a low polished pivot stack; return (key, native half-size)."""
    palette=_palette(metal)
    if not 1<=radius<=32:raise ValueError('Pivot cap radius outside supported range')
    half=math.ceil(radius+10);size=half*2
    out=Image.new('RGBA',(size*a.S,size*a.S));od=ImageDraw.Draw(out)
    a.ellipse(od,(half-radius+1,half-radius+2,half+radius+1,half+radius+2),(0,0,0,48))
    out=out.filter(ImageFilter.GaussianBlur(2*a.S))
    mask=Image.new('L',out.size);md=ImageDraw.Draw(mask)
    a.ellipse(md,(half-radius,half-radius,half+radius,half+radius),255)
    plane=Image.new('RGBA',out.size);data=[]
    for yy in range(plane.height):
        for xx in range(plane.width):
            dx=(xx/a.S-half)/radius;dy=(yy/a.S-half)/radius;r=math.hypot(dx,dy)
            directional=max(0,min(1,.50-(dx+dy)*.33))
            if r>.86:color=_lerp(palette['edge'],palette['bright'],directional)
            elif r>.72:color=_lerp(palette['shade'],palette['mid'],directional)
            else:color=_lerp(palette['mid'],palette['bright'],directional*.63)
            data.append(color+(255,))
    plane.putdata(data);plane.putalpha(mask);out.alpha_composite(plane);od=ImageDraw.Draw(out)
    pin=max(.6,min(1.5,radius*.14))
    a.ellipse(od,(half-pin,half-pin,half+pin,half+pin),palette['edge']+(255,))
    a.ellipse(od,(half-pin*.45,half-pin*.70,half+pin*.25,half+pin*.05),palette['bright']+(220,))
    a.save(key,out)
    return key,half
