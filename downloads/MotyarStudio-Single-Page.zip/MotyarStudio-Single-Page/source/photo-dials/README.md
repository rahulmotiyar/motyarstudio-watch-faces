# Selected photographic dials

The current selection contains Submariner Diamond, Daytona Pearl Photo, Chronograph Ivory Photo and Tissot Le Locle. Both Tissot mentions in the selection request refer to Tissot Le Locle. The other ten photographic designs are excluded from the gallery, native collection, artwork and export.

All four dial backgrounds use the supplied image pixels directly: one measured crop and Lanczos fit to 466 × 466, a circular mask and native RGB565 dithering. No AI retouch or drawn substitute dial is used for this selection. Original attachment numbers are retained (01, 09, 13 and 15), with hashes in attachments.json.

layout.json records the source crops and photographed pivots. native-layout.json records exact native pivots, register sources and calendar regions. Live hands and calendar overlays are separate native resources. Chronograph registers display clock readings on their printed scales, rather than an interactive stopwatch.

The four retained native files are unchanged from the validated versions. They passed byte-exact codec round trips, header/resource CRC, full asset decode and browser rendering checks. No physical-watch install was performed for this update.
