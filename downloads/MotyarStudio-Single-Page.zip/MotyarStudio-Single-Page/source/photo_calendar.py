"""Native calendar overlays for the supplied photographic dial plates.

Importing this module does not configure artwork output or write any files.
``build_calendar(a, config, native_background)`` returns native layers, a list
of ``{x, y, w, h}`` readout rectangles, and calendar provenance/geometry.
"""
import math
from PIL import Image, ImageDraw, ImageFont, ImageChops, ImageColor


_WEEKDAYS = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY']


def _mapping(config):
    left, top, right, bottom = config['crop']
    sx, sy = 466 / (right-left), 466 / (bottom-top)
    def point(x, y):
        return (x-left+.5)*sx-.5, (y-top+.5)*sy-.5
    return left, top, sx, sy, point


def _rectangle(config, source_box):
    left, top, sx, sy, _ = _mapping(config)
    x, y, w, h = source_box
    edges = ((x-left)*sx, (y-top)*sy, (x+w-left)*sx, (y+h-top)*sy)
    l, t = max(0, math.floor(edges[0])), max(0, math.floor(edges[1]))
    r, b = min(466, math.ceil(edges[2])), min(466, math.ceil(edges[3]))
    if r <= l or b <= t:
        raise ValueError('Calendar aperture is outside the native dial')
    return {'x': l, 'y': t, 'w': r-l, 'h': b-t}, edges


def _union(boxes):
    if not boxes:
        return None
    x, y = min(b['x'] for b in boxes), min(b['y'] for b in boxes)
    right, bottom = max(b['x']+b['w'] for b in boxes), max(b['y']+b['h'] for b in boxes)
    return {'x': x, 'y': y, 'w': right-x, 'h': bottom-y}


def _font(a, size, index=1):
    return ImageFont.truetype(a.FONT, max(1, round(size*a.S)), index=index)


def _fitted_font(a, labels, preferred, width, height, index=1):
    size = max(6, preferred)
    while True:
        font = _font(a, size, index)
        bounds = [font.getbbox(label) for label in labels if label]
        widest = max((b[2]-b[0] for b in bounds), default=0) / a.S
        tallest = max((b[3]-b[1] for b in bounds), default=0) / a.S
        if size <= 6 or (widest <= width*.88 and tallest <= height*.82):
            return font, size
        size -= .25


def _centered_text(im, label, font, color):
    if not label:
        return
    d = ImageDraw.Draw(im)
    left, top, right, bottom = d.textbbox((0, 0), label, font=font)
    d.text(((im.width-left-right)/2, (im.height-top-bottom)/2), label, font=font, fill=color)


def _rect_mask(a, box, edges):
    mask = Image.new('L', (box['w']*a.S, box['h']*a.S))
    # Fractional source-to-native coverage remains within the measured opening.
    l, t, r, b = edges
    ImageDraw.Draw(mask).rectangle(((l-box['x'])*a.S, (t-box['y'])*a.S,
                                   (r-box['x'])*a.S-.01, (b-box['y'])*a.S-.01), fill=255)
    return mask


def _paper(a, background, box, mask, paper_color=None, arc_depth=None):
    native = background.convert('RGBA').crop((box['x'], box['y'], box['x']+box['w'], box['y']+box['h']))
    paper = native.resize(mask.size, Image.Resampling.BICUBIC)
    if paper_color:
        rgb = ImageColor.getrgb(paper_color)
        pixels = []
        for yy in range(mask.height):
            y = (yy+.5)/a.S
            for xx in range(mask.width):
                x = (xx+.5)/a.S
                if arc_depth:
                    edge = max(0, arc_depth(box['x']+x, box['y']+y))
                    shade = 10*math.exp(-edge/1.4)
                else:
                    shade = 10*math.exp(-x/1.5)+13*math.exp(-y/1.6)
                pixels.append(tuple(max(0, min(255, round(c-shade))) for c in rgb)+(255,))
        paper.putdata(pixels)
    paper.putalpha(mask)
    return paper


def _flat_readout(a, config, background, source_box, labels, prefix, source, size, color, paper_color):
    box, edges = _rectangle(config, source_box)
    mask = _rect_mask(a, box, edges)
    paper = _paper(a, background, box, mask, paper_color)
    font, actual_size = _fitted_font(a, labels, size, box['w'], box['h'])
    frames = []
    for value, label in enumerate(labels):
        im = paper.copy()
        ink = Image.new('RGBA', im.size)
        _centered_text(ink, label, font, color)
        ink.putalpha(ImageChops.multiply(ink.getchannel('A'), mask))
        im.alpha_composite(ink)
        key = f'{prefix}-{value}'
        a.save(key, im)
        frames.append(key)
    return a.art(frames[0], box['x'], box['y'], source, frames), box, actual_size


def _arc_geometry(a, config, arc):
    left, top, sx, sy, point = _mapping(config)
    cx, cy = arc['center']
    start, end = arc['startDegrees'], arc['endDegrees']
    # A small source-space inset protects the original metal/paint lip.
    inset = .3/min(sx, sy)
    inner, outer = arc['innerRadius']+inset, arc['outerRadius']-inset
    sector = []
    for radius, reverse in [(outer, False), (inner, True)]:
        for n in range(161):
            f = (160-n if reverse else n)/160
            angle = math.radians(start+(end-start)*f)
            sector.append(point(cx+radius*math.sin(angle), cy-radius*math.cos(angle)))
    l = max(0, math.floor(min(p[0] for p in sector))-1)
    t = max(0, math.floor(min(p[1] for p in sector))-1)
    r = min(466, math.ceil(max(p[0] for p in sector))+1)
    b = min(466, math.ceil(max(p[1] for p in sector))+1)
    box = {'x': l, 'y': t, 'w': r-l, 'h': b-t}
    mask = Image.new('L', (box['w']*a.S, box['h']*a.S))
    ImageDraw.Draw(mask).polygon([((x-l)*a.S, (y-t)*a.S) for x, y in sector], fill=255)
    def depth(x, y):
        source_x = (x+.5)/sx+left-.5
        source_y = (y+.5)/sy+top-.5
        radius = math.hypot(source_x-cx, source_y-cy)
        return min(radius-inner, outer-radius)*min(sx, sy)
    return box, mask, point, (sx+sy)/2, depth


def _curved_ink(a, text, font, box, arc, point, scale, color):
    im = Image.new('RGBA', (box['w']*a.S, box['h']*a.S))
    tracking = .2
    advances = [font.getlength(ch)/a.S+tracking for ch in text]
    total = sum(advances)-tracking
    radius_native = arc['radius']*scale
    mid_angle = math.radians((arc['startDegrees']+arc['endDegrees'])/2)
    cursor = -total/2
    for ch, advance in zip(text, advances):
        angle = mid_angle+(cursor+(advance-tracking)/2)/radius_native
        cursor += advance
        bounds = font.getbbox(ch)
        width, height = max(1, bounds[2]-bounds[0]), max(1, bounds[3]-bounds[1])
        glyph = Image.new('RGBA', (width+4*a.S, height+4*a.S))
        ImageDraw.Draw(glyph).text((2*a.S-bounds[0], 2*a.S-bounds[1]), ch, font=font, fill=color)
        glyph = glyph.rotate(-math.degrees(angle), resample=Image.Resampling.BICUBIC, expand=True)
        cx, cy = arc['center']
        x, y = point(cx+arc['radius']*math.sin(angle), cy-arc['radius']*math.cos(angle))
        im.alpha_composite(glyph, (round((x-box['x'])*a.S-glyph.width/2), round((y-box['y'])*a.S-glyph.height/2)))
    return im, total/radius_native


def _curved_weekday(a, config, background, calendar):
    arc = calendar['weekdayArc']
    box, mask, point, scale, depth = _arc_geometry(a, config, arc)
    paper = _paper(a, background, box, mask, calendar.get('weekdayPaperColor'), depth)
    _, _, _, sy, _ = _mapping(config)
    size = calendar.get('weekdayFontNative', calendar.get('weekdayFontSize', 22)*sy)
    color = calendar.get('weekdayColor', calendar.get('digitColor', '#17201a'))
    span = math.radians(arc['endDegrees']-arc['startDegrees'])
    while True:
        font = _font(a, size)
        previews = [_curved_ink(a, label, font, box, arc, point, scale, color) for label in _WEEKDAYS]
        outside = ImageChops.invert(mask)
        fits = all(width < span-.035 and ImageChops.multiply(im.getchannel('A'), outside).getextrema()[1] <= 24
                   for im, width in previews)
        if fits or size <= 6:
            break
        size -= .25
    frames = []
    for value, (ink, _) in enumerate(previews):
        ink.putalpha(ImageChops.multiply(ink.getchannel('A'), mask))
        frame = paper.copy()
        frame.alpha_composite(ink)
        key = f"{config['theme']}-calendar-weekday-{value}"
        a.save(key, frame)
        frames.append(key)
    return a.art(frames[0], box['x'], box['y'], 24, frames), box, size


def build_calendar(a, config, native_background):
    """Build day/date native image pickers without repainting photographic bezels.

    ``a`` is the already-configured native_face_art module (or a compatible
    adapter). ``native_background`` is its exact 466×466 photographic dial.
    Every date picker has 32 frames, with frame zero blank; weekday order is
    Sunday through Saturday, matching native sources 23 and 24 respectively.
    """
    calendar = config.get('calendar')
    if not calendar:
        return [], [], {'hasDate': False, 'sources': []}
    if native_background.size != (466, 466):
        raise ValueError('Calendar background must be the native 466×466 dial')
    _, _, sx, sy, _ = _mapping(config)
    layers, boxes, date_boxes = [], [], []
    metadata = {'hasDate': True, 'sources': [], 'dateFrameCount': 32,
                'paperTreatment': 'Photographic aperture pixels retained unless a calendar-wheel paper fill is configured; metal bevels remain outside the masks.'}
    color = calendar.get('digitColor', '#17201a')
    date_sources = calendar.get('bigDateBoxes') or ([calendar['dateBox']] if calendar.get('dateBox') else [])
    date_sizes = []
    for i, source_box in enumerate(date_sources):
        big = bool(calendar.get('bigDateBoxes'))
        labels = ['']+[(f'{day:02d}'[i] if big else str(day)) for day in range(1, 32)]
        native_height = source_box[3]*sy
        size = calendar.get('dateFontNative', calendar.get('dateFontSize', native_height/sy)*sy)
        prefix = config['theme']+('-calendar-date-'+str(i) if big else '-calendar-date')
        layer, box, actual_size = _flat_readout(a, config, native_background, source_box, labels, prefix, 23,
                                                size, color, calendar.get('paperColor'))
        layers.append(layer); boxes.append(box); date_boxes.append(box); date_sizes.append(round(actual_size, 3))
    if date_sources:
        metadata.update(dateBoxes=date_boxes, dateFontNative=date_sizes, dateSource=23,
                        dateMode='zero-padded tens and units of day-of-month' if calendar.get('bigDateBoxes') else 'day-of-month')
        metadata['sources'].append(23)
    if calendar.get('weekdayBox') or calendar.get('weekdayArc'):
        if calendar.get('weekdayArc'):
            layer, box, size = _curved_weekday(a, config, native_background, calendar)
            metadata.update(weekdayLabels=_WEEKDAYS, weekdayLayout='curved full weekday', sourceWeekdayArc=calendar['weekdayArc'])
        else:
            source_box = calendar['weekdayBox']
            labels = [name[:3] for name in _WEEKDAYS]
            size = calendar.get('weekdayFontNative', calendar.get('weekdayFontSize', source_box[3]*.85)*sy)
            layer, box, size = _flat_readout(a, config, native_background, source_box, labels,
                                           config['theme']+'-calendar-weekday', 24, size,
                                           calendar.get('weekdayColor', color), calendar.get('weekdayPaperColor', calendar.get('paperColor')))
            metadata.update(weekdayLabels=labels, weekdayLayout='flat abbreviated weekday')
        layers.append(layer); boxes.append(box)
        metadata.update(weekdayBox=box, weekdayFontNative=round(size, 3), weekdayFrameCount=7, weekdaySource=24)
        metadata['sources'].append(24)
    metadata['unionBox'] = _union(boxes)
    return layers, boxes, metadata
