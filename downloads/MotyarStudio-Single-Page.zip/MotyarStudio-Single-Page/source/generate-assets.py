"""Code-drawn white/black Braun dials, native hands, and world-offset hand shadows."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageColor, ImageChops
import math, json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OUT = ROOT if HERE.name == 'source' else ROOT / 'outputs/braun-round'
ASSETS = OUT / 'assets'
ASSETS.mkdir(parents=True, exist_ok=True)
S = 4
FONT = '/System/Library/Fonts/HelveticaNeue.ttc'
manifest = {}

def canvas(w,h,color=(0,0,0,0)):
    im=Image.new('RGBA',(w*S,h*S),color)
    return im,ImageDraw.Draw(im)
def font(size):return ImageFont.truetype(FONT,round(size*S))
def line(d,points,fill,width):
    d.line([(round(x*S),round(y*S)) for x,y in points],fill=fill,width=round(width*S))
def rect(d,box,fill,outline=None,width=1):
    d.rectangle(tuple(round(v*S) for v in box),fill=fill,outline=outline,width=round(width*S))
def circle(d,box,fill,outline=None,width=1):
    d.ellipse(tuple(round(v*S) for v in box),fill=fill,outline=outline,width=round(width*S))
def text(d,xy,t,size,fill):
    d.text(tuple(round(v*S) for v in xy),t,font=font(size),fill=fill,anchor='mm')

def save(name,im,cf=5,**geometry):
    im=im.resize((im.width//S,im.height//S),Image.Resampling.LANCZOS)
    if cf==4:
        # Dithering keeps subtle gradients smooth after native RGB565 encoding.
        matrix=((0,8,2,10),(12,4,14,6),(3,11,1,9),(15,7,13,5));pixels=im.load()
        for y in range(im.height):
            for x in range(im.width):
                r,g,b,a=pixels[x,y];n=(matrix[y%4][x%4]-7.5)/16
                pixels[x,y]=(max(0,min(255,round(r+n*7.8))),max(0,min(255,round(g+n*3.8))),max(0,min(255,round(b+n*7.8))),a)
    im.save(ASSETS/f'{name}.png');(ASSETS/f'{name}.rgba').write_bytes(im.tobytes())
    manifest[name]={'w':im.width,'h':im.height,'cf':cf,**geometry}
    return im

def gradient(w,h,start,end,horizontal=False):
    a=ImageColor.getrgb(start);b=ImageColor.getrgb(end);small=Image.new('RGBA',(w,h))
    small.putdata([tuple(round(a[k]+(b[k]-a[k])*(x/(w-1) if horizontal else y/(h-1))) for k in range(3))+(255,) for y in range(h) for x in range(w)])
    return small.resize((w*S,h*S),Image.Resampling.BICUBIC)
def paste_mask(im,art,mask,xy=(0,0)):
    layer=art.copy();layer.putalpha(mask);im.alpha_composite(layer,xy)
def logo(im,black):
    # Real Braun wordmark from the official clocks/watches website, using its exact alpha outline.
    src=Image.open(OUT/'source/braun-logo-official.png').convert('RGBA')
    mask=src.getchannel('A');mask=mask.crop(mask.getbbox())
    w=76*S;h=round(w*mask.height/mask.width);mask=mask.resize((w,h),Image.Resampling.LANCZOS)
    art=Image.new('RGBA',(w,h),'#e9ebe7' if black else '#252623');art.putalpha(mask)
    im.alpha_composite(art,((466*S-w)//2,114*S))

def dial(black=False,aod=False):
    im,d=canvas(466,466,'black');key='aod-dial' if aod else ('black-dial' if black else 'dial')
    ink='#eceee9' if black else '#292a27'
    if not aod:
        surface=Image.new('RGBA',(466,466));pixels=[]
        for y in range(466):
            for x in range(466):
                dx=(x-233)/233;dy=(y-233)/233;r=math.hypot(dx,dy);light=(-dx-dy)*.5
                if r>1:
                    edge=15+light*6 if black else 241+light*7
                    rgb=(edge,edge,edge if black else edge-2)
                elif black:
                    v=31+light*10-6*max(0,r-.3)
                    if r<.853:
                        v-=4.5*math.exp(-(.853-r)*233/12)*(.8+.55*light)
                    if r>.85:v=15+light*6
                    v-=4*math.exp(-((r-.852)/.008)**2)
                    grain=(((x*17+y*47)%19)-9)*.075;rgb=(v+grain,v+grain+.6,v+grain+.2)
                else:
                    v=246+light*5.5-5.5*r*r
                    # Broad rim occlusion, strongest along the upper/left inside wall.
                    if r<.853:
                        v-=10*math.exp(-(.853-r)*233/12)*(.8+.55*light)
                    v-=1.8*math.exp(-((r-.849)/.008)**2)*(1+.35*light)
                    if r>.855:v=241+light*7
                    rgb=(v,v+.1,v-2)
                pixels.append(tuple(max(0,min(255,round(c))) for c in rgb)+(255,))
        surface.putdata(pixels);im=surface.resize((466*S,466*S),Image.Resampling.BICUBIC);d=ImageDraw.Draw(im)
        circle(d,(34.5,34.5,431.5,431.5),None,'#111510' if black else '#d8dad4',.45)
        circle(d,(35.6,35.6,430.4,430.4),None,'#333930' if black else '#f9faf5',.45)
    for i in range(60):
        if aod and i%5:continue
        angle=i*math.tau/60;r0=215 if aod else (205 if i%5==0 else 210)
        points=[(233+math.sin(angle)*r0,233-math.cos(angle)*r0),(233+math.sin(angle)*224,233-math.cos(angle)*224)]
        if not aod:line(d,[(x+.45,y+.65) for x,y in points],'#050705' if black else '#ffffff',3.1 if i%5==0 else 1.35)
        line(d,points,'#797b75' if aod else ink,2.7 if i%5==0 else 1.05)
    for h in range(1,13):
        if aod and h not in (3,6,9,12):continue
        a=h*math.tau/12;xy=(233+math.sin(a)*173,233-math.cos(a)*173)
        if not aod:text(d,(xy[0]+.45,xy[1]+.6),str(h),31.5,'#090a08' if black else '#ffffff')
        text(d,xy,str(h),31.5,'#acafa6' if aod else ink)
    if not aod:
        logo(im,black);d=ImageDraw.Draw(im)
        # The Subdials aperture treatment, upright: thin walls, pale recessed paper
        # and its distinctive red chevron. Keep the large date without a raised tile.
        rect(d,(213,329,253,376),'#c6c9bf')
        for yy in range(331,375):
            for xx in range(215,252):
                v=248-12*math.exp(-(yy-331)/8)-7*math.exp(-(xx-215)/4)
                rect(d,(xx,yy,xx+1,yy+1),(round(v),round(v),round(v-5),255))
        line(d,[(214,375),(214,330),(252,330)],'#aeb5a7',.65)
        line(d,[(215,375),(252,375),(252,331)],'#ffffff',.8)
        tab=[(211,323),(233,326.5),(255,323),(255,332),(233,335.5),(211,332)]
        mask=Image.new('L',im.size);md=ImageDraw.Draw(mask);md.polygon([(round(x*S),round(y*S)) for x,y in tab],fill=255)
        tab_shadow=Image.new('RGBA',im.size,(0,0,0,0))
        tab_alpha=ImageChops.offset(mask.filter(ImageFilter.GaussianBlur(1.5*S)),0,1*S).point(lambda a:round(a*.10))
        tab_shadow.putalpha(tab_alpha);im.alpha_composite(tab_shadow)
        red=Image.new('RGBA',im.size,'#ce1622')
        paste_mask(im,red,mask);d=ImageDraw.Draw(im)
        line(d,[(211.7,323.5),(233,327),(254.3,323.5)],'#f15b53',.5)
        line(d,[(211,332),(233,335.5),(255,332)],'#b8131e',.5)
    if not aod:
        edge_mask=Image.new('L',im.size)
        ImageDraw.Draw(edge_mask).ellipse((0,0,466*S-1,466*S-1),fill=255)
        rounded=Image.new('RGBA',im.size,'black');rounded.paste(im,(0,0),edge_mask);im=rounded
    return save(key,im,4)

backgrounds={'white':dial(),'black':dial(True),'aod':dial(aod=True)}

for key,black in [('hub-base',False),('black-hub-base',True)]:
    im,d=canvas(34,38)
    # The central spindle has a lower barrel, a thin polished rim and a dark top face.
    circle(d,(4,7,31,34),'#11140f')
    circle(d,(3,4,30,31),'#92988e' if black else '#545a50')
    circle(d,(3.5,3,29.5,29),'#1b1e17')
    d.arc(tuple(round(v*S) for v in (4.4,3.8,28.4,27.8)),175,285,fill='#c1c6bb' if black else '#838b7d',width=round(.65*S))
    d.arc(tuple(round(v*S) for v in (5,8,29,32)),5,115,fill='#080b07',width=round(1.1*S))
    save(key,im)

im,d=canvas(72,76)
hub_mask=Image.new('L',im.size);hd=ImageDraw.Draw(hub_mask)
circle(hd,(21,19,51,49),255)
im.putalpha(hub_mask.filter(ImageFilter.GaussianBlur(6*S)).point(lambda a:round(a*.22)))
save('hub-shadow',im)

def make_hand(key,w,h,pivot,tip,width,color,tail=9,second=False):
    im,d=canvas(w,h);x=w/2;y=pivot;mask=Image.new('L',im.size);md=ImageDraw.Draw(mask)
    if second:
        line(md,[(x,y-tip),(x,y+29)],255,1.8)
        md.rounded_rectangle(tuple(round(v*S) for v in (x-4.6,y-3,x+4.6,y+28)),radius=round(4.6*S),fill=255)
        circle(md,(x-10.6,y-10.6,x+10.6,y+10.6),255)
        paste_mask(im,gradient(w,h,'#f5ce36','#d49c0a',True),mask);d=ImageDraw.Draw(im)
        circle(d,(x-10.3,y-10.3,x+10.3,y+10.3),None,'#a9770b',.65)
        d.arc(tuple(round(v*S) for v in (x-9.3,y-9.3,x+9.3,y+9.3)),195,315,fill='#ffe774',width=round(.8*S))
        circle(d,(x-2.35,y-2.35,x+2.35,y+2.35),'#9d700b')
        circle(d,(x-1.3,y-1.5,x+1.15,y+.9),'#fff3a8');circle(d,(x-.55,y-.55,x+.65,y+.65),'#7c5d18')
        line(d,[(x-.4,y-tip+1),(x-.4,y-12)],'#ffe378',.4)
    else:
        rect(md,(x-width/2,y-tip,x+width/2,y+tail),255)
        paste_mask(im,gradient(w,h,*color,True),mask);d=ImageDraw.Draw(im)
        line(d,[(x-width/2+.25,y-tip+.4),(x-width/2+.25,y+tail)],'#ffffff' if 'black-' in key else '#71756d',.55)
        line(d,[(x+width/2-.2,y-tip+.4),(x+width/2-.2,y+tail)],'#888e84' if 'black-' in key else '#11130f',.6)
        line(d,[(x-width/2,y-tip),(x+width/2,y-tip)],'#ffffff' if 'black-' in key else '#84877f',.5)
    save(key,im,pivotY=pivot)
    # Native shadow hands use a fixed dial-space offset, so the light does not spin with the art.
    shadow=Image.new('RGBA',im.size,(0,0,0,0))
    # A wide penumbra and a tighter contact shadow reproduce the photographed raised hands.
    blur=4.4 if second else (5.8 if key.endswith('hour') else 7.0)
    soft=mask.filter(ImageFilter.GaussianBlur(blur*S)).point(lambda a:round(a*(.16 if second else .28)))
    contact=mask.filter(ImageFilter.GaussianBlur((1.5 if second else 2.0)*S)).point(lambda a:round(a*(.025 if second else .035)))
    shadow.putalpha(ImageChops.screen(soft,contact))
    dx,dy=(2,3) if second else ((2,4) if key.endswith('hour') else (3,5))
    save(key+'-shadow',shadow,pivotY=pivot,offsetX=dx,offsetY=dy)

for prefix in ['', 'black-']:
    tones=('#f9fbf5','#9ba397') if prefix else ('#555951','#131510')
    make_hand(prefix+'hour',64,192,150,117,7.2,tones)
    make_hand(prefix+'minute',64,238,196,163,5.2,tones)
    make_hand(prefix+'second',70,280,220,187,1.8,None,second=True)
for key,w,h,piv,tip,width in [('aod-hour',12,135,122,115,4.2),('aod-minute',10,181,168,162,3)]:
    im,d=canvas(w,h);rect(d,(w/2-width/2,piv-tip,w/2+width/2,piv+6),'#bfc2b8');save(key,im,pivotY=piv)
im,d=canvas(12,12);circle(d,(1,1,11,11),'#bfc2b8');save('aod-cap',im)
for n in range(10):
    im,d=canvas(17,37);text(d,(8.5,18.5),str(n),29,'#252822');save(f'digit-{n}',im)

def composite(theme='white',h=10,m=8,s=35,day=29):
    aod=theme=='aod';prefix='black-' if theme=='black' else '';result=backgrounds[theme].copy()
    if not aod:
        for i,c in enumerate(f'{day:02d}'):
            result.alpha_composite(Image.open(ASSETS/f'digit-{c}.png'),(216+i*17,337))
        result.alpha_composite(Image.open(ASSETS/'hub-shadow.png'),(200,203))
        result.alpha_composite(Image.open(ASSETS/f'{prefix}hub-base.png'),(216,217))
    for name,deg in [('hour',(h%12)*30+m/2),('minute',m*6+s*.1),('second',s*6)]:
        if aod and name=='second':continue
        key=f'aod-{name}' if aod else prefix+name
        for part in ([key] if aod else [key+'-shadow',key]):
            a=manifest[part];src=Image.open(ASSETS/f'{part}.png');full=Image.new('RGBA',(466,466))
            full.alpha_composite(src,(233-src.width//2,233-a['pivotY']))
            turned=full.rotate(-deg,resample=Image.Resampling.BICUBIC,center=(233,233))
            if part.endswith('-shadow'):
                shifted=Image.new('RGBA',(466,466));shifted.alpha_composite(turned,(a['offsetX'],a['offsetY']));turned=shifted
            result.alpha_composite(turned)
    if aod:result.alpha_composite(Image.open(ASSETS/'aod-cap.png'),(227,227))
    return result

for theme,key,file in [('white','thumb','preview.png'),('black','black-thumb','black-preview.png'),('aod','aod-thumb','aod-preview.png')]:
    im=composite(theme);im.save(OUT/file);thumb=im.resize((270,270),Image.Resampling.LANCZOS)
    save(key,thumb.resize((1080,1080)),4)
(ASSETS/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(f'Generated {len(manifest)} assets, white and black variants, in {ASSETS}')
