"""Eight code-drawn classic dial adaptations, with native clock/date widgets."""
import math
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops, ImageColor
import native_face_art as A

A.configure('classics')
S=A.S
SERIF='/System/Library/Fonts/Supplemental/Times New Roman.ttf'
SERIFB='/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf'
ITALIC='/System/Library/Fonts/Supplemental/Times New Roman Italic.ttf'
COND='/System/Library/Fonts/Supplemental/DIN Condensed Bold.ttf'
scenes=[]

def face_surface(color,edge=16,falloff=10):
    rgb=ImageColor.getrgb(color);im=Image.new('RGBA',(466,466));pixels=[]
    for y in range(466):
        for x in range(466):
            dx=(x-233)/233;dy=(y-233)/233;r=math.hypot(dx,dy);light=-(dx+dy)/math.sqrt(2)
            shade=edge*math.exp(-max(0,1-r)*233/falloff)*(0.8+0.45*light)
            grain=(((x*19+y*31)%23)-11)*.035
            pixels.append(tuple(max(0,min(255,round(v+light*3-shade+grain))) for v in rgb)+(255,))
    im.putdata(pixels);return im.resize((466*S,466*S),Image.Resampling.BICUBIC)

def polar(cx,cy,r,n,den=60):
    a=n*math.tau/den;return (cx+math.sin(a)*r,cy-math.cos(a)*r)

def radial_text(im,t,r,n,den=60,size=12,color='#303b36',font=A.FONT,rotation=True):
    a=n*360/den;A.rotated_text(im,polar(233,233,r,n,den),str(t),size,color,-a if rotation else 0,font)

def custom_hand(key,tip,width,color,style='spear',shadow=True):
    """Padded native sprite; shadow offset stays fixed in dial coordinates."""
    w=80;piv=tip+38;h=tip+104;h+=h%2;x=w/2
    im,d=A.canvas(w,h);mask=Image.new('L',im.size);md=ImageDraw.Draw(mask)
    if style=='spear':
        A.poly(md,[(x,piv-tip),(x+width/2,piv-tip+18),(x+width*.25,piv+13),(x-width*.25,piv+13),(x-width/2,piv-tip+18)],255)
    elif style=='breguet':
        A.poly(md,[(x,piv-tip),(x+width*.45,piv-tip+12),(x+width*.3,piv+13),(x-width*.3,piv+13),(x-width*.45,piv-tip+12)],255)
        A.ellipse(md,(x-6,piv-tip+12,x+6,piv-tip+24),255)
        A.ellipse(md,(x-3.8,piv-tip+14.2,x+3.8,piv-tip+21.8),0)
    elif style=='orange':
        A.poly(md,[(x,piv-tip),(x+width/2,piv-tip+15),(x+width/2,piv-8),(x+2,piv+15),(x-2,piv+15),(x-width/2,piv-8),(x-width/2,piv-tip+15)],255)
    elif style=='xeric':
        A.line(md,[(x,piv-tip),(x,piv+22)],255,1.6)
        A.rect(md,(x-10,piv-tip+8,x+10,piv-18),None,255,1,r=5)
    elif style=='baton':A.rect(md,(x-width/2,piv-tip,x+width/2,piv+8),255)
    elif style=='motyar-second':A.line(md,[(x,piv-tip),(x,piv+32)],255,width)
    elif style=='chrono-second':
        A.line(md,[(x,piv-tip),(x,piv+29)],255,width)
        A.rect(md,(x-3,piv+9,x+3,piv+29),255,r=1.1)
        A.ellipse(md,(x-6.4,piv-6.4,x+6.4,piv+6.4),255)
    else:A.line(md,[(x,piv-tip),(x,piv+22)],255,width)
    layer=Image.new('RGBA',im.size,color);layer.putalpha(mask);im.alpha_composite(layer);d=ImageDraw.Draw(im)
    if style in ('spear','orange'):
        A.line(d,[(x-.5,piv-tip+9),(x-.5,piv-7)],'#f3e4b0' if style=='orange' else '#718079',.45)
    if style=='xeric':A.line(d,[(x,piv-tip+5),(x,piv+21)],'#d78332',1.8)
    if style=='chrono-second':
        A.line(d,[(x-.35,piv-tip+2),(x-.35,piv-7)],'#ec6870',.5)
        A.line(d,[(x-2.4,piv+10),(x-2.4,piv+27)],'#e46b72',.55)
    A.save(key,im,pivotX=x,pivotY=piv)
    if shadow:
        sh=Image.new('RGBA',im.size);alpha=mask.filter(ImageFilter.GaussianBlur((6 if tip>70 else 2.4)*S)).point(lambda v:round(v*.5))
        sh.putalpha(alpha);A.save(key+'-shadow',sh,pivotX=x,pivotY=piv,offsetX=2 if tip>70 else 1,offsetY=5 if tip>70 else 2)

def hand_layers(prefix,cx=233,cy=233,seconds=True):
    ls=[]
    for name,source in [('hour',10),('minute',14)]+([('second',114)] if seconds else []):
        ls.extend([A.pointer(prefix+'-'+name+'-shadow',cx,cy,source),A.pointer(prefix+'-'+name,cx,cy,source)])
    return ls

def cap(prefix,color,size=7,metal=False):
    im,d=A.canvas(80,80);A.ellipse(d,(40-size+2,40-size+5,40+size+2,40+size+5),(0,0,0,110));im=im.filter(ImageFilter.GaussianBlur(5*S));d=ImageDraw.Draw(im)
    rgb=ImageColor.getrgb(color)
    for r in range(round(size*S),0,-1):
        k=(size-r/S)/size;v=tuple(max(0,min(255,round(c+8*k))) for c in rgb)
        A.ellipse(d,(40-r/S,40-r/S,40+r/S,40+r/S),v+(255,))
    if metal:
        A.ellipse(d,(38.2,38.2,41.8,41.8),'#181e1b');A.ellipse(d,(39,38.6,40.2,39.8),'#a8b0a4')
    A.save(prefix+'-cap',im);return A.art(prefix+'-cap',193,193)

def sub(im,cx,cy,r,den=60,marks=None,cream=False,ink='#3c4540',label_size=10.5):
    """Concentric machined well with a diffuse directional inner shadow."""
    patch,d=A.canvas(r*2+4,r*2+4);base=(239,235,214) if cream else (220,225,219)
    data=[]
    for yy in range(patch.height):
        for xx in range(patch.width):
            dx=(xx+.5)/S-r-2;dy=(yy+.5)/S-r-2;rr=math.hypot(dx,dy);dep=r-rr
            if dep<0:data.append((0,0,0,0));continue
            light=-(dx+dy)/max(rr,1)/math.sqrt(2)
            v=25*math.exp(-dep/5)*(.6+.4*light)-6*math.exp(-((dep-.7)/.8)**2)*max(0,-light)
            groove=.6*math.sin(rr*math.tau/1.7)
            data.append(tuple(max(0,min(255,round(b-v+groove))) for b in base)+(255,))
    patch.putdata(data);im.alpha_composite(patch,(round((cx-r-2)*S),round((cy-r-2)*S)));d=ImageDraw.Draw(im)
    for n in range(den):
        if den==24 and n%2:continue
        A.tick(d,n,cx,cy,r-(9 if n%(5 if den==60 else 6)==0 else 6),r-3,ink,1 if n%(5 if den==60 else 6)==0 else .65,den)
    marks=marks or ([(0,'60'),(20,'20'),(40,'40')] if den==60 else [(0,'24'),(6,'06'),(12,'12'),(18,'18')])
    for n,t in marks:
        a=n*math.tau/den;A.text(d,(cx+math.sin(a)*(r-17),cy-math.cos(a)*(r-17)),t,label_size,ink)

def small_pointer(prefix,color,tip=27,width=1.8):
    custom_hand(prefix,tip,width,color,'needle');return prefix

def small_layers(key,cx,cy,source):return [A.pointer(key+'-shadow',cx,cy,source),A.pointer(key,cx,cy,source)]

def date_window(im,prefix,x,y,w=27,h=31,frame='#9b9e90',red=False,cream=False,font_size=21,cell_w=11,cell_h=24):
    d=ImageDraw.Draw(im);A.rect(d,(x,y,x+w,y+h),'#b41b25' if red else frame,r=1)
    A.rect(d,(x+2,y+2,x+w-2,y+h-2),'#f5f3e5' if cream else '#f6f7f0')
    A.line(d,[(x+2,y+h-2),(x+2,y+2),(x+w-2,y+2)],'#787e72',.8)
    A.line(d,[(x+3,y+h-2),(x+w-2,y+h-2),(x+w-2,y+3)],'#ffffff',.7)
    keys=A.digits(prefix+'-date',cell_w,cell_h,font_size,'#252e26',A.NARROW)
    return A.number(keys,x+(w-cell_w*2)//2,y+(h-cell_h)//2,23),{'x':x,'y':y,'w':w+1,'h':h+1}

def add_scene(theme,name,im,layers,description,**extra):
    A.roundface(theme+'-dial',im)
    scenes.append({'theme':theme,'name':name,'kind':'analog','description':description,'main':[A.art(theme+'-dial',0,0),*layers],**extra})

# 1 — MotyarStudio in ivory and charcoal. The geometric hour numerals retain
# their original orientation; the vertical day/date register is a live calendar.
paths={0:[(0,0),(17,0),(17,25),(0,25),(0,0)],1:[(12,0),(12,25)],2:[(0,0),(17,0),(17,12),(0,12),(0,25),(17,25)],3:[(0,0),(17,0),(17,25),(0,25)],4:[(0,0),(0,12),(17,12),(17,0),(17,25)],5:[(17,0),(0,0),(0,12),(17,12),(17,25),(0,25)],6:[(17,0),(0,0),(0,25),(17,25),(17,12),(0,12)],7:[(0,0),(17,0),(17,25)],8:[(0,0),(17,0),(17,25),(0,25),(0,0),(0,12),(17,12)],9:[(0,25),(17,25),(17,0),(0,0),(0,12),(17,12)]}
MOTYAR_ORANGE='#ff951d'
MOTYAR_WEEKDAY_RED='#b92f34'
MOTYAR_CALENDAR_SPLIT='#7d827c'

def motyar_date_labels(prefix,dark=False,sans=False):
    """Each edition uses its hour typeface for the live date frames."""
    keys=[]
    for day in range(32):
        im,_=A.canvas(50,44)
        if day and sans:
            font=ImageFont.truetype(A.FONT,30*S,index=1);d=ImageDraw.Draw(im)
            box=d.textbbox((0,0),str(day),font=font)
            d.text((25*S-(box[0]+box[2])/2,22*S-(box[1]+box[3])/2),str(day),font=font,fill='#e4e8de' if dark else '#20271c')
        elif day:
            glyph,gd=A.canvas(66,46);label=str(day);x=(66-(len(label)*23-6))/2
            for ch in label:
                A.line(gd,[(x+xx,10+yy) for xx,yy in paths[int(ch)]],'#e4e8de' if dark else '#20271c',3.1)
                if ch=='3':A.line(gd,[(x,22.5),(x+17,22.5)],'#e4e8de' if dark else '#20271c',3.1)
                x+=23
            glyph=glyph.crop(glyph.getchannel('A').getbbox())
            glyph=glyph.resize((round(glyph.width*.84),round(glyph.height*.84)),Image.Resampling.LANCZOS)
            im.alpha_composite(glyph,(round((50*S-glyph.width)/2),round((44*S-glyph.height)/2)))
        key=f'{prefix}-day-{day}';A.save(key,im);keys.append(key)
    return keys

def motyar_calendar(im,prefix,dark=False,sans=False):
    # Two bowed apertures reveal large, gently cylindrical calendar discs below
    # the face. The red weekday disc and dial-tone date share a gray inset split.
    x,y,w,h=206,292,54,74
    pane=im.crop((x*S,y*S,(x+w)*S,(y+h)*S));pixels=pane.load()
    bow=lambda px:1.6*max(0,1-((px-27)/25)**2)
    for yy in range(pane.height):
        for xx in range(pane.width):
            px=(xx+.5)/S;py=(yy+.5)/S;arc=bow(px)
            if not 2<=px<=52:continue
            weekday=py<28+arc
            top,bottom=(1.5+arc,28+arc) if weekday else (28+arc,72+arc)
            if not top<=py<=bottom:continue
            t=(py-top)/(bottom-top)
            occlusion=(12 if weekday else (8 if dark else 16))*math.exp(-(px-2)/2.8)+(14 if weekday else (9 if dark else 18))*math.exp(-(py-top)/2.6)
            cylinder=(1 if dark else 1.8)-(3 if dark else 4.5)*(2*t-1)**2
            rgb=(185,47,52,255) if weekday else pixels[xx,yy]
            pixels[xx,yy]=tuple(max(0,min(255,round(c+cylinder-occlusion))) for c in rgb[:3])+(255,)
    pd=ImageDraw.Draw(pane)
    arc_points=lambda level:[(2+i*.5,level+bow(2+i*.5)) for i in range(101)]
    A.line(pd,arc_points(1.5),'#111910' if dark else '#b8bdaf',.45)
    A.line(pd,arc_points(72),'#4b5544' if dark else '#fcfdf8',.45)
    # Exactly one native pixel, inside the pane: an inset separator, never a drop shadow.
    A.line(pd,arc_points(28),MOTYAR_CALENDAR_SPLIT,1)
    for edge in (2,52):
        A.line(pd,[(edge,1.5+bow(edge)),(edge,72+bow(edge))],'#151d12' if dark else '#c1c6b7',.4)
    im.alpha_composite(pane,(x*S,y*S))
    weekdays=A.labels(prefix+'-weekday',['SUN','MON','TUE','WED','THU','FRI','SAT'],50,26,17.5,'#ffffff',index=1)
    dates=motyar_date_labels(prefix,dark,sans)
    return [A.art(weekdays[0],208,294,24,weekdays),A.art(dates[0],208,320,23,dates)],{'x':206,'y':292,'w':55,'h':75}

def motyar_branding(im,dark=False):
    # Both words share a family and baseline; center their combined actual ink.
    label,ld=A.canvas(190,44);color='#b4bdac' if dark else '#62675b'
    bold=ImageFont.truetype(A.FONT,22*S,index=1);light=ImageFont.truetype(A.FONT,22*S,index=7)
    start=8*S;baseline=29*S;advance=ld.textlength('Motyar',font=bold)
    ld.text((start,baseline),'Motyar',font=bold,fill=color,anchor='ls')
    ld.text((start+advance,baseline),'Studio',font=light,fill=color,anchor='ls')
    label=label.crop(label.getchannel('A').getbbox())
    im.alpha_composite(label,(round(233*S-label.width/2),round(128*S-label.height/2)))

def motyar_face(dark=False,sans=False):
    p=('motyarstudio-sans-dark' if dark else 'motyarstudio-sans') if sans else ('motyarstudio-dark' if dark else 'bai-clock')
    name=('MotyarStudio Sans Dark' if dark else 'MotyarStudio Sans') if sans else ('MotyarStudio Dark' if dark else 'MotyarStudio')
    im=face_surface('#252823' if dark else '#f3f1eb',15 if dark else 30,42);d=ImageDraw.Draw(im)
    ink='#e4e8de' if dark else '#252a22';tick_inner,tick_outer=188,210
    for n in range(60):
        if n%5==0:continue
        marker_color='#a2a797' if dark else '#77786b'
        if sans:
            mx,my=polar(233,233,(tick_inner+tick_outer)/2,n,60)
            A.ellipse(d,(mx-1.65,my-1.65,mx+1.65,my+1.65),marker_color)
        else:
            A.tick(d,n,233,233,tick_inner,tick_outer,marker_color,1,60)
    for h in range(1,13):
        glyph,gd=A.canvas(66,46);s=str(h)
        if sans:
            font=ImageFont.truetype(A.FONT,35*S,index=1);box=gd.textbbox((0,0),s,font=font)
            gd.text((33*S-(box[0]+box[2])/2,23*S-(box[1]+box[3])/2),s,font=font,fill=ink)
        else:
            span=(len(s)*23-6);x=(66-span)/2
            for ch in s:
                A.line(gd,[(x+xx,10+yy) for xx,yy in paths[int(ch)]],ink,3.1)
                if ch=='3':A.line(gd,[(x,22.5),(x+17,22.5)],ink,3.1)
                x+=23
        glyph=glyph.crop(glyph.getchannel('A').getbbox())
        glyph=glyph.rotate(180-h*30 if 4<=h<=8 else -h*30,resample=Image.Resampling.BICUBIC,expand=True)
        glyph=glyph.crop(glyph.getchannel('A').getbbox())
        px,py=polar(233,233,(tick_inner+tick_outer)/2,h,12)
        im.alpha_composite(glyph,(round(px*S-glyph.width/2),round(py*S-glyph.height/2)))
    hand_color='#e6eae0' if dark else '#20241c'
    custom_hand(p+'-hour',116,6,hand_color,'baton');custom_hand(p+'-minute',193,3,hand_color,'baton')
    custom_hand(p+'-second',207,1.5,MOTYAR_ORANGE,'motyar-second')
    motyar_branding(im,dark)
    calendar,box=motyar_calendar(im,p,dark,sans)
    calendar_style={'placementCenter':[233,329],'shadow':'inner-only','dateFont':'same geometric paths as hour numerals','dateFontScale':.84,'datePaper':'dial-tone','weekdayPaper':MOTYAR_WEEKDAY_RED,'weekdayInk':'#ffffff','arcSag':1.6,'separatorWidth':1,'separatorColor':MOTYAR_CALENDAR_SPLIT,'orange':MOTYAR_ORANGE}
    extra={}
    if sans:
        calendar_style.pop('dateFontScale')
        calendar_style.update(dateFont='Helvetica Neue',dateFontWeight='Bold',dateFontSize=30)
        extra={'copyOf':'motyarstudio-dark' if dark else 'bai-clock','typography':{'hourFont':'Helvetica Neue','hourWeight':'Bold','hourSize':35,'dateFont':'Helvetica Neue','dateWeight':'Bold','dateSize':30,'weekdayFont':'Helvetica Neue','weekdayWeight':'Bold'}}
    minute_track={'divisions':60,'minorStrokes':48,'strokesBetweenHours':4,'innerRadius':tick_inner,'outerRadius':tick_outer,'labelRadius':(tick_inner+tick_outer)/2}
    if sans:
        minute_track={'divisions':60,'markerStyle':'dots','minorDots':48,'dotsBetweenHours':4,'dotRadius':1.65,'radius':(tick_inner+tick_outer)/2,'labelRadius':(tick_inner+tick_outer)/2}
    description=(('Charcoal' if dark else 'Ivory')+' dial with a dotted minute track, Helvetica Neue Bold hour and date numerals, mixed-weight branding, white weekdays on red and a gray calendar split.') if sans else (('Charcoal' if dark else 'Ivory')+' dial with larger mixed-weight branding, white weekday text on a red disc, a gray calendar split and dial-tone geometric date numerals.')
    add_scene(p,name,im,[*calendar,*hand_layers(p),cap(p,MOTYAR_ORANGE,20)],
        description,
        revision=2 if sans else (4 if dark else 8),filename=p+'.bin' if sans else ('motyarstudio-dark.bin' if dark else 'motyarstudio.bin'),
        preview=p+'-preview.png' if sans else ('motyarstudio-dark-preview.png' if dark else 'motyarstudio-preview.png'),
        aodPreview=p+'-aod-preview.png' if sans else ('motyarstudio-dark-aod-preview.png' if dark else 'motyarstudio-aod-preview.png'),
        validationFile=p+'-validation.json' if sans else ('motyarstudio-dark-validation.json' if dark else 'motyarstudio-validation.json'),
        supportsSeconds=True,hasDate=True,dateBox=box,dayBox={'x':208,'y':294,'w':50,'h':26},
        dateNumberBox={'x':208,'y':320,'w':50,'h':44},calendarStyle=calendar_style,
        branding={'text':'MotyarStudio','fontFamily':'Helvetica Neue','motyarWeight':'Bold','studioWeight':'Light','size':22,'center':[233,128]},secondHandTail=32,referenceIndex=1,
        minuteTrack=minute_track,**extra)

motyar_face();motyar_face(True)
motyar_face(sans=True);motyar_face(True,sans=True)

# 5 — Mint concentric scale dial. Fine rings remain legible at the watch's
# native size; labels have fixed orientation relative to their scale.
p='xeric-mint';im=face_surface('#c7e0d7',26);d=ImageDraw.Draw(im);ink='#3f635a'
scale_bounds=[54,64,92,120,172,194,216,228]
scale_layout={'boundaries':scale_bounds,'labelRadii':{'roman':78,'innerHour':106,'hour':146,'quarterMinute':183,'minute':205},'fontSizes':{'roman':14,'innerHour':14,'hour':34,'quarterMinute':8.5,'minute':23},'lowerLabelsUpright':True}
def xeric_label(label,r,n,den,size,font=A.FONT):
    # Rotate a tightly cropped glyph, then align its visible bounds to the
    # scale's centerline; font ascenders/side bearings cannot shift the rings.
    glyph,gd=A.canvas(112,56);A.text(gd,(56,28),str(label),size,ink,font)
    glyph=glyph.crop(glyph.getchannel('A').getbbox());angle=n*360/den
    rotation=-angle+(180 if 90<angle%360<270 else 0)
    glyph=glyph.rotate(rotation,resample=Image.Resampling.BICUBIC,expand=True)
    glyph=glyph.crop(glyph.getchannel('A').getbbox());x,y=polar(233,233,r,n,den)
    im.alpha_composite(glyph,(round(x*S-glyph.width/2),round(y*S-glyph.height/2)))
for r in scale_bounds:A.ellipse(d,(233-r,233-r,233+r,233+r),None,ink,.55)
for n in range(120):A.tick(d,n,233,233,217 if n%10==0 else 221,227,ink,1.05 if n%10==0 else .55,120)
for n in range(12):A.tick(d,n,233,233,166,172,ink,.9,12)
for n in range(12):
    xeric_label('60' if n==0 else str(n*5),205,n,12,23,A.NARROW)
    xeric_label(str(n or 12),146,n,12,34)
    xeric_label(str(n or 12),106,n,12,14,A.NARROW)
for n in range(48):
    A.tick(d,n,233,233,173,177,ink,.55,48)
    hour=(n//4) or 12;minute=(n%4)*15
    xeric_label(f'{hour:02d}:{minute:02d}',183,n,48,8.5,A.NARROW)
for n,t in enumerate(['XII','I','II','III','IV','V','VI','VII','VIII','IX','X','XI']):xeric_label(t,78,n,12,14,SERIF)
for n in range(60):A.tick(d,n,233,233,54 if n%5==0 else 59,64,ink,.7 if n%5==0 else .45)
d=ImageDraw.Draw(im);A.tracked(d,(233,271),'XERIC',16,ink,1.8)
custom_hand(p+'-hour',139,4,ink,'xeric');custom_hand(p+'-minute',212,3,ink,'xeric');custom_hand(p+'-second',216,1.3,'#d88b39','needle')
add_scene(p,'Xeric Mint',im,[*hand_layers(p),cap(p,'#304b44',10,True)],'Mint technical dial with larger hour and minute numerals, balanced concentric scales and orange-accented skeleton hands.',revision=2,hasDate=False,referenceIndex=5,scaleLayout=scale_layout)

# 6 — Ivory Seiko adaptation, with aligned recessed clock subdials and blue
# Breguet-style hands. Subdials show minute, seconds and 24-hour clock values.
p='seiko-ivory';im=face_surface('#f1eed7',30);d=ImageDraw.Draw(im);ink='#4c5a4a'
for n in range(120):A.tick(d,n,233,233,215 if n%10==0 else 219,226,ink,.8 if n%10==0 else .45,120)
for h in range(1,13):
    xy=polar(233,233,187,h,12);A.text(d,xy,h,36,'#9b5d4a' if h==12 else ink,ITALIC)
A.text(d,(233,110),'SEIKO',24,ink,SERIFB);A.text(d,(233,132),'Automatic',13,ink,ITALIC)
for cx,cy,den in [(143,216,60),(323,216,60),(233,330,24)]:sub(im,cx,cy,43,den,cream=True,ink='#68715a')
date,box=date_window(im,p,333,331,28,30,cream=True)
custom_hand(p+'-hour',128,6,'#204a5c','breguet');custom_hand(p+'-minute',185,4,'#1d4657','spear');custom_hand(p+'-second',199,1.2,'#305e75','needle')
small_pointer(p+'-small-min','#546449',25);small_pointer(p+'-small-sec','#546449',25)
frames=A.hour24_frames(p,'#546449')
ls=[date,*small_layers(p+'-small-min',143,216,14),*small_layers(p+'-small-sec',323,216,114),A.art(frames[0],193,290,4,frames),*hand_layers(p),cap(p,'#1c4050',5,True)]
add_scene(p,'Seiko Ivory',im,ls,'Cream vintage dial, blue steel hands, serif numerals, three recessed clock subdials and a live date.',hasDate=True,dateBox=box,referenceIndex=6,clockSubdialCenters={'minute':[143,216],'second':[323,216],'hour24':[233,330]})

# 11 — Sternglas grey chronograph. The nested hour and minute scales are
# independent of the two clock subdials, with a red framed date at six.
def sternglas_scale_label(im,label,r,n,den,size,color):
    glyph,gd=A.canvas(80,44);A.text(gd,(40,22),label,size,color,A.NARROW)
    glyph=glyph.crop(glyph.getchannel('A').getbbox())
    angle=n*360/den;rotation=-angle+(180 if 90<angle%360<270 else 0)
    glyph=glyph.rotate(rotation,resample=Image.Resampling.BICUBIC,expand=True)
    glyph=glyph.crop(glyph.getchannel('A').getbbox());x,y=polar(233,233,r,n,den)
    im.alpha_composite(glyph,(round(x*S-glyph.width/2),round(y*S-glyph.height/2)))

def sternglas_hour24_frames(prefix):
    # Both the recess and this native image picker share the exact same center.
    keys=[]
    for hour in range(24):
        im,d=A.canvas(116,116);angle=hour*math.tau/24;cx=cy=58
        pts=[(cx-math.sin(angle)*6,cy+math.cos(angle)*6),(cx+math.sin(angle)*39,cy-math.cos(angle)*39)]
        shade,_=A.canvas(116,116);sd=ImageDraw.Draw(shade)
        A.line(sd,[(x+1,y+2) for x,y in pts],(0,0,0,110),2.4)
        A.ellipse(sd,(cx-3+1,cy-3+2,cx+3+1,cy+3+2),(0,0,0,90))
        im.alpha_composite(shade.filter(ImageFilter.GaussianBlur(2.3*S)));d=ImageDraw.Draw(im)
        A.line(d,pts,'#26322c',2.4);A.ellipse(d,(cx-4,cy-4,cx+4,cy+4),'#28312b')
        A.ellipse(d,(cx-1.1,cy-1.3,cx+1.2,cy+1),'#87917f')
        key=f'{prefix}-24h-{hour}';A.save(key,im);keys.append(key)
    return keys

p='sternglas';im=face_surface('#e5e5df',24);d=ImageDraw.Draw(im);ink='#2e3432'
for n in range(60):
    A.tick(d,n,233,233,200 if n%5==0 else 205,213,ink,1.1 if n%5==0 else .7)
    if n%5==0:sternglas_scale_label(im,f'{n:02d}',222,n,60,14,ink)
for h in range(1,13):
    sternglas_scale_label(im,f'{h:02d}',171,h,12,21,ink)
    A.tick(d,h,233,233,180,190,ink,.9,12)
A.tracked(d,(233,140),'STERNGLAS',13,ink,2.0);A.tracked(d,(233,156),'ZEITMESSER',6.7,ink,1.4)
sub(im,143,233,54,60,[(0,'60'),(15,'15'),(30,'30'),(45,'45')],ink=ink,label_size=12.5)
sub(im,323,233,54,24,[(0,'24'),(6,'06'),(12,'12'),(18,'18')],ink=ink,label_size=12.5)
A.tracked(d,(233,317),'MECHA · QUARTZ',6.5,'#9d2f37',1.1);A.tracked(d,(233,329),'CHRONO',6,ink,1)
date,box=date_window(im,p,215,341,36,38,red=True,font_size=27,cell_w=14,cell_h=32)
custom_hand(p+'-hour',126,8,'#1c2523','spear');custom_hand(p+'-minute',187,5,'#1c2523','spear');custom_hand(p+'-second',211,2.1,'#bd303b','chrono-second')
small_pointer(p+'-small-min','#b82e38',39,2.8);frames=sternglas_hour24_frames(p)
ls=[date,*small_layers(p+'-small-min',143,233,14),A.art(frames[0],265,175,4,frames),*hand_layers(p),cap(p,'#b32a35',6.4,True)]
add_scene(p,'Sternglas Chrono',im,ls,'A cool grey instrument dial with larger main scales, enlarged aligned chronograph wells, a distinct red seconds hand and a raised wider live date.',revision=3,hasDate=True,dateBox=box,referenceIndex=11,clockSubdialCenters={'minute':[143,233],'hour24':[323,233]},chronoDialRadius=54,scaleLayout={'hourLabelRadius':171,'hourFontSize':21,'minuteLabelRadius':222,'minuteFontSize':14},mainPivot=[233,233])

# 13 — Seiko orange/blue sports chronograph. The pale lower plate is clipped
# to the dial circle, leaving a blue upper panel for the wordmark.
p='seiko-orange';im=face_surface('#7d8d94',21);d=ImageDraw.Draw(im);orange='#e2a12f'
A.ellipse(d,(23,23,443,443),'#222e35');A.ellipse(d,(48,48,418,418),'#8d9eaa')
for n in range(60):
    A.tick(d,n,233,233,215 if n%5==0 else 220,228,orange,1.6 if n%5==0 else .9)
    if n%10==0:radial_text(im,'60' if n==0 else str(n),216,n,60,18,orange,COND)
for n in range(120):A.tick(d,n,233,233,192 if n%10==0 else 199,204,'#d6dbd9',1 if n%10==0 else .45,120)
for n in range(12):A.tick(d,n,233,233,187,201,orange,4.2,12)
plate,_=A.canvas(466,466,'#d4d9d6');mask=Image.new('L',plate.size);md=ImageDraw.Draw(mask)
A.ellipse(md,(51,51,415,415),255);band=Image.new('L',plate.size);bd=ImageDraw.Draw(band)
A.poly(bd,[(40,205),(100,179),(165,171),(233,172),(301,171),(366,179),(426,205),(426,430),(40,430)],255)
mask=ImageChops.multiply(mask,band);plate.putalpha(mask);im.alpha_composite(plate);d=ImageDraw.Draw(im)
A.text(d,(233,109),'SEIKO',25,'#e8ebe4',SERIFB);A.text(d,(233,132),'CHRONOGRAPH',9.5,'#e8ebe4',A.BOLD)
for cx,cy,den in [(146,222,60),(320,222,24),(233,323,60)]:sub(im,cx,cy,47,den,ink='#4a5a5d')
date,box=date_window(im,p,350,209,27,30,frame='#8f9d9b')
custom_hand(p+'-hour',119,11,orange,'orange');custom_hand(p+'-minute',176,8,orange,'orange');custom_hand(p+'-second',193,1.2,'#efb341','needle')
small_pointer(p+'-small-sec','#3d4f55',29);small_pointer(p+'-small-min','#3d4f55',29);frames=A.hour24_frames(p,'#3d4f55')
ls=[date,*small_layers(p+'-small-sec',146,222,114),*small_layers(p+'-small-min',233,323,14),A.art(frames[0],280,182,4,frames),*hand_layers(p),cap(p,'#26373b',8,True)]
add_scene(p,'Seiko Orange',im,ls,'Blue and grey sports dial, orange hands and bezel markings, three live clock subdials and a date window.',hasDate=True,dateBox=box,referenceIndex=13,clockSubdialCenters={'minute':[233,323],'second':[146,222],'hour24':[320,222]})

A.finish(scenes)
