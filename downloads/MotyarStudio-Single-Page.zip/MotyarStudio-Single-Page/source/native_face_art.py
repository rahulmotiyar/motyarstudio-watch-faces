"""Three code-drawn CMF faces. All live elements are exported as native widgets."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageFilter,ImageChops,ImageColor
import math,json,re,xml.etree.ElementTree as ET

HERE=Path(__file__).resolve().parent
OUT=HERE.parent if HERE.name=='source' else HERE.parent/'outputs/braun-round'
ASSETS=OUT/'expanded-assets'/'scratch'
S=4;FONT='/System/Library/Fonts/HelveticaNeue.ttc'
BOLD='/System/Library/Fonts/Supplemental/Arial Bold.ttf'
NARROW='/System/Library/Fonts/Supplemental/Arial Narrow.ttf'
manifest={};scenes=[]
# One layout drives the recessed circles, tick marks, native pivots and checks.
SUBDIALS={'minute':[154,183],'hour24':[312,183],'second':[233,320],'radius':48}
def canvas(w,h,c=(0,0,0,0)):
    im=Image.new('RGBA',(w*S,h*S),c);return im,ImageDraw.Draw(im)
def line(d,pts,c,w=1):d.line([(round(x*S),round(y*S)) for x,y in pts],fill=c,width=max(1,round(w*S)))
def ellipse(d,box,c=None,outline=None,w=1):d.ellipse(tuple(round(v*S) for v in box),fill=c,outline=outline,width=max(1,round(w*S)))
def rect(d,box,c,outline=None,w=1,r=0):
    box=tuple(round(v*S) for v in box)
    if r:d.rounded_rectangle(box,radius=round(r*S),fill=c,outline=outline,width=max(1,round(w*S)))
    else:d.rectangle(box,fill=c,outline=outline,width=max(1,round(w*S)))
def poly(d,pts,c):d.polygon([(round(x*S),round(y*S)) for x,y in pts],fill=c)
def text(d,xy,t,size,c='#252722',font=FONT,index=0):
    d.text(tuple(round(v*S) for v in xy),str(t),font=ImageFont.truetype(font,round(size*S),index=index),fill=c,anchor='mm')
def tracked(d,xy,t,size,c,spacing=1.5,font=FONT):
    f=ImageFont.truetype(font,round(size*S));width=sum(d.textlength(ch,font=f) for ch in t)+spacing*S*(len(t)-1)
    x=xy[0]*S-width/2
    for ch in t:
        d.text((round(x),round(xy[1]*S)),ch,font=f,fill=c,anchor='lm');x+=d.textlength(ch,font=f)+spacing*S
def save(key,im,cf=5,**geometry):
    im=im.resize((im.width//S,im.height//S),Image.Resampling.LANCZOS)
    return save_native(key,im,cf,**geometry)

def save_native(key,im,cf=5,**geometry):
    """Import an already-sized bitmap without another resampling pass."""
    im=im.convert('RGBA')
    if im.width>466 or im.height>466:raise ValueError('Native asset exceeds 466 pixels')
    if cf==4:
        px=im.load();bayer=((0,8,2,10),(12,4,14,6),(3,11,1,9),(15,7,13,5))
        for y in range(im.height):
            for x in range(im.width):
                r,g,b,a=px[x,y];n=(bayer[y%4][x%4]-7.5)/16
                px[x,y]=tuple(max(0,min(255,round(v+n*step))) for v,step in [(r,7.8),(g,3.8),(b,7.8)])+(a,)
    im.save(ASSETS/f'{key}.png');(ASSETS/f'{key}.rgba').write_bytes(im.tobytes())
    manifest[key]={'w':im.width,'h':im.height,'cf':cf,**geometry};return im
def surface(dark=False):
    small=Image.new('RGBA',(466,466));px=[]
    for y in range(466):
        for x in range(466):
            dx=(x-233)/233;dy=(y-233)/233;r=math.hypot(dx,dy);light=(-dx-dy)*.5
            v=31+light*10-r*r*2 if dark else 245+light*5-r*r*4
            px.append(tuple(max(0,min(255,round(v+a))) for a in (0,.4,-1))+(255,))
    small.putdata(px);return small.resize((466*S,466*S),Image.Resampling.BICUBIC)
def roundface(key,im):
    mask=Image.new('L',im.size);ImageDraw.Draw(mask).ellipse((0,0,466*S-1,466*S-1),fill=255)
    bg=Image.new('RGBA',im.size,'black');bg.paste(im,(0,0),mask);return save(key,bg,4)
def braun_logo(im,xy=(233,97),w=80):
    src=Image.open(OUT/'source/braun-logo-official.png').convert('RGBA').getchannel('A');src=src.crop(src.getbbox())
    h=round(w*S*src.height/src.width);alpha=src.resize((round(w*S),h),Image.Resampling.LANCZOS)
    logo=Image.new('RGBA',alpha.size,'#20221d');logo.putalpha(alpha)
    im.alpha_composite(logo,(round(xy[0]*S-w*S/2),round(xy[1]*S-h/2)))
def tick(d,t,cx,cy,r0,r1,c,w=1,den=60):
    a=t*math.tau/den;line(d,[(cx+math.sin(a)*r0,cy-math.cos(a)*r0),(cx+math.sin(a)*r1,cy-math.cos(a)*r1)],c,w)
def well(im,cx,cy,r,dark=False):
    # Broad, directional occlusion on the inside wall, with a soft lower lip.
    # This shades a recess rather than outlining it with two hard semicircles.
    patch,_=canvas(r*2+4,r*2+4);pixels=[]
    global_light=(-(cx-233)-(cy-233))/466
    for yy in range(patch.height):
        for xx in range(patch.width):
            dx=(xx+.5)/S-r-2;dy=(yy+.5)/S-r-2;rr=math.hypot(dx,dy);depth=r-rr
            if depth<0:pixels.append((0,0,0,0));continue
            light=-(dx+dy)/max(rr,1)/math.sqrt(2)
            base=(29+global_light*8) if dark else (242+global_light*4)
            shade=(15 if dark else 35)*math.exp(-depth/5.7)*(.63+.37*light)
            lip=(8 if dark else 12)*math.exp(-((depth-.7)/.65)**2)*max(0,-light)
            v=base-shade+lip+(-dx-dy)/r*(.7 if dark else 1)
            pixels.append(tuple(max(0,min(255,round(v+c))) for c in (0,.5,-.7))+(255,))
    patch.putdata(pixels);im.alpha_composite(patch,(round((cx-r-2)*S),round((cy-r-2)*S)))
def subdial(im,cx,cy,r,label,den=60,dark=False):
    well(im,cx,cy,r,dark);d=ImageDraw.Draw(im);ink='#d9dfd1' if dark else '#252923'
    for n in range(0,den,5 if den==60 else 2):tick(d,n,cx,cy,r-9,r-5,ink,1.1,den)
    marks=[(0,'60'),(20,'20'),(40,'40')] if den==60 else [(0,'24'),(8,'08'),(16,'16')]
    for n,s in marks:
        a=n*math.tau/den;text(d,(cx+math.sin(a)*(r-17),cy-math.cos(a)*(r-17)),s,10.5,ink)
    if den!=24:text(d,(cx,cy+18),label,10.5,ink)
def art(key,x,y,source=0,frames=None,conditions=None):
    return {'type':'image','key':key,'x':x,'y':y,'source':source,'frames':frames or [key],**({'conditions':conditions} if conditions else {})}
def pointer(key,cx,cy,source,maxval=60):return {'type':'hand','key':key,'cx':cx,'cy':cy,'source':source,'max':maxval}
def number(keys,x,y,source,digits=2,padZero=True):return {'type':'number','keys':keys,'x':x,'y':y,'source':source,'digits':digits,'padZero':padZero}

def hand(key,tip,width,color,style='plain',shadow=True):
    w=80 if tip>70 else 40;h=round(tip+104);h+=h%2;piv=round(tip+38);x=w/2
    im,d=canvas(w,h);mask=Image.new('L',im.size);md=ImageDraw.Draw(mask)
    if style=='second':
        line(md,[(x,piv-tip),(x,piv+22)],255,width)
        md.rounded_rectangle(tuple(round(v*S) for v in (x-3,piv+4,x+3,piv+23)),radius=round(3*S),fill=255)
        ellipse(md,(x-8,piv-8,x+8,piv+8),255)
    elif style=='rounded':rect(md,(x-width/2,piv-tip,x+width/2,piv+8),255,r=width/2)
    else:rect(md,(x-width/2,piv-tip,x+width/2,piv+8),255)
    layer=Image.new('RGBA',im.size,color);layer.putalpha(mask);im.alpha_composite(layer);d=ImageDraw.Draw(im)
    if style=='hollow':
        rect(d,(x-width*.23,piv-tip+5,x+width*.23,piv-13),'#dedfd7',r=1)
        line(d,[(x-width/2+.25,piv-tip+.5),(x-width/2+.25,piv+7)],'#747a6f',.45)
    elif style=='rounded':
        rect(d,(x-width*.22,piv-tip+5,x+width*.22,piv-12),'#eef0e7',r=1.3)
        line(d,[(x-width/2+.4,piv-tip+5),(x-width/2+.4,piv+5)],'#f6f8ee',.55)
    elif style=='second':
        ellipse(d,(x-7.8,piv-7.8,x+7.8,piv+7.8),None,'#f8e398',.65)
        ellipse(d,(x-1.7,piv-1.7,x+1.7,piv+1.7),'#8c7334')
        ellipse(d,(x-.6,piv-.8,x+.7,piv+.4),'#fff2bd')
    save(key,im,pivotX=w/2,pivotY=piv)
    if shadow:
        sh=Image.new('RGBA',im.size,(0,0,0,0));large=tip>70
        broad=mask.filter(ImageFilter.GaussianBlur((7.2 if large else 2.8)*S)).point(lambda a:round(a*(.60 if large else .35)))
        contact=mask.filter(ImageFilter.GaussianBlur((2.7 if large else 1)*S)).point(lambda a:round(a*.10))
        sh.putalpha(ImageChops.add(broad,contact));save(key+'-shadow',sh,pivotX=w/2,pivotY=piv,offsetX=3 if large else 1,offsetY=7 if large else 2)

def clock_layers(prefix,cx=233,cy=233):
    result=[]
    for key,src in [('hour',10),('minute',14),('second',114)]:
        result.extend([pointer(prefix+key+'-shadow',cx,cy,src),pointer(prefix+key,cx,cy,src)])
    return result
def hour24_frames(prefix,color):
    keys=[]
    for hour in range(24):
        im,d=canvas(80,80);a=hour*math.tau/24
        pts=[(40-math.sin(a)*4,40+math.cos(a)*4),(40+math.sin(a)*25,40-math.cos(a)*25)]
        shadow,_=canvas(80,80);sd=ImageDraw.Draw(shadow)
        line(sd,[(x+1,y+2) for x,y in pts],(0,0,0,95),2)
        ellipse(sd,(38,39,44,45),(0,0,0,95));im.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(2.3*S)))
        d=ImageDraw.Draw(im);line(d,pts,color,2)
        ellipse(d,(37,37,43,43),color);key=f'{prefix}-24h-{hour}';save(key,im);keys.append(key)
    return keys

def subdial_layers(prefix,frames):
    mx,my=SUBDIALS['minute'];hx,hy=SUBDIALS['hour24'];sx,sy=SUBDIALS['second']
    return [pointer(prefix+'small-min-shadow',mx,my,14),pointer(prefix+'small-min',mx,my,14),
        art(frames[0],hx-40,hy-40,4,frames),pointer(prefix+'small-sec-shadow',sx,sy,114),pointer(prefix+'small-sec',sx,sy,114)]

def hub_shadow(key):
    im,d=canvas(80,84);ellipse(d,(28,29,52,53),(0,0,0,100))
    save(key,im.filter(ImageFilter.GaussianBlur(8*S)))

def configure(family):
    global ASSETS,manifest
    ASSETS=OUT/'expanded-assets'/family;ASSETS.mkdir(parents=True,exist_ok=True);manifest={}
    return ASSETS

def rotated_text(im,xy,t,size,c='#252722',angle=0,font=FONT,index=0):
    layer,d=canvas(466,466);text(d,(233,233),t,size,c,font,index)
    layer=layer.rotate(angle,resample=Image.Resampling.BICUBIC,center=(233*S,233*S))
    im.alpha_composite(layer,(round((xy[0]-233)*S),round((xy[1]-233)*S)))

def digits(prefix,w,h,size,c='#252722',font=FONT,index=0):
    keys=[]
    for n in range(10):
        im,d=canvas(w,h);text(d,(w/2,h/2),n,size,c,font,index);key=f'{prefix}-{n}';save(key,im);keys.append(key)
    return keys

def labels(prefix,values,w,h,size,c='#252722',font=FONT,index=0):
    keys=[]
    for n,label in enumerate(values):
        im,d=canvas(w,h);text(d,(w/2,h/2),label,size,c,font,index);key=f'{prefix}-{n}';save(key,im);keys.append(key)
    return keys

def aod(prefix,digital=False):
    im,d=canvas(466,466,'black')
    if digital:
        text(d,(233,171),'LOCAL TIME',10,'#687267')
        text(d,(233,230),':',50,'#a4aea0')
        roundface(prefix+'-aod-dial',im);keys=digits(prefix+'-aod-num',29,60,52,'#a4aea0')
        return [art(prefix+'-aod-dial',0,0),number(keys,163,201,1),number(keys,245,201,11)]
    for n in range(0,60,5):tick(d,n,233,233,215,224,'#687267',1)
    roundface(prefix+'-aod-dial',im)
    hand(prefix+'-aod-hour',115,3,'#a4aea0',shadow=False);hand(prefix+'-aod-minute',169,2,'#a4aea0',shadow=False)
    return [art(prefix+'-aod-dial',0,0),pointer(prefix+'-aod-hour',233,233,10),pointer(prefix+'-aod-minute',233,233,14)]

def value(source,h,m,s,day,wd=4):
    return {0:0,1:h,4:h,10:(h%12)*5+m/12,11:m,14:m+s/60,15:s,19:int(h>=12),20:1,21:1,23:day,24:wd,25:6789,26:72,36:80,48:80,54:25,95:25,96:28,97:18,114:s}.get(source,0)

def compose(scene,screen='main',h=10,m=8,s=35,day=29):
    result=Image.new('RGBA',(466,466),'black')
    for layer in scene[screen]:
        def condition(c):
            actual=value(c['source'],h,m,s,day);target=c['value'];op=c.get('op','eq')
            return {'eq':actual==target,'ne':actual!=target,'noData':actual==target,'lt':actual<target,'gte':actual>=target,'lte':actual<=target}[op]
        if not all(condition(c) for c in layer.get('conditions',[])):continue
        v=value(layer.get('source',0),h,m,s,day)
        if layer['type']=='hand':
            a=manifest[layer['key']];sprite=Image.open(ASSETS/(layer['key']+'.png'));full=Image.new('RGBA',(466,466))
            full.alpha_composite(sprite,(233-round(a['pivotX']),233-a['pivotY']))
            full=full.rotate(-v/layer.get('max',60)*360,resample=Image.Resampling.BICUBIC,center=(233,233))
            shifted=Image.new('RGBA',(466,466));shifted.alpha_composite(full,(layer['cx']-233+a.get('offsetX',0),layer['cy']-233+a.get('offsetY',0)));result.alpha_composite(shifted)
        elif layer['type']=='number':
            x=layer['x']
            string=f'{abs(round(v)):0{layer["digits"]}d}' if layer.get('padZero',True) else str(abs(round(v)))
            for ch in string:
                sprite=Image.open(ASSETS/(layer['keys'][int(ch)]+'.png'));result.alpha_composite(sprite,(x,layer['y']));x+=sprite.width
        else:
            frames=layer['frames'];key=frames[int(v)%len(frames)];result.alpha_composite(Image.open(ASSETS/(key+'.png')),(layer['x'],layer['y']))
    return result

def finish(scenes):
    for scene in scenes:
        p=scene['theme'];scene.setdefault('filename',p+'.bin');scene.setdefault('seed','cmf-'+p+'-v1');scene.setdefault('revision',1)
        scene.setdefault('validationFile',p+'-validation.json');scene.setdefault('preview',p+'-preview.png');scene.setdefault('aodPreview',p+'-aod-preview.png')
        scene.setdefault('hasDate',False);scene.setdefault('supportsSeconds',True)
        if 'aod' not in scene:
            scene['aod']=aod(p,scene.get('kind')=='digital')
            if scene.get('hourFormat','').startswith('24'):
                for layer in scene['aod']:
                    if layer.get('source')==1:layer['source']=4
        for screen,file in [('main',scene['preview']),('aod',scene['aodPreview'])]:
            im=compose(scene,screen);im.save(OUT/file);key=p+'-'+screen+'-thumb'
            save(key,im.resize((270*S,270*S),Image.Resampling.LANCZOS),4);scene[screen+'Thumb']=key
        scene.setdefault('expectedSources',sorted({l.get('source',0) for l in scene['main']} - {0}))
    (ASSETS/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(ASSETS/'scenes.json').write_text(json.dumps(scenes,indent=2)+'\n')
    print(f'Generated {len(scenes)} scenes, {len(manifest)} assets in {ASSETS}')

