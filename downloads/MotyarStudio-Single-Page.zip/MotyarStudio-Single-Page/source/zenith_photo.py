"""Use the supplied Zenith photograph as native dial artwork, with live hands."""
from PIL import Image, ImageDraw, ImageFilter,ImageChops
import hashlib,json,math

CROP=(186,78,1012,894)
SOURCE_PIVOTS={'main':(599,486),'minute':(420,486),'minute30':(779,486),'second':(599,683)}

def native_point(point):
    x,y=point;l,t,r,b=CROP
    return (round((x-l+.5)*466/(r-l)-.5),round((y-t+.5)*466/(b-t)-.5))

def polished_hand(a,key,tip,width,second=False):
    """High-contrast metal edge, luminous center and a broad native shadow."""
    w=96;h=tip+106;piv=tip+36;x=w/2
    im,d=a.canvas(w,h);mask=Image.new('L',im.size);md=ImageDraw.Draw(mask)
    if second:
        a.line(md,[(x,piv-tip),(x,piv+23)],255,width)
        a.rect(md,(x-2.8,piv+6,x+2.8,piv+21),255,r=2)
    else:
        shape=[(x,piv-tip),(x+width*.48,piv-tip+6),(x+width*.53,piv-23),
            (x+width*.31,piv+10),(x-width*.31,piv+10),(x-width*.53,piv-23),(x-width*.48,piv-tip+6)]
        a.poly(md,shape,255)
    # Native-size metal shader is supersampled before masking. The dark outer
    # edge remains visible on silver, ivory and blue portions of the dial.
    plane=Image.new('RGBA',im.size)
    colors=[]
    for xx in range(im.width):
        dx=(xx/a.S-x)/max(width/2,1)
        sheen=math.exp(-((dx+.7)/.18)**2)
        base=(17,30,39) if second else (18,29,37)
        colors.append(tuple(round(c+sheen*70) for c in base)+(255,))
    for xx,c in enumerate(colors):ImageDraw.Draw(plane).line((xx,0,xx,plane.height),fill=c)
    plane.putalpha(mask);im.alpha_composite(plane);d=ImageDraw.Draw(im)
    if second:
        a.line(d,[(x-.45,piv-tip+3),(x-.45,piv-22)],'#d9e9eb',.85)
    else:
        a.line(d,[(x-width*.46,piv-tip+7),(x-width*.49,piv-23)],'#a8bdc7',.65)
        a.line(d,[(x+width*.5,piv-tip+7),(x+width*.5,piv-23)],'#061118',.7)
        inset=width*.35
        a.rect(d,(x-inset/2,piv-tip+12,x+inset/2,piv-26),'#f1f0db',r=.8)
        a.line(d,[(x-inset/2+.3,piv-tip+12),(x-inset/2+.3,piv-26)],'#ffffff',.4)
    a.save(key,im,pivotX=w/2,pivotY=piv)
    sh,_=a.canvas(w,h)
    wide=mask.filter(ImageFilter.GaussianBlur(6.3*a.S)).point(lambda alpha:round(alpha*.48))
    contact=mask.filter(ImageFilter.GaussianBlur(2.2*a.S)).point(lambda alpha:round(alpha*.13))
    sh.putalpha(ImageChops.add(wide,contact));a.save(key+'-shadow',sh,pivotX=w/2,pivotY=piv,offsetX=3,offsetY=7)

def build_zenith(a):
    p='zenith-ice';source=a.OUT/'source/zenith-reference.png'
    photo=Image.open(source).convert('RGBA')
    # One deterministic image resample fits the photographed dial to the panel.
    # All lettering, relief, metal reflections and subdial rings come from it.
    face=photo.resize((466,466),Image.Resampling.LANCZOS,box=CROP)
    circle=Image.new('L',(466,466));ImageDraw.Draw(circle).ellipse((0,0,465,465),fill=255)
    background=Image.new('RGBA',(466,466),'black');background.paste(face,(0,0),circle)
    background=a.save_native(p+'-dial',background,4)
    centers={name:native_point(point) for name,point in SOURCE_PIVOTS.items()}
    mx,my=centers['main'];lx,ly=centers['minute'];rx,ry=centers['minute30'];sx,sy=centers['second']

    # Add only the moving elements. The photo has no hands to remove or repaint.
    for name,tip,width in [('hour',118,11),('minute',181,8),('second',195,2.8)]:
        polished_hand(a,p+'-'+name,tip,width,second=name=='second')
    a.hand(p+'-sub-minute',32,1.7,'#263e47')
    a.hand(p+'-sub-second',32,1.5,'#263e47')

    # The right register is printed 30/10/20, not a 24-hour scale. Its 60-frame
    # minute selector repeats the 30-minute phase, preserving the supplied text.
    frames=[]
    for minute in range(60):
        frame,d=a.canvas(80,80);angle=(minute%30)*math.tau/30
        pts=[(40-math.sin(angle)*4,40+math.cos(angle)*4),(40+math.sin(angle)*32,40-math.cos(angle)*32)]
        shadow,sd=a.canvas(80,80);a.line(sd,[(x+1,y+2) for x,y in pts],(0,0,0,85),1.7)
        frame.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(2*a.S)))
        a.line(ImageDraw.Draw(frame),pts,'#263e47',1.7)
        key=f'{p}-minute30-{minute}';a.save(key,frame);frames.append(key)

    layers=[a.art(p+'-dial',0,0),
        a.pointer(p+'-sub-minute-shadow',lx,ly,14),a.pointer(p+'-sub-minute',lx,ly,14),
        a.art(frames[0],rx-40,ry-40,11,frames),
        a.pointer(p+'-sub-second-shadow',sx,sy,114),a.pointer(p+'-sub-second',sx,sy,114),
        *a.clock_layers(p+'-',mx,my)]

    # Reuse the actual photographed pivot caps as foreground pieces, so hands
    # emerge beneath them while their original bevels and lighting stay intact.
    for name,radius,size in [('minute',6.4,20),('minute30',6.4,20),('second',6.4,20),('main',18,44)]:
        cx,cy=centers[name];left=cx-size//2;top=cy-size//2
        cap=background.crop((left,top,left+size,top+size))
        mask=Image.new('L',(size*a.S,size*a.S));md=ImageDraw.Draw(mask)
        mid=size/2;md.ellipse(tuple(round(v*a.S) for v in (mid-radius,mid-radius,mid+radius,mid+radius)),fill=255)
        cap.putalpha(mask.resize((size,size),Image.Resampling.LANCZOS))
        key=f'{p}-photo-cap-{name}';a.save_native(key,cap);layers.append(a.art(key,left,top))

    provenance={'source':'User-supplied Zenith dial photograph','sourceFile':'zenith-reference.png',
        'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'sourceSize':list(photo.size),
        'sourceCropBox':list(CROP),'nativeSize':[466,466],
        'sourcePivots':{k:list(v) for k,v in SOURCE_PIVOTS.items()},'nativePivots':{k:list(v) for k,v in centers.items()},
        'processing':'Direct crop and circular fit with one Lanczos resampling pass; native RGB565 dithering. No redrawing of dial details.',
        'foregroundCaps':'Exact pixels copied from the imported dial, with circular alpha masks.',
        'rightSubdial':'Original 30-minute scale retained; current minute modulo 30.',
        'movingHands':'Broader dark navy polished facets with luminous center strips; wider soft drop shadows. Main native pivot unchanged.',
        'mainHandWidths':{'hour':11,'minute':8,'second':2.8}}
    (a.OUT/'source/zenith-reference-layout.json').write_text(json.dumps(provenance,indent=2)+'\n')
    return {'theme':p,'name':'Zenith Ice','kind':'analog','revision':3,
        'description':'The supplied Zenith dial image with broader polished dark hands, luminous centers and soft moving depth, aligned to its original pivots.',
        'main':layers,'hasDate':False,'supportsSeconds':True,
        'subdialLayout':{'minute':list(centers['minute']),'minute30':list(centers['minute30']),'second':list(centers['second']),'radius':76},
        'mainPivot':list(centers['main']),'artworkMode':'supplied-image',
        'referenceCredit':'User-supplied Zenith dial image; details imported directly.',
        'referenceNote':'Left register: current minute. Right register: minute modulo 30. Bottom register: current second. Clock values, not a stopwatch.',
        'sourceImageSha256':provenance['sourceSha256']}
