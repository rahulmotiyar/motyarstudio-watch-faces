"""Native digital watch faces based on the supplied visual references."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageFilter,ImageChops
import math,json
import native_face_art as A

A.configure('digitals')
S=A.S;FONT=A.FONT;BOLD=A.BOLD
FUTURA='/System/Library/Fonts/Supplemental/Futura.ttc'
ROUND='/System/Library/Fonts/Supplemental/Arial Rounded Bold.ttf'
scenes=[]

def clip_screen(im,x,y):
    mask=Image.new('L',im.size);d=ImageDraw.Draw(mask)
    d.ellipse(((-x)*S,(-y)*S,(466-x)*S-1,(466-y)*S-1),fill=255)
    im.putalpha(ImageChops.multiply(im.getchannel('A'),mask));return im

def shaded_surface(dark=False,cool=False):
    im=Image.new('RGBA',(466,466));px=[]
    for y in range(466):
        for x in range(466):
            dx=(x-233)/233;dy=(y-233)/233;r=math.hypot(dx,dy);direction=(-dx-dy)/math.sqrt(2)
            if dark:
                v=21+direction*5-3*r*r-8*math.exp(-(1-min(r,1))*466/13)
                rgb=(v+.8,v+.5,v+2.8) if not cool else (v-1,v+1,v+6)
            else:
                v=249-4*r*r+direction*2-22*math.exp(-(1-min(r,1))*466/13)*(.6+.4*max(direction,0))
                rgb=(v,v+.3,v-.8)
            px.append(tuple(max(0,min(255,round(c))) for c in rgb)+(255,))
    im.putdata(px);return im.resize((466*S,466*S),Image.Resampling.BICUBIC)

def plain_text(im,xy,t,size,c,font=FONT,index=0,anchor='mm'):
    ImageDraw.Draw(im).text(tuple(round(v*S) for v in xy),str(t),font=ImageFont.truetype(font,round(size*S),index=index),fill=c,anchor=anchor)

def tilted(im,xy,t,size,c,angle=45,index=7):
    f=ImageFont.truetype(FONT,round(size*S),index=index);bb=f.getbbox(t)
    sprite=Image.new('RGBA',(bb[2]-bb[0]+16*S,bb[3]-bb[1]+16*S))
    ImageDraw.Draw(sprite).text((8*S-bb[0],8*S-bb[1]),t,font=f,fill=c)
    sprite=sprite.rotate(angle,resample=Image.Resampling.BICUBIC,expand=True)
    im.alpha_composite(sprite,(round(xy[0]*S-sprite.width/2),round(xy[1]*S-sprite.height/2)))

def day_labels(prefix,w,h,size,c,index=0,upper=True):
    names=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];names=[s.upper() for s in names] if upper else names
    return A.labels(prefix,names,w,h,size,c,index=index)

def cloudy(im,x,y,c,scale=1):
    # A decorative filled cloud and sun, separated by a narrow ceramic gap.
    icon,d=A.canvas(64,52);mask=Image.new('L',icon.size);md=ImageDraw.Draw(mask)
    for box in [(3,23,27,44),(14,12,44,43),(32,23,58,44)]:A.ellipse(md,box,255)
    A.rect(md,(14,32,46,44),255)
    A.ellipse(d,(30,11,48,29),c)
    for degrees in (-110,-75,-40,-5,30):
        aa=math.radians(degrees)
        A.line(d,[(39+math.cos(aa)*13,20+math.sin(aa)*13),(39+math.cos(aa)*17,20+math.sin(aa)*17)],c,1.5)
    sun_cutout=mask.filter(ImageFilter.MaxFilter(9))
    icon.putalpha(ImageChops.multiply(icon.getchannel('A'),ImageChops.invert(sun_cutout)))
    cloud=Image.new('RGBA',icon.size,c);cloud.putalpha(mask);icon.alpha_composite(cloud)
    if scale!=1:icon=icon.resize((round(icon.width*scale),round(icon.height*scale)),Image.Resampling.LANCZOS)
    im.alpha_composite(icon,(round(x*S),round(y*S)))

def rolling_hours(theme,dark):
    ink='#e0dce1' if dark else '#0b0d0c';muted='#88868b' if dark else '#a8aba5'
    im=shaded_surface(dark);d=ImageDraw.Draw(im)
    A.line(d,[(233,30),(233,436)],'#9a969d' if dark else '#7c8379',.6)
    A.poly(d,[(224,30),(242,30),(233,46)],ink);A.poly(d,[(224,436),(242,436),(233,420)],ink)
    for value in range(0,61,10):
        xx=47+value*372/60
        rr=3.1 if value in (0,60) else 2.2 if value==30 else 1.15
        A.ellipse(d,(xx-rr,316-rr,xx+rr,316+rr),ink if value in (0,60) else muted)
    A.roundface(theme+'-dial',im)
    hkeys=[]
    for h in range(24):
        strip,sd=A.canvas(466,152)
        prev=(h-1)%24;nxt=(h+1)%24
        A.text(sd,(33,78),prev,100,ink,FUTURA,2)
        A.text(sd,(233,78),f'{h:02d}',116,ink,FUTURA,2)
        A.text(sd,(434,78),nxt,100,ink,FUTURA,2)
        key=f'{theme}-hours-{h}';A.save(key,clip_screen(strip,0,137));hkeys.append(key)
    minute=[]
    for m in range(60):
        strip,sd=A.canvas(400,14);xx=14+m*372/60
        A.ellipse(sd,(xx-3.1,7-3.1,xx+3.1,7+3.1),ink)
        key=f'{theme}-minute-dot-{m}';A.save(key,strip);minute.append(key)
    mins=A.digits(theme+'-minute-num',24,46,39,ink,index=7)
    return {'theme':theme,'name':'Sliding Numbers '+('Dark' if dark else 'Light'),'kind':'digital','revision':2,
      'description':'A quiet '+('charcoal' if dark else 'ivory')+' hour drum, fixed vertical index and live minute indicator.',
      'main':[A.art(theme+'-dial',0,0),A.art(hkeys[0],0,137,4,hkeys),A.art(minute[0],33,309,11,minute),A.number(mins,209,344,11)],
      'hasDate':False,'supportsSeconds':False,'expectedSources':[4,11],
      'hourFormat':'24-hour drum','referenceImage':2,'typography':{'hourSize':116,'neighborHourSize':100,'minuteSize':39},'minuteScale':{'values':[0,10,20,30,40,50,60],'radii':[3.1,1.15,1.15,2.2,1.15,1.15,3.1],'xStart':47,'xEnd':419,'y':316,'indicatorStep':6.2},'clockRegions':{'hours':[0,137,466,152],'minutes':[33,309,400,81]}}

for dark in (False,True):scenes.append(rolling_hours('sliding-dark' if dark else 'sliding-light',dark))

# Three concentric source-bound discs rotate anticlockwise, with upright labels.
# Hours use 12 discrete states, minutes and seconds use 60. The fixed 3-o'clock
# aperture reads all three current values. No subsecond firmware cadence is assumed.
def lens_surface(x,y):
    # A capsule has a straight crown and semicircular ends, not an ellipse.
    nearest=min(436,max(312,x));dx=x-nearest;dy=y-233
    distance=math.hypot(dx,dy)
    return 24-distance,dx/max(distance,.001),dy/max(distance,.001)

def optical_mesh(width,height,map_point,step=4):
    mesh=[]
    for y in range(0,height,step):
        for x in range(0,width,step):
            right=min(width,x+step);bottom=min(height,y+step)
            quad=[]
            for xx,yy in [(x,y),(x,bottom),(right,bottom),(right,y)]:
                sx,sy=map_point(xx,yy);quad.extend((sx*S,sy*S))
            mesh.append(((x*S,y*S,right*S,bottom*S),tuple(quad)))
    return mesh

def background_refraction(x,y):
    depth,nx,ny=lens_surface(288+x,209+y)
    edge=max(0,1-max(0,depth)/12)**1.8
    gain=1+.08*max(0,1-((y-24)/24)**2)
    return 86+(x-86)/gain-nx*2.6*edge,24+(y-24)/1.08-ny*2.2*edge

readout_meshes={}
def lens_readout(value,global_center):
    if global_center not in readout_meshes:
        def optical_point(x,y):
            dx=x-32;dy=y-24
            depth,nx,ny=lens_surface(global_center+dx,209+y)
            edge=max(0,1-max(0,depth)/12)**1.6
            # Convex gain is strongest through the center, easing toward the rim.
            gain=1.24*(1-.055*(dx/32)**2-.075*(dy/24)**2)
            return 32+dx/gain-nx*.8*edge,24+dy/gain-ny*.8*edge
        readout_meshes[global_center]=optical_mesh(64,48,optical_point)
    glyph,gd=A.canvas(64,48)
    A.text(gd,(32,24),f'{value:02d}',25,'#e5f1fa',index=10)
    return glyph.transform(glyph.size,Image.Transform.MESH,readout_meshes[global_center],Image.Resampling.BICUBIC)

theme='radial-dark';ink='#adbece';faint='#6e8295'
im=Image.new('RGBA',(466,466));pixels=[]
for y in range(466):
    for x in range(466):
        dx=x-233;dy=y-233;r=math.hypot(dx,dy);light=-(dx+dy)/330
        base=24 if r>=181 else (20 if r>=113 else 17)
        v=base+light*3.5
        for boundary in (113,181):
            if r<boundary:v-=8*math.exp(-(boundary-r)/5)*(.65+.35*max(0,light))
        if r>228:v-=7*(r-228)/5
        pixels.append(tuple(max(0,min(255,round(v+c))) for c in (-1,1,5))+(255,))
im.putdata(pixels);im=im.resize((466*S,466*S),Image.Resampling.BICUBIC);d=ImageDraw.Draw(im)
for radius in (113,181):A.ellipse(d,(233-radius,233-radius,233+radius,233+radius),None,'#34424f',.55)
for label,size,index,cy in [('motyar',18,1,222),('studios',16,7,244)]:
    font=ImageFont.truetype(FONT,round(size*S),index=index)
    left,top,right,bottom=d.textbbox((0,0),label,font=font)
    d.text((233*S-(left+right)/2,cy*S-(top+bottom)/2),label,font=font,fill=ink)
# Refract the actual dial surface and its concentric disc boundaries under the
# clear lens. The native frames receive the same precomputed optical treatment.
lens_mask=Image.new('L',(172*S,48*S));lm=ImageDraw.Draw(lens_mask)
A.rect(lm,(0,0,171.75,47.75),255,r=24)
transmitted=im.crop((288*S,209*S,460*S,257*S))
transmitted=transmitted.transform(transmitted.size,Image.Transform.MESH,optical_mesh(172,48,background_refraction),Image.Resampling.BICUBIC)
shadow=Image.new('RGBA',im.size);sd=ImageDraw.Draw(shadow)
A.rect(sd,(289,211,459,258),(0,0,0,38),r=24)
shadow=shadow.filter(ImageFilter.GaussianBlur(2.5*S));im.alpha_composite(shadow)
transmitted.putalpha(lens_mask);im.alpha_composite(transmitted,(288*S,209*S))
A.roundface(theme+'-dial',im)

def rotating_disc(prefix,size,offset,numeral_radius,tick0,tick1,color,count=60,label_step=5,label_size=None,hour12=False):
    keys=[];cx=cy=233-offset
    for state in range(count):
        frame,fd=A.canvas(size,size)
        for n in range(count):
            angle=math.radians((n-state)*360/count)
            major=n%label_step==0;r0=tick0 if major else tick0+3
            A.line(fd,[(cx+math.cos(angle)*r0,cy+math.sin(angle)*r0),(cx+math.cos(angle)*tick1,cy+math.sin(angle)*tick1)],color,1.8 if major else .85)
            gx=233+math.cos(angle)*numeral_radius;gy=233+math.sin(angle)*numeral_radius
            if major and not(278<=gx<=470 and 199<=gy<=267):
                label=12 if hour12 and n==0 else n
                A.text(fd,(gx-offset,gy-offset),f'{label:02d}',label_size or (15 if size<466 else 14),color,index=10)
            if n==0:
                mx=cx+math.cos(angle)*(tick1-3);my=cy+math.sin(angle)*(tick1-3)
                A.ellipse(fd,(mx-2,my-2,mx+2,my+2),'#6ca9c8')
        # Static aperture occludes the moving disc markings; the actual current
        # value is part of this native frame, upright and centered in the opening.
        keep=Image.new('L',frame.size,255);kd=ImageDraw.Draw(keep)
        A.rect(kd,(288-offset,209-offset,460-offset,257-offset),0,r=24)
        frame.putalpha(ImageChops.multiply(frame.getchannel('A'),keep));fd=ImageDraw.Draw(frame)
        value=12 if hour12 and state==0 else state
        # Each current value is optically warped, rather than simply enlarged.
        glyph=lens_readout(value,233+numeral_radius)
        frame.alpha_composite(glyph,(round((cx+numeral_radius-32)*S),round((cy-24)*S)))
        key=f'{prefix}-{state}';A.save(key,clip_screen(frame,offset,offset));keys.append(key)
    return keys

hours=rotating_disc(theme+'-hour-disc',228,119,88,99,107,'#8fa4b7',count=12,label_step=1,label_size=14,hour12=True)
minutes=rotating_disc(theme+'-minute-disc',360,53,143,168,176,'#8fa4b7')
seconds=rotating_disc(theme+'-second-disc',466,0,199,216,225,'#96aabd')
window,wd=A.canvas(180,60)
# Light follows the lens surface normal: one fine Fresnel rim, broad low-opacity
# reflections and a narrow lower caustic. No oval strokes cross the reading area.
cap=Image.new('RGBA',window.size);cp=[]
for yy in range(cap.height):
    v=(yy/S-8)/48
    for xx in range(cap.width):
        gx=284+(xx+.5)/S;gy=201+(yy+.5)/S
        depth,nx,ny=lens_surface(gx,gy)
        if depth<0:cp.append((0,0,0,0));continue
        light=max(0,-.35*nx-.8*ny)
        rim=(55+145*light)*math.exp(-depth/.70)
        reflection=12*math.exp(-((v-.20)/.22)**2)
        reflection+=10*math.exp(-((gy-(222+.12*(gx-374)))/8)**2)*math.exp(-((gx-374)/130)**2)
        caustic=18*max(0,ny)*math.exp(-((depth-1.3)/.8)**2)
        cp.append((205,225,238,round(rim+reflection+caustic)))
cap.putdata(cp)
cap_mask=Image.new('L',cap.size);cm=ImageDraw.Draw(cap_mask)
A.rect(cm,(4,8,176,56),255,r=24)
cap.putalpha(ImageChops.multiply(cap.getchannel('A'),cap_mask));window.alpha_composite(cap)
A.save(theme+'-fixed-window',window)
# Raw hour values index this twelve-frame set modulo twelve, preserving 12 at
# midnight/noon independently of the watch's global 12/24-hour preference.
radial_aod=A.aod(theme,True)
aod_hours=A.labels(theme+'-aod-hours',[f'{12 if h==0 else h:02d}' for h in range(12)],58,60,52,'#a4aea0')
radial_aod[1]=A.art(aod_hours[0],163,201,4,aod_hours)
scenes.append({'theme':theme,'name':'MotiyarStudios Radial Instruments','kind':'digital','revision':8,
  'description':'Three anticlockwise discs show 12-hour time through a clear reading lens with optically enlarged numerals, refracted disc boundaries and centered motyar / studios branding.',
  'main':[A.art(theme+'-dial',0,0),A.art(hours[0],119,119,4,hours),A.art(minutes[0],53,53,11,minutes),A.art(seconds[0],0,0,15,seconds),A.art(theme+'-fixed-window',284,201)],
  'aod':radial_aod,'hasDate':False,'supportsSeconds':True,'expectedSources':[4,11,15],'referenceImage':3,'hourFormat':'12-hour disc',
  'branding':{'lines':['motyar','studios'],'weights':['Bold','Light'],'center':[233,233],'lineCenters':[[233,222],[233,244]]},
  'readingLens':{'style':'clear lens with surface-normal lighting','sourceNumeralSize':25,'visualMagnification':1.24,'liveValues':True,'runtimeRefraction':False,'precomputedRefraction':True,'backgroundRefraction':True,'ovalReflections':False,'bounds':[288,209,172,48]},
  'clockRegions':{'hours':[301,217,40,34],'minutes':[356,217,40,34],'seconds':[412,217,40,34]},
  'discLayout':{'center':[233,233],'hourRadius':113,'direction':'anticlockwise','degreesPerStep':-6,'zeroAngleDegrees':0,'uprightLabels':True,
    'hours':{'source':4,'frames':12,'degreesPerStep':-30,'placement':[119,119,228,228],'numeralRadius':88,'outerRadius':113,'selectedCenter':[321,233],'readoutROI':[301,217,40,34],'zeroMarkerRadius':104,'labels':['12']+[f'{h:02d}' for h in range(1,12)]},
    'minutes':{'source':11,'frames':60,'degreesPerStep':-6,'placement':[53,53,360,360],'numeralRadius':143,'outerRadius':178,'selectedCenter':[376,233],'readoutROI':[356,217,40,34],'zeroMarkerRadius':173},
    'seconds':{'source':15,'frames':60,'degreesPerStep':-6,'placement':[0,0,466,466],'numeralRadius':199,'outerRadius':228,'selectedCenter':[432,233],'readoutROI':[412,217,40,34],'zeroMarkerRadius':222},
    'fixedWindowROI':[288,209,172,48],'zeroMarkerColor':'#6ca9c8','zeroMarkerSize':2,'cadence':'One native image state per hour, minute or second; no verified subsecond disc animation.'}})

# Larger, aligned typography with a compact date strip and a clean cloud outline.
theme='typographic';im=shaded_surface();d=ImageDraw.Draw(im);ink='#3d5557';muted='#71817e'
A.line(d,[(202,309),(202,355)],muted,.9)
cloudy(im,120,304,ink)
A.roundface(theme+'-dial',im)
hour=A.digits(theme+'-hour',100,180,160,ink,font=ROUND)
minute=A.digits(theme+'-minute',61,130,104,ink,index=12)
weekday=[];day_positions=[]
for index,label in enumerate(['SUN','MON','TUE','WED','THU','FRI','SAT']):
    glyph,_=A.canvas(89,44);plain_text(glyph,(3,22),label,29,ink,index=1,anchor='lm')
    key=f'{theme}-weekday-{index}';native=A.save(key,glyph);weekday.append(key)
    right=native.getchannel('A').point(lambda value:255 if value>32 else 0).getbbox()[2]
    day_positions.append(225+right+3)
day=A.digits(theme+'-day',22,44,31,ink,index=7)
day_layers=[{**A.number(day,x,309,23),'conditions':[{'source':24,'value':index}]} for index,x in enumerate(day_positions)]
scenes.append({'theme':theme,'name':'Ceramic Type','kind':'digital','revision':3,
  'description':'Rounded hours and fine minutes share one baseline, with a compact weekday/date strip and a decorative filled cloud and sun.',
  'main':[A.art(theme+'-dial',0,0),A.number(hour,61,118,1),A.number(minute,271,163,11),A.art(weekday[0],225,311,24,weekday),*day_layers],
  'hasDate':True,'dateBox':{'x':223,'y':307,'w':132,'h':50},'supportsSeconds':False,'expectedSources':[1,11,23,24],
  'decorativeWeatherIcon':True,'referenceImage':10,'clockRegions':{'hours':[61,118,200,180],'minutes':[271,163,122,130]},
  'typography':{'hourSize':160,'minuteSize':104,'weekdaySize':29,'daySize':31,'timeBaseline':269,'dateBaseline':344,'weekdayLeft':225,'dayLeftByWeekday':day_positions,'weekdayDayGap':[6,10]}})

A.finish(scenes)
