"""Native weather/minimal faces and the photo-backed Zenith dial."""
from PIL import Image,ImageDraw,ImageFilter,ImageChops
import math
import native_face_art as a

a.configure('weather');S=a.S
scenes=[]
TEMP_SOURCE=0x5f
CASUAL='/System/Library/Fonts/Supplemental/Comic Sans MS.ttf'


def cloud_path(cx,cy,scale):
    points=[(cx-19*scale,cy+15*scale)]
    def cubic(p,c1,c2,q):
        for n in range(1,25):
            t=n/24;u=1-t
            points.append((cx+(u**3*p[0]+3*u*u*t*c1[0]+3*u*t*t*c2[0]+t**3*q[0])*scale,cy+(u**3*p[1]+3*u*u*t*c1[1]+3*u*t*t*c2[1]+t**3*q[1])*scale))
    cubic((-19,15),(-39,15),(-39,-13),(-18,-13))
    cubic((-18,-13),(-13,-34),(12,-34),(18,-14))
    cubic((18,-14),(40,-15),(42,15),(22,15))
    points.append(points[0]);return points


def weather_icon(im,cx,cy,scale=1,color='#252c25',sun=True,rain=False,filled=False):
    """A clean decorative motif; it is not bound to an unverified condition ID."""
    icon,d=a.canvas(150,130);ox,oy=75,75
    if sun:
        sx,sy=ox+24*scale,oy-25*scale;r=14*scale
        a.ellipse(d,(sx-r,sy-r,sx+r,sy+r),None,color,1.8*scale)
        for deg in range(0,360,45):
            ang=math.radians(deg)
            a.line(d,[(sx+math.sin(ang)*19*scale,sy-math.cos(ang)*19*scale),(sx+math.sin(ang)*24*scale,sy-math.cos(ang)*24*scale)],color,1.8*scale)
    pts=cloud_path(ox,oy,scale)
    # Clear the sun where it passes behind the cloud rather than leaving
    # intersecting circles inside the cloud body.
    mask=Image.new('L',icon.size);a.poly(ImageDraw.Draw(mask),pts,255)
    icon.putalpha(ImageChops.subtract(icon.getchannel('A'),mask));d=ImageDraw.Draw(icon)
    if filled:a.poly(d,pts,color)
    else:a.line(d,pts,color,2.1*scale)
    if rain:
        for xx in (-14,0,14):
            x=ox+xx*scale;y=oy+23*scale
            a.poly(d,[(x,y-3.5*scale),(x-2.6*scale,y+2*scale),(x+2.6*scale,y+2*scale)],color)
            a.ellipse(d,(x-2.6*scale,y-1*scale,x+2.6*scale,y+4.2*scale),color)
    im.alpha_composite(icon,(round((cx-ox)*S),round((cy-oy)*S)))


def battery_shape(d,cx,cy,value,color,w=25,h=13,vertical=False):
    if vertical:
        a.rect(d,(cx-w/2,cy-h/2,cx+w/2,cy+h/2),None,color,1.2,r=2)
        a.rect(d,(cx-2,cy-h/2-2,cx+2,cy-h/2),color)
        pad=2.5;avail=h-pad*2;filled=avail*max(0,min(100,value))/100
        if filled>.1:a.rect(d,(cx-w/2+pad,cy+h/2-pad-filled,cx+w/2-pad,cy+h/2-pad),color,r=.5)
    else:
        a.rect(d,(cx-w/2,cy-h/2,cx+w/2,cy+h/2),None,color,1.2,r=2)
        a.rect(d,(cx+w/2,cy-2,cx+w/2+2,cy+2),color)
        pad=2.5;filled=(w-pad*2)*max(0,min(100,value))/100
        if filled>.1:a.rect(d,(cx-w/2+pad,cy-h/2+pad,cx-w/2+pad+filled,cy+h/2-pad),color,r=.5)


def battery_frames(p,x,y,style,color,font=a.FONT,index=7):
    frames=[]
    for value in range(101):
        if style=='inline':
            w,h=114,48;im,d=a.canvas(w,h);battery_shape(d,16,24,value,color,24,13)
            a.text(d,(75,24),str(value)+'%',30,color,font,index)
        elif style=='stack':
            w,h=82,62;im,d=a.canvas(w,h);battery_shape(d,41,14,value,color,29,15)
            a.text(d,(41,45),str(value)+'%',23,color,font,index)
        else:
            w,h=92,74;im,d=a.canvas(w,h);battery_shape(d,46,16,value,color,14,21,True)
            a.text(d,(46,53),str(value)+'%',22,color,font,index)
        key=f'{p}-battery-{value}';a.save(key,im);frames.append(key)
    return a.art(frames[0],x,y,36,frames)


def surface(base=(246,246,242),depth=17):
    im=Image.new('RGBA',(466,466));pix=[]
    for y in range(466):
        for x in range(466):
            dx=(x-233)/233;dy=(y-233)/233;r=math.hypot(dx,dy);light=(-dx-dy)*.5
            shade=depth*math.exp(-max(0,1-r)*233/12)*(.65+.35*light);v=light*4-r*r*2-shade
            pix.append(tuple(max(0,min(255,round(c+v))) for c in base)+(255,))
    im.putdata(pix);return im.resize((466*S,466*S),Image.Resampling.BICUBIC)


def glyphs(p,w,h,size,color,index=0,font=a.FONT):return a.digits(p,w,h,size,color,font=font,index=index)
def enum(p,vals,w,h,size,color,index=0,font=a.FONT):return a.labels(p,vals,w,h,size,color,font=font,index=index)


def aligned_labels(p,values,w,h,size,color,align='center',font=a.FONT,index=0):
    keys=[]
    for n,label in enumerate(values):
        im,d=a.canvas(w,h)
        if align=='right':
            f=a.ImageFont.truetype(font,round(size*S),index=index)
            d.text(((w-1)*S,h*S/2),label,font=f,fill=color,anchor='rm')
        else:a.text(d,(w/2,h/2),label,size,color,font,index)
        key=f'{p}-{n}';a.save(key,im);keys.append(key)
    return keys


def minimal_calendar(p,y):
    ink='#444b43'
    day=glyphs(p+'-day',14,38,25,ink,7)
    mon=enum(p+'-month',['Dec','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov'],52,38,25,ink,7)
    # Native weekday conditions select seven measured row layouts. That keeps
    # Friday and Wednesday equally centered without padding the shorter word
    # out to the width of the longest weekday.
    layers=[];bounds=[];font=a.ImageFont.truetype(a.FONT,25*S,index=7)
    for weekday,label in enumerate(['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']):
        width=math.ceil(font.getlength(label)/S)+2;left=round((466-width-24-28-52)/2)
        frame,d=a.canvas(width,38);a.text(d,(width/2,19),label,25,ink,index=7)
        key=f'{p}-weekday-{weekday}';a.save(key,frame)
        condition=[{'source':24,'value':weekday}]
        layers.extend([a.art(key,left,y,24,[key],conditions=condition),
            {**a.number(day,left+width+12,y,23),'conditions':condition},
            a.art(mon[0],left+width+52,y,21,mon,conditions=condition)])
        bounds.append((left,left+width+104))
    lo=min(x for x,_ in bounds);hi=max(x for _,x in bounds)
    return layers,{'x':lo-1,'y':y,'w':hi-lo+2,'h':38}


def temp(p,x,y,size,color,width=18,height=34,font=a.FONT,index=7):
    keys=glyphs(p+'-temperature',width,height,size,color,index,font)
    src=TEMP_SOURCE
    layers=[{**a.number(keys,x,y,src), 'sub':6,'max':1000,
        'conditions':[{'source':src,'op':'gte','value':-99},{'source':src,'op':'lte','value':99}]}]
    sign,d=a.canvas(13,height);a.text(d,(6.5,height/2),'-',size,color,font,index);a.save(p+'-minus',sign)
    layers.append(a.art(p+'-minus',x-13,y,conditions=[{'source':src,'op':'lt','value':0},{'source':src,'op':'gte','value':-99}]))
    missing,d=a.canvas(width*2+13,height);a.text(d,((width*2+13)/2,height/2),'– –',size*.7,color,font,index);a.save(p+'-temp-missing',missing)
    layers.extend([a.art(p+'-temp-missing',x-13,y,conditions=[{'source':src,'op':'lt','value':-99}]),a.art(p+'-temp-missing',x-13,y,conditions=[{'source':src,'op':'gte','value':100}])])
    return layers


def footprints(d,cx,cy,c):
    for x,y in [(cx-3,cy-3),(cx+3,cy+3)]:
        a.ellipse(d,(x-1.7,y-3,x+1.7,y+3),c);a.ellipse(d,(x-1.1,y-5.4,x+1.1,y-3.4),c)


def heart(d,cx,cy,c):
    pts=[]
    for n in range(65):
        t=n*math.tau/64
        pts.append((cx+math.sin(t)**3*6.2,cy-(13*math.cos(t)-5*math.cos(2*t)-2*math.cos(3*t)-math.cos(4*t))*.4))
    a.line(d,pts,c,1.1)


def scene(p,name,main,**kw):
    return {'theme':p,'name':name,'kind':'digital','revision':2,'description':kw.pop('description'),'main':main,
        'weatherNote':'The improved weather pictogram is a decorative motif. Native current temperature uses stock-exercised source0x5f; no weather-condition source is verified.',
        'temperatureSourceEvidence':'Pinned FMC sources.ts labels0x36/0x5f as temperature; available Function and Elaborate_2 stock fixtures use0x5f with number sub6/max1000. Function has noData marker1000.',
        'metrics':[TEMP_SOURCE,36],**kw}


# Weather Minimal: larger thin time, compact sentence-case date, larger status typography.
p='weather-minimal';im=surface();weather_icon(im,233,108,1.12,'#30382e',sun=True);d=ImageDraw.Draw(im)
a.text(d,(233,224),':',112,'#50594c',index=12)
a.text(d,(195,358),'°',30,'#3e4839',index=7)
a.text(d,(166,399),'TEMP',11,'#737e6b');a.text(d,(302,399),'BATTERY',11,'#737e6b')
a.roundface(p+'-dial',im);digits=glyphs(p+'-time',62,128,112,'#182017',12)
cal,box=minimal_calendar(p,277)
main=[a.art(p+'-dial',0,0),a.number(digits,88,163,1),a.number(digits,254,163,11),*cal,
      *temp(p,141,337,34,'#3e4839',22,44),battery_frames(p,244,337,'inline','#3e4839')]
mark,md=a.canvas(30,234);a.rect(md,(13,2,16,29),'#be272e');a.save(p+'-second-marker',mark,pivotX=15,pivotY=232)
main.append(a.pointer(p+'-second-marker',233,233,114))
scenes.append(scene(p,'Weather Minimal',main,description='Larger thin time, a compact sentence-case date and clearer live temperature and battery indicators on a softly recessed pale dial.',hasDate=True,dateBox=box,supportsSeconds=True))


# Weather Arc: sentence-case text, tighter vertical rhythm, clearer real status indicators.
p='weather-arc';im=surface();d=ImageDraw.Draw(im);a.text(d,(233,138),':',102,'#252c23',index=12)
curve=[(x,282+47*((x-233)/233)**2) for x in range(467)]
a.poly(d,curve+[(466,466),(0,466)],'#0b0e0a');a.poly(d,[(280,283),(466,329),(466,466),(407,466)],'#242824')
gold='#e3c24a'
# A filled sun sits behind a filled cloud; the small clear seam preserves the
# overlap instead of letting both silhouettes merge into one yellow shape.
icon,idraw=a.canvas(150,130);ox,oy=75,75;scale=.86
sx,sy=ox+24*scale,oy-25*scale;radius=14*scale
a.ellipse(idraw,(sx-radius,sy-radius,sx+radius,sy+radius),gold)
for deg in range(0,360,45):
    ang=math.radians(deg)
    a.line(idraw,[(sx+math.sin(ang)*19*scale,sy-math.cos(ang)*19*scale),(sx+math.sin(ang)*24*scale,sy-math.cos(ang)*24*scale)],gold,1.6)
points=cloud_path(ox,oy,scale);occlusion=Image.new('L',icon.size);a.poly(ImageDraw.Draw(occlusion),points,255)
occlusion=occlusion.filter(ImageFilter.MaxFilter(7))
icon.putalpha(ImageChops.subtract(icon.getchannel('A'),occlusion));a.poly(ImageDraw.Draw(icon),points,gold)
im.alpha_composite(icon,(60*S,260*S));d=ImageDraw.Draw(im)
a.line(d,[(225,309),(225,393)],'#87917c',.8)
a.text(d,(167,372),'°',26,'#f3f5ed',index=7)
footprints(d,263,322,gold);heart(d,263,366,gold)
a.text(d,(316,346),'STEPS',10,gold);a.text(d,(316,390),'PULSE',10,gold)
a.roundface(p+'-dial',im)
digits=glyphs(p+'-time',57,114,103,'#192117',12)
wd=enum(p+'-weekday',['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],260,42,30,'#2c3527',10)
day=glyphs(p+'-day',14,35,24,'#56604f',7);mon=enum(p+'-month',['Dec','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov'],55,35,24,'#56604f',7)
steps=glyphs(p+'-steps',14,32,24,'#e5e9de');hr=glyphs(p+'-hr',14,32,24,'#e5e9de')
# The complete battery group is centered for each native 0..100 state. Its
# fill and percentage always read the same live battery source.
frames=[];font=a.ImageFont.truetype(a.FONT,22*S,index=7)
for value in range(101):
    frame,fd=a.canvas(128,36);label=str(value)+'%';label_width=font.getlength(label)/S
    left=(128-26-12-label_width)/2
    battery_shape(fd,left+12,18,value,'#e7d266',24,13)
    a.text(fd,(left+38+label_width/2,18),label,22,'#e7d266',index=7)
    key=f'{p}-battery-{value}';a.save(key,frame);frames.append(key)
main=[a.art(p+'-dial',0,0),a.number(digits,96,83,1),a.number(digits,256,83,11),a.art(wd[0],103,187,24,wd),a.art(mon[0],185,229,21,mon),a.number(day,252,229,23),
      *temp(p,105,353,43,'#f5f6f1',25,54),a.number(steps,285,305,25,5,padZero=False),a.number(hr,285,349,26,3,padZero=False),a.art(frames[0],169,402,36,frames)]
scenes.append(scene(p,'Weather Arc',main,revision=3,description='Filled cloud-and-sun artwork beside live temperature, aligned steps and pulse on the right, and a centered live battery indicator below.',hasDate=True,dateBox={'x':102,'y':186,'w':262,'h':79},supportsSeconds=False,metrics=[TEMP_SOURCE,36,25,26],
    lowerPanelLayout={'weatherIconCenter':[135,335],'temperature':[105,353,50,54],'steps':[285,305],'pulse':[285,349],'statusIconX':263,'batteryBox':[169,402,128,36],'batteryCenter':[233,420]}))


# Orbit: casual handwritten numerals and a larger rain-cloud motif, following the reference.
p='orbit';im=surface((243,244,239),24)
orb,od=a.canvas(116,104)
for angle in (-28,28,90):
    layer,ld=a.canvas(116,104);a.ellipse(ld,(26,5,90,87),None,'#8c928a',.7);layer=layer.rotate(angle,resample=Image.Resampling.BICUBIC,center=(58*S,46*S));orb.alpha_composite(layer)
shadow,sd=a.canvas(116,104);a.ellipse(sd,(39,85,80,90),(0,0,0,38));orb.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(3*S)));od=ImageDraw.Draw(orb)
for x,y in [(58,5),(59,87),(33,28),(82,67)]:
    a.ellipse(od,(x-2.3,y-2.3,x+2.3,y+2.3),'#b1a36d');a.ellipse(od,(x-1.3,y-1.5,x+.2,y),'#eee3b9')
im.alpha_composite(orb,(175*S,23*S));weather_icon(im,202,155,.61,'#222b1f',sun=False,rain=True,filled=True);d=ImageDraw.Draw(im)
a.text(d,(282,151),'°',22,'#273421',font=CASUAL)
a.text(d,(216,225),':',56,'#24301e',font=CASUAL)
a.text(d,(233,344),'steps',10,'#77836e',font=CASUAL);a.roundface(p+'-dial',im)
digits=glyphs(p+'-time',34,68,56,'#202c1a',font=CASUAL);sec=glyphs(p+'-sec',14,32,23,'#394a30',font=CASUAL);steps=glyphs(p+'-steps',17,34,25,'#394a30',font=CASUAL)
wd=enum(p+'-weekday',['Sun,','Mon,','Tue,','Wed,','Thu,','Fri,','Sat,'],66,34,23,'#394a30',font=CASUAL)
mon=enum(p+'-month',['Dec','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov'],52,34,23,'#394a30',font=CASUAL)
day=glyphs(p+'-day',14,34,23,'#394a30',font=CASUAL);am=enum(p+'-ampm',['AM','PM'],35,28,18,'#34432c',font=CASUAL)
main=[a.art(p+'-dial',0,0),*temp(p,245,136,27,'#273421',17,36,font=CASUAL,index=0),a.number(digits,129,193,1),a.number(digits,235,193,11),a.number(sec,326,209,15),
      a.art(am[0],86,216,19,am,conditions=[{'source':20,'value':0}]),a.art(wd[0],154,269,24,wd),a.art(mon[0],222,269,21,mon),a.number(day,280,269,23),
      a.number(steps,199,310,25,5,padZero=False),battery_frames(p,187,354,'portrait','#34432c',font=CASUAL,index=0)]
scenes.append(scene(p,'Orbit Minimal',main,description='Casual handwritten-style numerals, an enlarged rain-cloud motif and aligned live temperature, seconds, calendar, steps and battery.',hasDate=True,dateBox={'x':153,'y':268,'w':156,'h':36},supportsSeconds=True,metrics=[TEMP_SOURCE,36,25],typeface='Comic Sans MS, matching the casual rounded character of the supplied reference.'))

from zenith_photo import build_zenith
scenes.append(build_zenith(a))
a.finish(scenes)
