"""Loopback-only preview server. Stores render checks and device test outcomes locally."""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import json, os
from urllib.parse import urlsplit, parse_qs

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent if HERE.name=='source' else HERE.parent/'outputs/braun-round'
class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*a,**kw): super().__init__(*a,directory=str(ROOT),**kw)
    def do_POST(self):
        if self.headers.get('Origin') not in (None,'http://127.0.0.1:48762','http://localhost:48762'):
            self.send_error(403);return
        size=int(self.headers.get('Content-Length',0))
        if size>3_000_000:self.send_error(413);return
        data=self.rfile.read(size)
        url=urlsplit(self.path);theme=parse_qs(url.query).get('theme',['white'])[0]
        variants=json.loads((ROOT/'variants.json').read_text())
        rendered={v.get('preview') for v in variants}|{v.get('aodPreview') for v in variants}|{'preview.png','black-preview.png','aod-preview.png'}
        if url.path.startswith('/api/render/') and url.path.rsplit('/',1)[1] in rendered:
            if not data.startswith(b'\x89PNG\r\n\x1a\n'): self.send_error(400);return
            (ROOT/url.path.rsplit('/',1)[1]).write_bytes(data)
        elif url.path in ('/api/hardware','/api/render-checks'):
            variant=next((v for v in variants if v['theme']==theme),None)
            if not variant:self.send_error(404);return
            report_name=variant.get('validationFile') or ('black-validation.json' if theme=='black' else 'validation.json')
            report_path=ROOT/report_name
            report=json.loads(report_path.read_text())
            report['hardware' if url.path=='/api/hardware' else 'browserRendering']=json.loads(data)
            report_path.write_text(json.dumps(report,indent=2)+'\n')
        else:self.send_error(404);return
        self.send_response(200);self.end_headers();self.wfile.write(b'OK')
    def log_message(self,fmt,*args):
        if self.command=='POST' or str(args[1])!='200':super().log_message(fmt,*args)
print('Braun Round preview: http://127.0.0.1:48762',flush=True)
ThreadingHTTPServer(('127.0.0.1',48762),Handler).serve_forever()
