"""Import supplied dial photographs and add native moving hands/calendars."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFilter
import hashlib,json,math
import native_face_art as A
from photo_hands import make_hand,make_subhand,make_cap
from photo_calendar import build_calendar

A.configure('photo-dials')
S=A.S
REFERENCES=A.OUT/'source/photo-dials'
configs=json.loads((REFERENCES/'layout.json').read_text())
scenes=[]

def point(config,p):
    l,t,r,b=config['crop']
    return (round((p[0]-l+.5)*466/(r-l)-.5),round((p[1]-t+.5)*466/(b-t)-.5))

def scale(config):
    l,t,r,b=config['crop'];return (466/(r-l)+466/(b-t))/2

def union(boxes):
    if not boxes:return None
    x=min(b['x'] for b in boxes);y=min(b['y'] for b in boxes)
    r=max(b['x']+b['w'] for b in boxes);bottom=max(b['y']+b['h'] for b in boxes)
    return {'x':x,'y':y,'w':r-x,'h':bottom-y}

def minute30_frames(prefix,tip,size,metal):
    keys=[];c=size/2
    colors={'gold':'#ead49d','rose':'#ebc5af','silver':'#c3d0d5','dark':'#26333c'}
    for minute in range(60):
        a=(minute%30)*math.tau/30
        pts=[(c-math.sin(a)*4,c+math.cos(a)*4),(c+math.sin(a)*tip,c-math.cos(a)*tip)]
        im,d=A.canvas(size,size)
        shadow,sd=A.canvas(size,size);A.line(sd,[(x+1,y+2) for x,y in pts],(0,0,0,65),2)
        im.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(1.4*S)));d=ImageDraw.Draw(im)
        A.line(d,pts,'#111c23',2.7);A.line(d,pts,colors[metal],1.5)
        key=f'{prefix}-{minute}';A.save(key,im);keys.append(key)
    return keys

def date_pointer(config,prefix):
    spec=config['datePointer'];cx,cy=point(config,spec['center']);radius=spec['radius']*scale(config)
    tip=spec['pointerRadius']*scale(config);size=2*math.ceil(radius+4);c=size/2;keys=[]
    for day in range(32):
        im,d=A.canvas(size,size)
        if day:
            angle=day*math.tau/31
            end=(c+math.sin(angle)*tip,c-math.cos(angle)*tip)
            A.line(d,[(c-math.sin(angle)*5,c+math.cos(angle)*5),end],'#14222d',3.2)
            A.line(d,[(c,c),(end[0],end[1])],'#f1eee2',1.65)
        key=f'{prefix}-{day}';A.save(key,im);keys.append(key)
    key,half=make_cap(A,prefix+'-cap',4,'silver')
    return [A.art(keys[0],cx-size//2,cy-size//2,23,keys),A.art(key,cx-half,cy-half)],\
        {'x':cx-size//2,'y':cy-size//2,'w':size,'h':size},\
        {'center':[cx,cy],'radius':radius,'pointerRadius':tip,'source':23,'frames':32,'dayAngle':'day * 360 / 31'}

for config in configs:
    theme=config['theme'];source=REFERENCES/config.get('sourceFile',f"{config['attachment']:02}.png")
    original=REFERENCES/config.get('originalSourceFile',f"{config['attachment']:02}.png")
    photo=Image.open(source).convert('RGBA')
    face=photo.resize((466,466),Image.Resampling.LANCZOS,box=tuple(config['crop']))
    mask=Image.new('L',(466,466));ImageDraw.Draw(mask).ellipse((0,0,465,465),fill=255)
    background=Image.new('RGBA',(466,466),'black');background.paste(face,(0,0),mask)
    native=A.save_native(theme+'-dial',background,4)
    mx,my=point(config,config['mainPivot']);metal=config['metal']
    layers=[A.art(theme+'-dial',0,0)]
    calendar,calendar_boxes,calendar_meta=build_calendar(A,config,native)
    layers+=calendar
    pointer_meta=None
    if config.get('datePointer'):
        pointer_layers,pointer_box,pointer_meta=date_pointer(config,theme+'-date-pointer')
        layers+=pointer_layers;calendar_boxes.append(pointer_box)
    registers=[];sub_caps=[]
    for sub in config.get('subdials',[]):
        cx,cy=point(config,sub['center']);radius=sub['radius']*scale(config)
        tip=round(radius*.70);key=theme+'-sub-'+sub['name']
        if sub['kind']=='minute30':
            size=2*math.ceil(radius+4);frames=minute30_frames(key,tip,size,metal)
            layers.append(A.art(frames[0],cx-size//2,cy-size//2,11,frames))
            source_id=11;kind='picker'
        else:
            source_id={'hour12':10,'minute':14,'second':114}[sub['kind']]
            make_subhand(A,key,tip,metal)
            layers.extend([A.pointer(key+'-shadow',cx,cy,source_id),A.pointer(key,cx,cy,source_id)])
            kind='hand'
        registers.append({'name':sub['name'],'center':[cx,cy],'radius':radius,'source':source_id,'scale':sub['scale'],'kind':sub['kind'],'widget':kind})
        cap_radius=max(3.4,min(6.5,radius*.07),sub.get('holeRadius',0)*scale(config)+.5)
        ck,half=make_cap(A,key+'-cap',cap_radius,metal);sub_caps.append(A.art(ck,cx-half,cy-half))
    layers+=sub_caps
    safe_radius=min(mx,my,465-mx,465-my)
    for hand,tip,width,source_id in [('hour',round(safe_radius*.58),8.5,10),('minute',round(safe_radius*.85),6,14),('second',round(safe_radius*.92),1.4,15)]:
        key=theme+'-'+hand
        tip=config.get('nativeHandLengths',{}).get(hand,tip)
        style='chrono' if config['handStyle']=='baton' else config['handStyle']
        make_hand(A,key,tip,width,metal,style,second=hand=='second')
        layers.extend([A.pointer(key+'-shadow',mx,my,source_id),A.pointer(key,mx,my,source_id)])
    default_holes={3:26,4:24,5:26,8:31,9:27,7:26,11:12,13:17}
    hole=config.get('mainHoleRadius',default_holes.get(config['attachment'],12))*scale(config)
    cap_radius=max(5.5,hole+.8)
    ck,half=make_cap(A,theme+'-main-cap',cap_radius,metal);layers.append(A.art(ck,mx-half,my-half))
    scene={'theme':theme,'name':config['name'],'kind':'analog','revision':1,'main':layers,
        'description':'The supplied dial photograph with live, aligned hands'+(', clock-driven subdials' if registers else '')+(' and calendar.' if calendar_boxes else '.'),
        'mainPivot':[mx,my],'photoMainSources':[10,14,15],'photoRegisters':registers,
        'hasDate':bool(calendar_boxes),'supportsSeconds':True,'artworkMode':'supplied-image',
        'referenceCredit':'User-supplied dial photograph. Brand marks and any source watermarks retained.',
        'sourceImageSha256':hashlib.sha256(original.read_bytes()).hexdigest(),
        'photoSource':{'attachment':config['attachment'],'originalFile':original.name,'dialFile':source.name,
            'sourceSize':list(photo.size),'crop':config['crop'],'sourcePivot':config['mainPivot'],
            'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
            'processing':'Direct crop, one Lanczos fit to 466 × 466, circular mask and native RGB565 dithering.',
            'handRemovalRetouch':bool(config.get('retouched'))},
        'referenceNote':'Subdial pointers show clock values, not an interactive stopwatch.' if registers else 'Live analogue clock.',
        'calendarLayout':calendar_meta}
    if calendar_boxes:scene['dateBox']=union(calendar_boxes)
    if pointer_meta:scene['datePointerLayout']=pointer_meta
    scenes.append(scene)

A.finish(scenes)
(REFERENCES/'native-layout.json').write_text(json.dumps([{'theme':s['theme'],'mainPivot':s['mainPivot'],'photoRegisters':s['photoRegisters'],'calendarLayout':s['calendarLayout'],'dateBox':s.get('dateBox'),'photoSource':s['photoSource']} for s in scenes],indent=2)+'\n')
