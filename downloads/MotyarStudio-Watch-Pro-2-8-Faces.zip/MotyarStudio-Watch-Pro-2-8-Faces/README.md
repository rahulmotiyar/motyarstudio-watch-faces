# MotyarStudio · Eight faces for CMF Watch Pro 2

Share **MotyarStudio-Watch-Pro-2-8-Faces.zip**. The recipient unzips it, starts the included local installer and transfers a face directly to their watch over Bluetooth. **No USB connection is needed.**

This bundle contains exactly eight native 466 × 466 faces, each with a separate always-on screen and watch thumbnail. The previews render the actual compiled files. The installer and code-drawn artwork were created with AI assistance; Zenith uses the supplied dial photograph with live hands overlaid.

## Included faces

| Face | Native file | Revision | Details |
| --- | --- | --- | --- |
| Braun Round | `braun-round.bin` | 5 | White dial, black hands, yellow seconds and recessed date. |
| Braun Black | `braun-black.bin` | 5 | Charcoal dial, silver-white hands, yellow seconds and recessed date. |
| Casio World | `casio-world.bin` | 2 | Circular LCD, calendar, small analogue clock and Amsterdam map target. |
| Braun Subdials | `braun-subdials.bin` | 3 | Enlarged recessed subdials, hollow hands, soft shadows and angled date. |
| Skagen Dark | `skagen-dark.bin` | 3 | Enlarged subdials at 12, 9 and 6; branding at 3; silver and gold hands. |
| MotyarStudio | `motyarstudio.bin` | 4 | Ivory dial, generous outer padding, four minute strokes between hour numerals and orange seconds. |
| Xeric Mint | `xeric-mint.bin` | 2 | Mint technical scales, larger numerals and orange-accented hands. |
| Zenith Ice | `zenith-ice.bin` | 2 | Image-based ice-blue dial, original details and live main/subdial hands. |

Open the [face gallery](collection.html) through the local server to browse all eight.

![The eight included watch faces](collection-preview.png)

## What the recipient needs

- A **CMF Watch Pro 2**, charged and nearby. Other watch models are untested.
- A computer with working Bluetooth and **desktop Microsoft Edge or Google Chrome** with Web Bluetooth available.
- **Python 3**, to run the included server. No Python packages, Node.js or build tools are needed to install the supplied faces.

Use the desktop browser for installation. Safari, Firefox and opening `index.html` directly from disk do not provide this installer’s required Web Bluetooth workflow. A company-managed browser may restrict Bluetooth access.

## Start the gallery and installer

1. Extract the entire ZIP into a normal, writable folder. Keep its files and subfolders together.
2. Open Terminal or Command Prompt in the extracted `MotyarStudio-Watch-Pro-2-8-Faces` folder.
3. Start the local server:

   **macOS / Linux**

   ```sh
   python3 source/serve.py
   ```

   **Windows**

   ```bat
   py -3 source/serve.py
   ```

   If Windows has `python` rather than the `py` launcher, use `python source/serve.py`.

4. Leave the terminal open. In Edge or Chrome, open:
   - Gallery: **http://127.0.0.1:48762/collection.html**
   - Installer: **http://127.0.0.1:48762/**

The included `start-mac.command` and `start-windows.cmd` launchers run the same commands. The terminal method also works if your system does not open the launcher directly.

The localhost address opens this bundle only on the computer running the server. Send the ZIP to your friend; sending your localhost link will not give them access.

If the port is already in use, stop the other server or run `python3 source/serve.py --port 48763` (Windows: `py -3 source/serve.py --port 48763`), then use **http://127.0.0.1:48763/collection.html**.

## Install a face over Bluetooth

1. In the gallery, choose **Preview & install** beneath a face. Review its live preview and **Always-on preview**. **Reference time** freezes the preview at 10:08:35 on the 29th for comparison.
2. Temporarily turn off Bluetooth on the paired phone, or otherwise release its connection to the watch. Keep computer Bluetooth on.
3. Click **Connect watch**, select the Watch Pro 2 in the browser picker and allow the connection. Read the displayed model and firmware.
4. Use **Choose a face to replace** before pressing Install. Select a face you are willing to replace, or explicitly choose **Add as a new face** if space is available.
5. Click **Install face** and keep the watch nearby until the transfer completes. Avoid changing faces or closing the browser during transfer.
6. Select/check the face on the physical watch, including its time, date where present and always-on display.
7. Click **Disconnect**, then restore the phone’s Bluetooth connection. Stop the local server with **Ctrl+C** when finished.

The installer changes a watch face; it does not replace the watch firmware. Available watch storage determines how many faces can be installed at once. The eight files in this bundle are independent choices.

## Sharing and Nothing X

Share the **complete ZIP**, retaining this README, source and license files. A recipient who already has a compatible native-face installer can also use the individual `.bin` files. PNG previews are pictures, not the functional watch faces.

This bundle uses the included Bluetooth installer. Sharing it does **not** publish the designs into Nothing X’s public face gallery. Appearance in Nothing X’s installed-face list has not been verified; select the installed face on the watch itself. This bundle provides no app-store publishing or cloud-sync integration.

## Display and data notes

- Analogue subdials show clock values, not an interactive stopwatch. Braun Subdials and Skagen show minutes, 24-hour time and seconds.
- Casio’s **AMS** label and reticle are fixed to Amsterdam. They are not GPS tracking or an independent world-time zone. Its time follows the watch’s time and 12/24-hour setting.
- Zenith retains the supplied image’s typography, texture and recessed subdials. Its left subdial shows the current minute; the right shows the minute modulo 30 to match the original 30-minute scale; the lower one shows seconds.
- MotyarStudio retains its earlier internal `bai-clock` theme/identity for update compatibility. Its visible name and downloadable file use MotyarStudio.
- Always-on displays are deliberately simpler and darker than the main faces. Watch settings control when AOD is shown.

## If something does not load or connect

- **Page unavailable:** keep the Python server running and check that the browser port matches the terminal output.
- **No watch in the picker:** check computer Bluetooth, release the phone’s connection and bring the watch closer. Disconnect another browser connection before trying again.
- **Empty replacement list:** disconnect and reconnect so the watch sends its face list again. The list combines watch notifications with this browser’s successful installation history; a different computer may not have that history.
- **Watch full:** choose an existing face to replace. Adding a new face requires available watch storage.
- **File integrity error:** extract a fresh copy of the complete ZIP. The installer checks each native file against the SHA-256 recorded in `variants.json`.

## Validation and privacy

`package-validation.json` records the checks performed for this release. Each face also has a validation report named in `variants.json`, separating native-format checks, browser rendering and hardware testing. `SHA256SUMS.txt` lists the packaged file hashes.

The included files passed native parsing/round-trip, CRC, image decoding and browser rendering checks. Physical appearance on the recipient’s watch remains to be checked; battery life has not been measured. Known development firmware was 1.0.0.73; compatibility with every firmware release is not claimed.

Creator-specific device identifiers and transfer history are omitted. The server binds only to `127.0.0.1`. The installer keeps successful installation history in that browser and saves local verification/transfer results in the extracted folder. If you later reshare a folder you have used, use a fresh release ZIP to avoid including your own device-test records.

Optional browser checks, with the server running:

- `http://127.0.0.1:48762/verify-collection.html` — render and check all eight native files without connecting a watch.
- `http://127.0.0.1:48762/tests/selector.html` — check replacement-selector behavior without Bluetooth transfers.

## Source and rebuilding

The complete source used by this bundle is included: installer JavaScript/HTML, `engine/`, original FMC TypeScript in `source/fmc/`, compiler scripts, artwork generators, ordered asset manifests, RGBA/PNG assets and the Zenith reference image. The package can be installed entirely from the supplied native files without rebuilding.

To reproduce the eight `.bin` files from the included assets, use **Node.js 22.13 or newer** with TypeScript stripping support, from the extracted folder:

```sh
node source/build.mjs
node source/build-collection.mjs
node source/build-expanded.mjs
node --test tests/face-slots.test.mjs
```

The compilers check native integrity and update the matching manifest/report entries. The expanded compiler is limited to the faces in this package. Rebuilding does not install anything on a watch. Native hashes should match those in the original `package-manifest.json` when using the included unchanged assets. Regenerate previews/browser reports using `verify-collection.html` afterward. Existing `SHA256SUMS.txt` describes the shipped release and must be regenerated if you modify files before resharing.

Optional artwork regeneration also requires **Pillow** and the macOS system fonts referenced by the generators. Fonts are not redistributed. These steps are unnecessary for normal installation or recompilation from bundled assets:

```sh
python3 source/generate-assets.py
python3 source/generate-collection.py
python3 source/generate-classics.py
python3 source/generate-zenith.py
```

Run the compiler commands after regenerating artwork. To update the pinned FMC source, replace it deliberately and review the resulting engine changes; no upstream download happens during installation or rebuilding.

## Credits and licenses

The native format, renderer and Bluetooth implementation derive from [FMC by freethinkel](https://github.com/freethinkel/fmc), pinned to commit `cfc340c95ddd18adbf1e04a9e3613cad145c2dc3`. The included installer/compiler code and FMC-derived code are distributed under **AGPL-3.0-only**; see [LICENSE](LICENSE), [source/fmc/LICENSE](source/fmc/LICENSE) and [source/fmc/UPSTREAM.json](source/fmc/UPSTREAM.json). Keep the corresponding source and license when sharing, and provide corresponding source for modifications as required by that license.

These are unofficial personal adaptations of the supplied visual references, not products endorsed by the referenced brands. Brand marks and reference photography retain their respective owners’ rights; the code license does not grant trademark or photograph rights.

- Braun wordmark: original alpha artwork from Braun Clocks; provenance in `source/braun-logo-source.json`.
- Casio wordmark: Wikimedia SVG, PD-textlogo; map: Natural Earth public-domain land data. Provenance in `source/collection-art-sources.json`.
- Zenith: user-supplied photograph, retained in `source/zenith-reference.png`; crop, image hash and hand pivots in `source/zenith-reference-layout.json`.

Release: **13 November 2026 · eight-face selection**.
