@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python source\serve.py %*
) else (
  py -3 source\serve.py %*
)
pause
