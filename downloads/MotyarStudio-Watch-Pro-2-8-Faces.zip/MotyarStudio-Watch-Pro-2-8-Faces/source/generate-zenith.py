"""Regenerate the supplied-image Zenith face and its live clock artwork."""
import native_face_art as a
from zenith_photo import build_zenith
a.configure('weather')
a.finish([build_zenith(a)])
