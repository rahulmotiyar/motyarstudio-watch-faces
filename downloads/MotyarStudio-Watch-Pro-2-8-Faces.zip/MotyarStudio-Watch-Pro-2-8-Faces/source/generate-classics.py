"""Two code-drawn classic dial adaptations, with native clock/date widgets."""
import math
from PIL import Image, ImageDraw, ImageFilter, ImageChops, ImageColor
import native_face_art as A

A.configure('classics')
S=A.S
SERIF='/System/Library/Fonts/Supplemental/Times New Roman.ttf'
SERIFB='/System/Library/Fonts/Supplemental/Times New Roman Bold.ttf'
ITALIC='/System/Library/Fonts/Supplemental/Times New Roman Italic.ttf'
COND='/System/Library/Fonts/Supplemental/DIN Condensed Bold.ttf'
scenes=[]

def face_surface(color,edge=16,falloff=10):
    rgb=ImageColor.getrgb(color);im=Image.new('RGBA',(466,466));pixels=[]
    for y in range(466):
        for x in range(466):
            dx=(x-233)/233;dy=(y-233)/233;r=math.hypot(dx,dy);light=-(dx+dy)/math.sqrt(2)
            shade=edge*math.exp(-max(0,1-r)*233/falloff)*(0.8+0.45*light)
            grain=(((x*19+y*31)%23)-11)*.035
            pixels.append(tuple(max(0,min(255,round(v+light*3-shade+grain))) for v in rgb)+(255,))
    im.putdata(pixels);return im.resize((466*S,466*S),Image.Resampling.BICUBIC)

def polar(cx,cy,r,n,den=60):
    a=n*math.tau/den;return (cx+math.sin(a)*r,cy-math.cos(a)*r)

def radial_text(im,t,r,n,den=60,size=12,color='#303b36',font=A.FONT,rotation=True):
    a=n*360/den;A.rotated_text(im,polar(233,233,r,n,den),str(t),size,color,-a if rotation else 0,font)

def custom_hand(key,tip,width,color,style='spear',shadow=True):
    """Padded native sprite; shadow offset stays fixed in dial coordinates."""
    w=80;piv=tip+38;h=tip+104;h+=h%2;x=w/2
    im,d=A.canvas(w,h);mask=Image.new('L',im.size);md=ImageDraw.Draw(mask)
    if style=='spear':
        A.poly(md,[(x,piv-tip),(x+width/2,piv-tip+18),(x+width*.25,piv+13),(x-width*.25,piv+13),(x-width/2,piv-tip+18)],255)
    elif style=='breguet':
        A.poly(md,[(x,piv-tip),(x+width*.45,piv-tip+12),(x+width*.3,piv+13),(x-width*.3,piv+13),(x-width*.45,piv-tip+12)],255)
        A.ellipse(md,(x-6,piv-tip+12,x+6,piv-tip+24),255)
        A.ellipse(md,(x-3.8,piv-tip+14.2,x+3.8,piv-tip+21.8),0)
    elif style=='orange':
        A.poly(md,[(x,piv-tip),(x+width/2,piv-tip+15),(x+width/2,piv-8),(x+2,piv+15),(x-2,piv+15),(x-width/2,piv-8),(x-width/2,piv-tip+15)],255)
    elif style=='xeric':
        A.line(md,[(x,piv-tip),(x,piv+22)],255,1.6)
        A.rect(md,(x-10,piv-tip+8,x+10,piv-18),None,255,1,r=5)
    elif style=='baton':A.rect(md,(x-width/2,piv-tip,x+width/2,piv+8),255)
    else:A.line(md,[(x,piv-tip),(x,piv+22)],255,width)
    layer=Image.new('RGBA',im.size,color);layer.putalpha(mask);im.alpha_composite(layer);d=ImageDraw.Draw(im)
    if style in ('spear','orange'):
        A.line(d,[(x-.5,piv-tip+9),(x-.5,piv-7)],'#f3e4b0' if style=='orange' else '#718079',.45)
    if style=='xeric':A.line(d,[(x,piv-tip+5),(x,piv+21)],'#d78332',1.8)
    A.save(key,im,pivotX=x,pivotY=piv)
    if shadow:
        sh=Image.new('RGBA',im.size);alpha=mask.filter(ImageFilter.GaussianBlur((6 if tip>70 else 2.4)*S)).point(lambda v:round(v*.5))
        sh.putalpha(alpha);A.save(key+'-shadow',sh,pivotX=x,pivotY=piv,offsetX=2 if tip>70 else 1,offsetY=5 if tip>70 else 2)

def hand_layers(prefix,cx=233,cy=233,seconds=True):
    ls=[]
    for name,source in [('hour',10),('minute',14)]+([('second',114)] if seconds else []):
        ls.extend([A.pointer(prefix+'-'+name+'-shadow',cx,cy,source),A.pointer(prefix+'-'+name,cx,cy,source)])
    return ls

def cap(prefix,color,size=7,metal=False):
    im,d=A.canvas(80,80);A.ellipse(d,(40-size+2,40-size+5,40+size+2,40+size+5),(0,0,0,110));im=im.filter(ImageFilter.GaussianBlur(5*S));d=ImageDraw.Draw(im)
    rgb=ImageColor.getrgb(color)
    for r in range(round(size*S),0,-1):
        k=(size-r/S)/size;v=tuple(max(0,min(255,round(c+8*k))) for c in rgb)
        A.ellipse(d,(40-r/S,40-r/S,40+r/S,40+r/S),v+(255,))
    if metal:
        A.ellipse(d,(38.2,38.2,41.8,41.8),'#181e1b');A.ellipse(d,(39,38.6,40.2,39.8),'#a8b0a4')
    A.save(prefix+'-cap',im);return A.art(prefix+'-cap',193,193)

def sub(im,cx,cy,r,den=60,marks=None,cream=False,ink='#3c4540'):
    """Concentric machined well with a diffuse directional inner shadow."""
    patch,d=A.canvas(r*2+4,r*2+4);base=(239,235,214) if cream else (220,225,219)
    data=[]
    for yy in range(patch.height):
        for xx in range(patch.width):
            dx=(xx+.5)/S-r-2;dy=(yy+.5)/S-r-2;rr=math.hypot(dx,dy);dep=r-rr
            if dep<0:data.append((0,0,0,0));continue
            light=-(dx+dy)/max(rr,1)/math.sqrt(2)
            v=25*math.exp(-dep/5)*(.6+.4*light)-6*math.exp(-((dep-.7)/.8)**2)*max(0,-light)
            groove=.6*math.sin(rr*math.tau/1.7)
            data.append(tuple(max(0,min(255,round(b-v+groove))) for b in base)+(255,))
    patch.putdata(data);im.alpha_composite(patch,(round((cx-r-2)*S),round((cy-r-2)*S)));d=ImageDraw.Draw(im)
    for n in range(den):
        if den==24 and n%2:continue
        A.tick(d,n,cx,cy,r-(9 if n%(5 if den==60 else 6)==0 else 6),r-3,ink,1 if n%(5 if den==60 else 6)==0 else .65,den)
    marks=marks or ([(0,'60'),(20,'20'),(40,'40')] if den==60 else [(0,'24'),(6,'06'),(12,'12'),(18,'18')])
    for n,t in marks:
        a=n*math.tau/den;A.text(d,(cx+math.sin(a)*(r-17),cy-math.cos(a)*(r-17)),t,10.5,ink)

def small_pointer(prefix,color,tip=27,width=1.8):
    custom_hand(prefix,tip,width,color,'needle');return prefix

def small_layers(key,cx,cy,source):return [A.pointer(key+'-shadow',cx,cy,source),A.pointer(key,cx,cy,source)]

def date_window(im,prefix,x,y,w=27,h=31,frame='#9b9e90',red=False,cream=False):
    d=ImageDraw.Draw(im);A.rect(d,(x,y,x+w,y+h),'#b41b25' if red else frame,r=1)
    A.rect(d,(x+2,y+2,x+w-2,y+h-2),'#f5f3e5' if cream else '#f6f7f0')
    A.line(d,[(x+2,y+h-2),(x+2,y+2),(x+w-2,y+2)],'#787e72',.8)
    A.line(d,[(x+3,y+h-2),(x+w-2,y+h-2),(x+w-2,y+3)],'#ffffff',.7)
    keys=A.digits(prefix+'-date',11,24,21,'#252e26',A.NARROW)
    return A.number(keys,x+(w-22)//2,y+(h-24)//2,23),{'x':x,'y':y,'w':w+1,'h':h+1}

def add_scene(theme,name,im,layers,description,**extra):
    A.roundface(theme+'-dial',im)
    scenes.append({'theme':theme,'name':name,'kind':'analog','description':description,'main':[A.art(theme+'-dial',0,0),*layers],**extra})

# 1 — BAI wall-clock adaptation. The orange hub and squared radial numerals are
# drawn as geometry rather than substituting a conventional dial font.
p='bai-clock';im=face_surface('#f3f1eb',30,42);d=ImageDraw.Draw(im)
tick_inner,tick_outer=188,210
for n in range(60):
    # Each numbered hour replaces the fifth minute mark, leaving four strokes.
    if n%5==0:continue
    A.tick(d,n,233,233,tick_inner,tick_outer,'#77786b',1,60)
paths={0:[(0,0),(17,0),(17,25),(0,25),(0,0)],1:[(12,0),(12,25)],2:[(0,0),(17,0),(17,12),(0,12),(0,25),(17,25)],3:[(0,0),(17,0),(17,25),(0,25)],4:[(0,0),(0,12),(17,12),(17,0),(17,25)],5:[(17,0),(0,0),(0,12),(17,12),(17,25),(0,25)],6:[(17,0),(0,0),(0,25),(17,25),(17,12),(0,12)],7:[(0,0),(17,0),(17,25)],8:[(0,0),(17,0),(17,25),(0,25),(0,0),(0,12),(17,12)],9:[(0,25),(17,25),(17,0),(0,0),(0,12),(17,12)]}
for h in range(1,13):
    glyph,gd=A.canvas(66,46);s=str(h);span=(len(s)*23-6);x=(66-span)/2
    for ch in s:
        A.line(gd,[(x+xx,10+yy) for xx,yy in paths[int(ch)]],'#252a22',3.1)
        if ch=='3':A.line(gd,[(x,22.5),(x+17,22.5)],'#252a22',3.1)
        x+=23
    # Center actual ink rather than the nominal text cell. The lower numerals
    # turn inward, matching the original clock's readable 4–8 orientation.
    glyph=glyph.crop(glyph.getchannel('A').getbbox())
    angle=180-h*30 if 4<=h<=8 else -h*30
    glyph=glyph.rotate(angle,resample=Image.Resampling.BICUBIC,expand=True)
    glyph=glyph.crop(glyph.getchannel('A').getbbox())
    px,py=polar(233,233,(tick_inner+tick_outer)/2,h,12)
    im.alpha_composite(glyph,(round(px*S-glyph.width/2),round(py*S-glyph.height/2)))
custom_hand(p+'-hour',116,6,'#20241c','baton');custom_hand(p+'-minute',193,3,'#20241c','baton')
custom_hand(p+'-second',207,1.5,'#ff951d','needle')
d=ImageDraw.Draw(im);A.text(d,(233,128),'MotyarStudio',17,'#62675b',index=10)
add_scene(p,'MotyarStudio',im,[*hand_layers(p),cap(p,'#ff951d',20)],'Ivory dial with a generous outer margin, four minute strokes between hour numerals and an orange seconds needle.',revision=4,filename='motyarstudio.bin',preview='motyarstudio-preview.png',aodPreview='motyarstudio-aod-preview.png',validationFile='motyarstudio-validation.json',supportsSeconds=True,hasDate=False,referenceIndex=1,minuteTrack={'divisions':60,'minorStrokes':48,'strokesBetweenHours':4,'innerRadius':tick_inner,'outerRadius':tick_outer,'labelRadius':(tick_inner+tick_outer)/2})

# 5 — Mint concentric scale dial. Fine rings remain legible at the watch's
# native size; labels have fixed orientation relative to their scale.
p='xeric-mint';im=face_surface('#c7e0d7',26);d=ImageDraw.Draw(im);ink='#3f635a'
scale_bounds=[54,64,92,120,172,194,216,228]
scale_layout={'boundaries':scale_bounds,'labelRadii':{'roman':78,'innerHour':106,'hour':146,'quarterMinute':183,'minute':205},'fontSizes':{'roman':14,'innerHour':14,'hour':34,'quarterMinute':8.5,'minute':23},'lowerLabelsUpright':True}
def xeric_label(label,r,n,den,size,font=A.FONT):
    # Rotate a tightly cropped glyph, then align its visible bounds to the
    # scale's centerline; font ascenders/side bearings cannot shift the rings.
    glyph,gd=A.canvas(112,56);A.text(gd,(56,28),str(label),size,ink,font)
    glyph=glyph.crop(glyph.getchannel('A').getbbox());angle=n*360/den
    rotation=-angle+(180 if 90<angle%360<270 else 0)
    glyph=glyph.rotate(rotation,resample=Image.Resampling.BICUBIC,expand=True)
    glyph=glyph.crop(glyph.getchannel('A').getbbox());x,y=polar(233,233,r,n,den)
    im.alpha_composite(glyph,(round(x*S-glyph.width/2),round(y*S-glyph.height/2)))
for r in scale_bounds:A.ellipse(d,(233-r,233-r,233+r,233+r),None,ink,.55)
for n in range(120):A.tick(d,n,233,233,217 if n%10==0 else 221,227,ink,1.05 if n%10==0 else .55,120)
for n in range(12):A.tick(d,n,233,233,166,172,ink,.9,12)
for n in range(12):
    xeric_label('60' if n==0 else str(n*5),205,n,12,23,A.NARROW)
    xeric_label(str(n or 12),146,n,12,34)
    xeric_label(str(n or 12),106,n,12,14,A.NARROW)
for n in range(48):
    A.tick(d,n,233,233,173,177,ink,.55,48)
    hour=(n//4) or 12;minute=(n%4)*15
    xeric_label(f'{hour:02d}:{minute:02d}',183,n,48,8.5,A.NARROW)
for n,t in enumerate(['XII','I','II','III','IV','V','VI','VII','VIII','IX','X','XI']):xeric_label(t,78,n,12,14,SERIF)
for n in range(60):A.tick(d,n,233,233,54 if n%5==0 else 59,64,ink,.7 if n%5==0 else .45)
d=ImageDraw.Draw(im);A.tracked(d,(233,271),'XERIC',16,ink,1.8)
custom_hand(p+'-hour',139,4,ink,'xeric');custom_hand(p+'-minute',212,3,ink,'xeric');custom_hand(p+'-second',216,1.3,'#d88b39','needle')
add_scene(p,'Xeric Mint',im,[*hand_layers(p),cap(p,'#304b44',10,True)],'Mint technical dial with larger hour and minute numerals, balanced concentric scales and orange-accented skeleton hands.',revision=2,hasDate=False,referenceIndex=5,scaleLayout=scale_layout)


A.finish(scenes)
