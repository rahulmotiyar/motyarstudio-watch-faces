import fs from 'node:fs';
import path from 'node:path';
import {stripTypeScriptTypes} from 'node:module';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';

const scriptDir=path.dirname(fileURLToPath(import.meta.url));
const portable=path.basename(scriptDir)==='source';
const root=path.resolve(scriptDir,'..');
const out=portable?root:path.join(root,'outputs/braun-round');
const upstream=portable?path.join(out,'source/fmc'):path.join(root,'work/fmc');
const modules=portable?upstream:path.join(upstream,'src/lib/modules');
const sources=path.join(out,'source/fmc');
const engine=path.join(out,'engine');
const commit=portable?JSON.parse(fs.readFileSync(path.join(upstream,'UPSTREAM.json'),'utf8')).commit:
  fs.readFileSync(path.join(upstream,'.git/shallow'),'utf8').trim();
fs.mkdirSync(sources,{recursive:true});
if(!portable)fs.copyFileSync(path.join(upstream,'LICENSE'),path.join(sources,'LICENSE'));
fs.writeFileSync(path.join(sources,'UPSTREAM.json'),JSON.stringify({url:'https://github.com/freethinkel/fmc',commit,license:'AGPL-3.0-only'},null,2)+'\n');

function emitDir(rel){
  const src=path.join(modules,rel);
  for(const entry of fs.readdirSync(src,{withFileTypes:true})){
    const child=path.join(rel,entry.name);
    if(entry.isDirectory()){emitDir(child);continue;}
    if(!entry.name.endsWith('.ts')&&!entry.name.endsWith('.json'))continue;
    const sourcePath=path.join(sources,child);
    fs.mkdirSync(path.dirname(sourcePath),{recursive:true});
    if(!portable)fs.copyFileSync(path.join(modules,child),sourcePath);
    let content=fs.readFileSync(sourcePath,'utf8');
    const dest=path.join(engine,child.replace(/\.ts$/,'.js'));
    fs.mkdirSync(path.dirname(dest),{recursive:true});
    if(child.endsWith('.ts')){
      content=stripTypeScriptTypes(content);
      content=content.replace(/(from\s*["'])(\.[^"']+)(["'])/g,(all,a,p,b)=>{
        const resolved=path.resolve(path.dirname(path.join(modules,child)),p);
        if(p.endsWith('.json'))return a+p+b+' with { type: "json" }';
        const suffix=fs.existsSync(resolved+'.ts')?'.js':'/index.js';
        return a+p+suffix+b;
      });
    }
    fs.writeFileSync(dest,content);
  }
}
emitDir('editor/core');
// Only the three upstream BLE implementation files, no app or analytics.
for(const name of ['ble.ts','ble-protocol.ts','catalog-names.ts','stock-dials.json']){
  const rel='device/lib/'+name,src=path.join(modules,rel);
  fs.mkdirSync(path.dirname(path.join(sources,rel)),{recursive:true});
  if(!portable)fs.copyFileSync(src,path.join(sources,rel));
  let text=fs.readFileSync(src,'utf8');
  if(name.endsWith('.ts'))text=stripTypeScriptTypes(text).replace(/(from\s*["'])(\.[^"']+)(["'])/g,
    (_,a,p,b)=>a+p+(p.endsWith('.json')?'':'.js')+b+(p.endsWith('.json')?' with { type: "json" }':''));
  const dest=path.join(engine,rel.replace(/\.ts$/,'.js'));
  fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,text);
}
fs.writeFileSync(path.join(engine,'package.json'),'{"type":"module"}\n');
const {encodePixels,decodePixels}=await import(path.join(engine,'editor/core/format/pixels-codec.js'));
const {buildBin,parseBin,assertFlashable,rawCRC32}=await import(path.join(engine,'editor/core/format/bin.js'));
const {TAG,u32}=await import(path.join(engine,'editor/core/format/raw.js'));
const {fromLegacy,toLegacy}=await import(path.join(engine,'editor/core/document/doc.js'));
const {idValue,defaultSim,timeParts}=await import(path.join(engine,'editor/core/document/sources.js'));
const manifest=JSON.parse(fs.readFileSync(path.join(out,'assets/manifest.json'),'utf8'));
const resources=[],ids={};
for(const [name,{w,h,cf}] of Object.entries(manifest)){
  const pixels=new Uint8ClampedArray(fs.readFileSync(path.join(out,'assets',name+'.rgba')));
  ids[name]=resources.length;resources.push(encodePixels(pixels,w,h,cf));
}
function meta(w=0,h=0,source=0,max=0){
  const m=new Uint8Array(14),v=new DataView(m.buffer);
  v.setUint16(0,w,true);v.setUint16(2,h,true);m[9]=source;
  m[11]=max;m[12]=max>>8;m[13]=max>>16;
  return Buffer.from(m).toString('hex');
}
function image(key,x,y,w=0,h=0){return {tag:TAG.image,subs:[{tag:TAG.struct,x,y,
  meta:meta(w,h),refType:0x61,images:[ids[key]]}]};}
function preview(key){return {tag:TAG.preview,subs:[{tag:TAG.pvStruct,prefix:'0000000000',
  refType:0x61,images:[ids[key]]}]};}
function hand(key,source){
  const {w,pivotY,offsetX=0,offsetY=0}=manifest[key];
  return {tag:TAG.hand,subs:[{tag:TAG.struct,
  x:233-w/2+offsetX,y:233-pivotY+offsetY,meta:meta(0,0,source,60),
  refType:0x61,images:[ids[key]]},{tag:TAG.pivot,flag:1,pivotX:w/2,pivotY}]};}
const reports=[];
for(const theme of ['white','black']){
const prefix=theme==='black'?'black-':'',name=theme==='black'?'Braun Black':'Braun Round';
const filename=theme==='black'?'braun-black.bin':'braun-round.bin';
const rawFace={name,resources,screens:[
  {tag:TAG.main,subs:[{tag:TAG.name,text:name},preview(prefix+'thumb'),image(prefix+'dial',0,0,466,466),
    {tag:TAG.number,subs:[{tag:TAG.struct,x:221,y:342,meta:meta(0,0,0x17,31),
      refType:0x61,images:Array.from({length:10},(_,i)=>ids['digit-'+i])},{tag:TAG.fmt,hex:'82'}]},
    image('hub-shadow',200,203),image(prefix+'hub-base',216,217),
    ...[['hour',0x0a],['minute',0x0e],['second',0x72]].flatMap(([key,source])=>[
      hand(prefix+key+'-shadow',source),hand(prefix+key,source)])]},
  {tag:TAG.aod,subs:[preview('aod-thumb'),image('aod-dial',0,0,466,466),
    hand('aod-hour',0x0a),hand('aod-minute',0x0e),image('aod-cap',227,227)]}
]};
// Canonical resource packing removes the other colorway's art from each native file.
const face=toLegacy(fromLegacy(rawFace).doc);
const bin=buildBin(face),parsed=parseBin(bin);
fs.writeFileSync(path.join(out,filename),bin);
assert.deepEqual(buildBin(parsed),bin,'byte-exact parser/compiler round trip');
assertFlashable(bin);
for(const r of parsed.resources){assert(r.w<=466&&r.h<=466);assert(decodePixels(r));}
const treeEnd=39+(bin[37]|bin[38]<<8),resourceEnd=bin.length-36;
assert.equal(rawCRC32(bin.subarray(treeEnd,resourceEnd)),u32(bin,32),'resource CRC');
const headerAndTree=new Uint8Array(32+treeEnd-36);
headerAndTree.set(bin.subarray(4,36));headerAndTree.set(bin.subarray(36,treeEnd),32);
assert.equal(rawCRC32(headerAndTree),u32(bin,0),'header/tree CRC');
assert.equal(u32(bin,24),bin.length-36);assert.equal(u32(bin,28),resourceEnd-treeEnd);
const {doc}=fromLegacy(parsed);
assert.deepEqual(doc.screens.map(s=>s.kind),['main','aod']);
const mainHands=doc.screens[0].layers.filter(l=>l.kind==='hand');
assert.deepEqual(mainHands.map(l=>l.meta.source),[10,10,14,14,114,114]);
for(let i=0;i<6;i++){
  const l=mainHands[i],asset=manifest[prefix+['hour','minute','second'][Math.floor(i/2)]+(i%2===0?'-shadow':'')];
  assert.equal(l.x+l.pivotX,233+(asset.offsetX??0));
  assert.equal(l.y+l.pivotY,233+(asset.offsetY??0));
}
assert.equal(doc.screens[0].layers.find(l=>l.kind==='number').meta.source,23);
const sim=defaultSim();sim.live=false;
for(let day=1;day<=31;day++){
  sim.time=new Date(2026,0,day,10,8,35).getTime();
  assert.equal(idValue(0x17,sim,timeParts(sim)),day);
}
for(const [h,m,seconds] of [[0,0,0],[3,15,15],[6,30,30],[9,45,45]]){
  sim.time=new Date(2026,0,1,h,m,seconds).getTime();
  assert.equal(idValue(10,sim,timeParts(sim)),h*5+m/12);
  assert.equal(idValue(14,sim,timeParts(sim)),m+seconds/60);
  assert.equal(idValue(114,sim,timeParts(sim)),seconds);
}
// Also check the compiler against the upstream physical-format fixtures.
let fixtures=0;
const fixtureDir=path.join(upstream,'tests/__fixtures__');
for(const name of (fs.existsSync(fixtureDir)?fs.readdirSync(fixtureDir):[]).filter(n=>n.endsWith('.bin'))){
  const bytes=new Uint8Array(fs.readFileSync(path.join(upstream,'tests/__fixtures__',name)));
  assert.deepEqual(buildBin(parseBin(bytes)),bytes);fixtures++;
}
const report={name:face.name,theme,revision:5,filename,target:'CMF Watch Pro 2',resolution:[466,466],bytes:bin.length,
 sha256:crypto.createHash('sha256').update(bin).digest('hex'),
 upstream:{url:'https://github.com/freethinkel/fmc',commit,license:'AGPL-3.0-only'},
 checks:{nativeMainAndAod:true,previewsOnBothScreens:true,liveHands:3,liveShadowLayers:3,shadowPivotsChecked:true,liveDayOfMonth:true,
  dateValuesChecked:31,headerAndResourceCrc:true,byteExactRoundTrip:true,
  allAssetsDecoded:true,maxImageSide:466,upstreamFixturesRoundTripped:fixtures},
 hardware:{connected:false,uploaded:false,verifiedOnWatch:false}};
fs.writeFileSync(path.join(out,theme==='black'?'black-validation.json':'validation.json'),JSON.stringify(report,null,2)+'\n');
reports.push(report);
}
const priorVariants=JSON.parse(fs.readFileSync(path.join(out,'variants.json'),'utf8'));
const mainVariants=reports.map(({theme,name,filename,sha256,revision})=>({
  ...priorVariants.find(v=>v.theme===theme),theme,name,filename,sha256,revision}));
fs.writeFileSync(path.join(out,'variants.json'),JSON.stringify([...mainVariants,...priorVariants.filter(v=>!['white','black'].includes(v.theme))],null,2)+'\n');
if(!portable){
  fs.copyFileSync(fileURLToPath(import.meta.url),path.join(out,'source/build.mjs'));
  fs.copyFileSync(path.join(root,'work/generate-assets.py'),path.join(out,'source/generate-assets.py'));
  fs.copyFileSync(path.join(root,'work/serve.py'),path.join(out,'source/serve.py'));
}
console.log(JSON.stringify(reports.map(({theme,bytes,checks})=>({theme,bytes,checks})),null,2));
