"""Serve this watch-face bundle on loopback; keep local verification results here."""
import argparse
import json
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

ROOT = Path(__file__).resolve().parent.parent


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def do_POST(self):
        port = self.server.server_port
        allowed_origins = (None, f'http://127.0.0.1:{port}', f'http://localhost:{port}')
        if self.headers.get('Origin') not in allowed_origins:
            self.send_error(403)
            return
        try:
            size = int(self.headers.get('Content-Length', 0))
        except ValueError:
            self.send_error(400)
            return
        if not 0 <= size <= 3_000_000:
            self.send_error(413)
            return
        data = self.rfile.read(size)
        url = urlsplit(self.path)
        theme = parse_qs(url.query).get('theme', ['white'])[0]
        variants = json.loads((ROOT / 'variants.json').read_text())
        previews = {v['preview'] for v in variants} | {v['aodPreview'] for v in variants}
        filename = url.path.rsplit('/', 1)[-1]
        if url.path.startswith('/api/render/') and filename in previews:
            if not data.startswith(b'\x89PNG\r\n\x1a\n'):
                self.send_error(400)
                return
            (ROOT / filename).write_bytes(data)
        elif url.path in ('/api/hardware', '/api/render-checks'):
            variant = next((v for v in variants if v['theme'] == theme), None)
            if variant is None:
                self.send_error(404)
                return
            try:
                result = json.loads(data)
            except (ValueError, UnicodeDecodeError):
                self.send_error(400)
                return
            if not isinstance(result, dict):
                self.send_error(400)
                return
            report_path = ROOT / variant['validationFile']
            report = json.loads(report_path.read_text())
            report['hardware' if url.path == '/api/hardware' else 'browserRendering'] = result
            report_path.write_text(json.dumps(report, indent=2) + '\n')
        else:
            self.send_error(404)
            return
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b'OK')

    def log_message(self, fmt, *args):
        if self.command == 'POST' or len(args) < 2 or str(args[1]) != '200':
            super().log_message(fmt, *args)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=48762, help='Local port (default: 48762)')
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error('--port must be between 1 and 65535')
    try:
        server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    except OSError as error:
        parser.exit(1, f'Cannot start local preview: {error}\nTry another port, for example --port 48763.\n')
    print(f'Eight-face gallery: http://127.0.0.1:{args.port}/collection.html', flush=True)
    print(f'Bluetooth installer: http://127.0.0.1:{args.port}/', flush=True)
    print('Leave this terminal open. Press Ctrl+C to stop.', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nPreview stopped.')
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
